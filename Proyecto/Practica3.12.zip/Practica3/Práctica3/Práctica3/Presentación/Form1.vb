﻿Public Class Form1

    Public Property j As Jugadora
    Public Property p As Pais
    Public Property t As Torneo
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' ActualizarListas()
        ActualizarPaises()
        ActualizarListaTorneo()
        ConectarBBDD()

    End Sub
    'Private Sub ActualizarListas()
    '    Dim jugadoras As Jugadora
    '    jugadoras = New Jugadora()

    '    Lista_jugadoras.Items.Clear()

    '    Try
    '        jugadoras.LeerTodas()

    '        For Each player As Jugadora In jugadoras.jDAO.jugadoras
    '            Lista_jugadoras.Items.Add(player.NombreJugadora)
    '        Next
    '    Catch ex As Exception
    '        MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    '    End Try
    'End Sub


    Private Sub ActualizarPaises()
        Me.p = New Pais
        Dim paux As Pais
        Dim aux As String
        SelectPais.Items.Clear()
        SelectPaisTorneo.Items.Clear()
        lista_paises.Items.Clear()
        Try
            Me.p.LeerTodas()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End Try
        For Each paux In Me.p.pDAO.paises
            'paux = p.pDAO.paises(1)'
            aux = New String(paux.idPais)
            SelectPais.Items.Add(aux)
            SelectPaisTorneo.Items.Add(aux)
            Me.lista_paises.Items.Add(paux.NombrePais)
        Next
    End Sub

    Private Sub ActualizarListaTorneo()
        SeleccionarTorneo.Items.Clear()
        Lista_Torneos.Items.Clear()
        Dim taux As Torneo
        Me.t = New Torneo
        Try
            Me.t.LeerTodas()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End Try
        For Each taux In Me.t.tDAO.torneos
            Me.Lista_Torneos.Items.Add(taux.NombreTorneo)
            Me.SeleccionarTorneo.Items.Add(taux.NombreTorneo)
        Next
    End Sub


    Private Sub ConectarBBDD()
        Dim jaux As Jugadora
        Me.j = New Jugadora
        Dim paux As Pais
        Me.p = New Pais
        Dim taux As Torneo
        Me.t = New Torneo
        Dim auxIDPais As String

        Try
            Me.j.LeerTodas()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End Try
        For Each jaux In Me.j.jDAO.jugadoras
            Me.Lista_jugadoras.Items.Add(jaux.NombreJugadora)
        Next

        'Try
        '    Me.p.LeerTodas()
        'Catch ex As Exception
        '    MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        '    Exit Sub
        'End Try
        'For Each paux In Me.p.pDAO.paises
        '    Me.lista_paises.Items.Add(paux.NombrePais)
        'Next

        'Try
        '    Me.t.LeerTodas()
        'Catch ex As Exception
        '    MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        '    Exit Sub
        'End Try
        'For Each taux In Me.t.tDAO.torneos
        '    Me.Lista_Torneos.Items.Add(taux.NombreTorneo)
        'Next
    End Sub
    Private Function formatoFecha(fechaInicial As String) As String
        Dim fechaux As String()
        fechaux = Split(fechaInicial, "/")
        Return fechaux(2) + "-" + fechaux(1) + "-" + fechaux(0)
    End Function
    Private Sub boton_insertarjugadora_Click(sender As Object, e As EventArgs) Handles boton_insertarjugadora.Click
        If Me.nombre_textbox.Text <> String.Empty And Me.SelectPais.Text <> String.Empty Then
            j = New Jugadora()
            j.idJugadora = j.MaxID() + 1
            j.NombreJugadora = nombre_textbox.Text
            Dim auxPaisString As Char()
            Dim auxPais As Pais
            auxPaisString = SelectPais.Text.ToCharArray()
            auxPais = New Pais(auxPaisString)
            j.PaisJugadora = auxPais
            Dim fechaux As String()
            fechaux = Split(FechaNacimiento.Value.ToString)
            j.FechaNacimientoJugadora = formatoFecha(fechaux(0))
            MessageBox.Show(j.FechaNacimientoJugadora)
            j.PuntosJugadora = 0

            Try
                If j.InsertarJugadora() <> 1 Then
                    MessageBox.Show("INSERT return <> 1", String.Empty, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub

            End Try
            Me.Lista_jugadoras.Items.Add(j.NombreJugadora)
        End If
    End Sub

    Private Sub Boton_Insertar_Pais_Click(sender As Object, e As EventArgs) Handles Boton_Insertar_Pais.Click
        If Me.NombrePais_Text.Text <> String.Empty Then
            p = New Pais()
            p.NombrePais = NombrePais_Text.Text
            Dim nombreaux As String = UCase(p.NombrePais)
            Dim aux2 As String = nombreaux.Substring(0, 3)
            p.idPais = aux2
            Dim aux As String
            aux = New String(p.idPais)
            Try
                If p.InsertarPais() <> 1 Then
                    MessageBox.Show("INSERT return <> 1", String.Empty, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub

            End Try
            Me.lista_paises.Items.Add(p.NombrePais)
            SelectPais.Items.Add(aux)
            ActualizarPaises()
        End If
    End Sub

    Private Sub Boton_Insertar_Torneo_Click(sender As Object, e As EventArgs) Handles Boton_Insertar_Torneo.Click
        If Me.NombreTorneo_Text.Text <> String.Empty And Me.CiudadTorneo_Text.Text <> String.Empty And Me.SelectPaisTorneo.Text <> String.Empty Then
            t = New Torneo()
            t.idTorneo = t.MaxID() + 1
            t.NombreTorneo = NombreTorneo_Text.Text
            t.CiudadTorneo = CiudadTorneo_Text.Text
            Dim auxPaisTorneo As Pais
            Dim auxChar As Char() = SelectPaisTorneo.Text.ToCharArray()
            auxPaisTorneo = New Pais(auxChar)
            t.PaisTorneo = auxPaisTorneo
            Try
                If t.InsertarTorneo() <> 1 Then
                    MessageBox.Show("INSERT return <> 1", String.Empty, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub

            End Try
            ActualizarListaTorneo()
        End If
    End Sub

    Private Sub idjugadoras_textbox_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub idPais_Text_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub BotonBorrarJugadora_Click(sender As Object, e As EventArgs) Handles BotonBorrarJugadora.Click
        If Lista_jugadoras.SelectedItem IsNot Nothing Then
            Try
                Dim jugadora As Jugadora = New Jugadora(Lista_jugadoras.SelectedItem.ToString)
                Lista_jugadoras.Items.Remove(jugadora.NombreJugadora)
                jugadora.Borrar_NombreJugadora()

            Catch ex As Exception

            End Try
        End If

    End Sub

    Private Sub Boton_Borrar_Pais_Click(sender As Object, e As EventArgs) Handles Boton_Borrar_Pais.Click
        If lista_paises.SelectedItem IsNot Nothing Then
            Try
                Dim p As Pais = New Pais(lista_paises.SelectedItem.ToString)
                lista_paises.Items.Remove(lista_paises.SelectedItem)
                p.BorrarPais()
                SelectPais.Items.Clear()
                ActualizarPaises()
            Catch ex As Exception

            End Try
        End If
    End Sub

    Private Sub BotonBorrar_Torneo_Click(sender As Object, e As EventArgs) Handles BotonBorrar_Torneo.Click
        If Lista_Torneos.SelectedItem IsNot Nothing Then
            Try
                Dim t As Torneo = New Torneo(Lista_Torneos.SelectedItem.ToString)
                Lista_Torneos.Items.Remove(Lista_Torneos.SelectedItem)
                t.BorrarTorneo_Nombre()
                ActualizarListaTorneo()
            Catch ex As Exception

            End Try
        End If

    End Sub

    Private Sub Lista_Torneos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Lista_Torneos.SelectedIndexChanged
        If Lista_Torneos.SelectedItem IsNot Nothing Then
            Dim torneo As Torneo = New Torneo(Lista_Torneos.SelectedItem.ToString)
            torneo.LeerDatosTorneo()
            NombreTorneo_Text.Text = torneo.NombreTorneo
            CiudadTorneo_Text.Text = torneo.CiudadTorneo
            SelectPaisTorneo.Text = torneo.PaisTorneo.idPais
            LabelidTorneo.Text = torneo.idTorneo
        End If
    End Sub
    Private Sub lista_paises_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lista_paises.SelectedIndexChanged
        If lista_paises.SelectedItem IsNot Nothing Then
            Dim p As Pais = New Pais(lista_paises.SelectedItem.ToString)
            p.LeerPaisNombre()
            Dim aux As New String(p.idPais)
            Labelid.Text = aux
            NombrePais_Text.Text = p.NombrePais
        End If
    End Sub
    Private Sub ActualizarTorneos_Click(sender As Object, e As EventArgs) Handles ActualizarTorneos.Click
        If Me.NombreTorneo_Text.Text <> String.Empty And Me.CiudadTorneo_Text.Text <> String.Empty And Me.SelectPaisTorneo.Text <> String.Empty And Lista_Torneos.SelectedItem IsNot Nothing Then
            Dim t As Torneo = New Torneo(Lista_Torneos.SelectedItem.ToString)
            t.LeerDatosTorneo()
            Dim nuevoNombre As String
            nuevoNombre = NombreTorneo_Text.Text
            t.NombreTorneo = nuevoNombre
            t.ActualizarTorneo()
            ActualizarListaTorneo()
        End If
    End Sub

    Private Sub Boton_Actualizar_Pais_Click(sender As Object, e As EventArgs) Handles Boton_Actualizar_Pais.Click
        If Me.NombrePais_Text.Text <> String.Empty And lista_paises.SelectedItem IsNot Nothing Then
            Dim p As Pais = New Pais(lista_paises.SelectedItem.ToString)
            p.LeerDatosPais()
            Dim nuevoPais As String = NombrePais_Text.Text
            p.NombrePais = nuevoPais
            p.ActualizarPais()
            ActualizarPaises()

        End If
    End Sub

    Private Function elegirJugadoras(cantidad As Integer) As Integer()
        Randomize()
        Dim i As Integer
        Dim j As Integer
        j = 0
        Dim n As Integer
        Dim vector(7) As Integer
        Dim repetido As Boolean
        repetido = False

        For j = 0 To 7 Step 1

            Do
                repetido = False
                n = Int((cantidad - 1 + 1) * Rnd() + 1)
                For i = 0 To 7 Step 1
                    If n = vector(i) Then
                        repetido = True
                        Exit For

                    End If
                Next

            Loop While (repetido)
            vector(j) = n
        Next
        Return vector
    End Function

    Private Sub Boton_InsertarEdicion_Click(sender As Object, e As EventArgs) Handles Boton_InsertarEdicion.Click
        If Me.SeleccionarTorneo.Text <> String.Empty And Me.AnoTorneo.Text <> String.Empty Then
            Dim edi As New Ediciones
            edi.anualidad = AnoTorneo.Text
            Dim t As New Torneo(SeleccionarTorneo.Text.ToString)
            t.LeerDatosTorneo()
            edi.torneo = New Torneo(t.idTorneo)
            Dim j As New Jugadora
            j.LeerTodas()
            Dim participantes(7) As Integer
            participantes = elegirJugadoras(j.jDAO.jugadoras.Count)
            Array.Sort(participantes)
            Dim vectorJug(7) As Jugadora
            vectorJug = j.LeerRandom(participantes)
            escribirCuartos(vectorJug)

        End If
    End Sub

    Private Sub escribirCuartos(ByRef v() As Jugadora)
        Cuartos1.Text = v(7).NombreJugadora
        Cuartos2.Text = v(6).NombreJugadora
        Cuartos3.Text = v(5).NombreJugadora
        Cuartos4.Text = v(4).NombreJugadora
        Cuartos5.Text = v(3).NombreJugadora
        Cuartos6.Text = v(2).NombreJugadora
        Cuartos7.Text = v(1).NombreJugadora
        Cuartos8.Text = v(0).NombreJugadora

    End Sub

    Private Sub Lista_jugadoras_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Lista_jugadoras.SelectedIndexChanged
        If Lista_jugadoras.SelectedItem IsNot Nothing Then
            Dim jug As Jugadora = New Jugadora(Lista_jugadoras.SelectedItem.ToString)
            jug.LeerDatosJugadora()
            idText.Text = jug.idJugadora
            puntosJug.Text = jug.PuntosJugadora
            nombre_textbox.Text = jug.NombreJugadora
            SelectPais.Text = jug.PaisJugadora.NombrePais
            FechaNacimiento.Value = jug.FechaNacimientoJugadora
        End If
    End Sub
End Class
