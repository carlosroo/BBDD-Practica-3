﻿Public Class EdicionesDAO
    Public ReadOnly Property tenis As Collection

    Public Sub New()
        Me.tenis = New Collection
    End Sub

    Public Sub LeerTodas()
        Dim e As Ediciones
        Dim t As Torneo = New Torneo()
        Dim j As Jugadora = New Jugadora()
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente().Leer("SELECT * FROM Ediciones ORDER BY Anualidad")
        For Each aux In col
            e = New Ediciones(aux(1).ToString)
            e.anualidad = aux(1).ToString
            t.idTorneo = aux(2)
            t.LeerTorneo()
            e.torneo = t
            j.idJugadora = aux(3)
            j.LeerJugadora()
            e.ganadora = j

            Me.tenis.Add(e)
        Next
    End Sub

    Public Sub Leer(ByRef e As Ediciones)
        Dim col As Collection : Dim aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT * FROM Ediciones WHERE Torneo='" & e.torneo.idTorneo & "';")
        Dim j As Jugadora = New Jugadora()
        For Each aux In col
            j.idJugadora = aux(3)
            e.ganadora = j
            e.anualidad = aux(1)
        Next
    End Sub

    Public Function Insertar(ByVal e As Ediciones) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("INSERT INTO Ediciones VALUES ('" & e.anualidad & "', '" & e.torneo.idTorneo & "';" & e.ganadora.idJugadora & "';")
    End Function

    'Public Function Actualizar(ByVal e As Ediciones) As Integer
    '    Return AgenteBD.ObtenerAgente.Modificar("UPDATE INTO Ediciones VALUES ('" & e.anualidad & "', '" & e.torneo.idTorneo & "';" & e.ganadora.idJugadora & "';")
    'End Function

    'Public Function Borrar(ByVal e As Ediciones) As Integer
    '    Return AgenteBD.ObtenerAgente.Modificar("DELETE INTO Ediciones VALUES ('" & e.anualidad & "', '" & e.torneo & "';" & e.ganadora & "';")
    'End Function
End Class
