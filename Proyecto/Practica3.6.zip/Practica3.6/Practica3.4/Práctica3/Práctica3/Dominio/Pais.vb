﻿Public Class Pais
    Private _idPais As Char()
    Private _NombrePais As String
    Public ReadOnly Property pDAO As PaisDAO

    Public Property idPais As Char()
        Get
            Return _idPais
        End Get
        Set(value As Char())
            _idPais = value
        End Set
    End Property
    Public Property NombrePais As String
        Get
            Return _NombrePais
        End Get
        Set(value As String)
            _NombrePais = value
        End Set
    End Property
    Public Sub New()
        Me.pDAO = New PaisDAO
    End Sub
    Public Sub New(id As Char())
        Me.pDAO = New PaisDAO
        Me.idPais = id
        Me.LeerPais()
    End Sub
    Public Sub New(nombre As String)
        Me.pDAO = New PaisDAO
        Me.NombrePais = nombre
    End Sub

    Public Sub LeerTodas()
        Me.pDAO.LeerTodas()
    End Sub
    Public Sub LeerPais()
        Me.pDAO.Leer(Me)
    End Sub
    Public Sub LeerPaisNombre()
        Me.pDAO.LeerNombre(Me)
    End Sub
    Public Function InsertarPais() As Integer
        Return Me.pDAO.Insertar(Me)
    End Function

    Public Function ActualizarPais() As Integer
        Return Me.pDAO.Actualizar(Me)
    End Function

    Public Function BorrarPais() As Integer
        Return Me.pDAO.Borrar_Nombre(Me)
    End Function

End Class
