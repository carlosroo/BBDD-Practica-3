﻿Public Class Torneo
    Private _idTorneo As Integer
    Private _NombreTorneo As String
    Private _CiudadTorneo As String
    Private _PaisTorneo As Pais

    Public ReadOnly Property tDAO As TorneoDAO

    Public Property idTorneo As Integer
        Get
            Return _idTorneo
        End Get
        Set(value As Integer)
            _idTorneo = value
        End Set
    End Property
    Public Property NombreTorneo As String
        Get
            Return _NombreTorneo
        End Get
        Set(value As String)
            _NombreTorneo = value
        End Set
    End Property
    Public Property PaisTorneo As Pais
        Get
            Return _PaisTorneo
        End Get
        Set(value As Pais)
            _PaisTorneo = value
        End Set
    End Property
    Public Property CiudadTorneo As String
        Get
            Return _CiudadTorneo
        End Get
        Set(value As String)
            _CiudadTorneo = value
        End Set
    End Property
    Public Sub New()
        Me.tDAO = New TorneoDAO
    End Sub
    Public Sub New(id As Integer)
        Me.tDAO = New TorneoDAO
        Me.idTorneo = id
        Me.LeerTorneo()
    End Sub
    Public Sub LeerTodas()
        Me.tDAO.LeerTodas()
    End Sub
    Public Sub LeerTorneo()
        Me.tDAO.Leer(Me)
    End Sub
    Public Function InsertarTorneo() As Integer
        Return Me.tDAO.Insertar(Me)
    End Function

    Public Function ActualizarTorneo() As Integer
        Return Me.tDAO.Actualizar(Me)
    End Function

    Public Function BorrarTorneo() As Integer
        Return Me.tDAO.Borrar(Me)
    End Function
End Class
