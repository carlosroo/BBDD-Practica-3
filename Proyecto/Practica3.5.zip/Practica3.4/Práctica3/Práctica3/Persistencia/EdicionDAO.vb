﻿Public Class EdicionDAO
    Public ReadOnly Property tenis As Collection

    Public Sub New()
        Me.tenis = New Collection
    End Sub

    Public Sub LeerTodas()
        Dim e As Ediciones
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente().Leer("SELECT * FROM Ediciones ORDER BY Anualidad")
        For Each aux In col
            e = New Ediciones(aux(1).ToString)
            p.Anualidad = aux(2).ToString
            p.FechaNacimiento = aux(3).ToString
            p.Puntos = aux(4).ToString
            p.Pais = aux(5).ToString
            Me.tenis.Add(p)
        Next
    End Sub

    Public Sub Leer(ByRef p As Jugadora)
        Dim col As Collection : Dim aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT * FROM Jugadoras WHERE idJugadora='" & p.idJugadora & "';")
        For Each aux In col
            p.Nombre = aux(2).ToString
        Next
    End Sub

    Public Function Insertar(ByVal p As Jugadora) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("INSERT INTO Jugadoras VALUES ('" & p.idJugadora & "', '" & p.Nombre & "');")
    End Function

    Public Function Actualizar(ByVal p As Jugadora) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("UPDATE Jugadoras SET NombreJugadora='" & p.Nombre & "' WHERE idJugadora='" & p.idJugadora & "';")
    End Function

    Public Function Borrar(ByVal p As Jugadora) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("DELETE FROM Jugadoras WHERE idJugadora='" & p.idJugadora & "';")
    End Function
End Class

