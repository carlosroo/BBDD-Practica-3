-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tenis
-- ------------------------------------------------------
-- Server version	5.7.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ediciones`
--

DROP TABLE IF EXISTS `ediciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ediciones` (
  `Anualidad` int(11) NOT NULL,
  `Torneo` int(11) NOT NULL,
  `Ganadora` int(11) NOT NULL,
  PRIMARY KEY (`Anualidad`,`Torneo`),
  KEY `FK_Edi_Tou_idx` (`Torneo`),
  KEY `FK_Edi_Pla_idx` (`Ganadora`),
  CONSTRAINT `FK_Edi_Pla` FOREIGN KEY (`Ganadora`) REFERENCES `jugadoras` (`idJugadora`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_Edi_Tou` FOREIGN KEY (`Torneo`) REFERENCES `torneos` (`idTorneo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ediciones`
--

LOCK TABLES `ediciones` WRITE;
/*!40000 ALTER TABLE `ediciones` DISABLE KEYS */;
INSERT INTO `ediciones` VALUES (2010,1,2),(2010,13,2),(1991,9,5),(2021,9,5),(1990,1,6),(2020,7,8),(2028,9,10),(1993,2,11),(2024,2,11),(2022,9,12),(2003,14,13),(2012,2,13),(2022,4,14),(2003,2,15),(2008,14,15),(2021,6,16);
/*!40000 ALTER TABLE `ediciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `juegos`
--

DROP TABLE IF EXISTS `juegos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `juegos` (
  `Jugadora` int(11) NOT NULL,
  `Partido` int(11) NOT NULL,
  `Set1` int(11) NOT NULL,
  `Set2` int(11) NOT NULL,
  `Set3` varchar(45) DEFAULT NULL,
  KEY `FK_Pla_Mat_idx` (`Partido`),
  KEY `FK_Pla_Pla_idx` (`Jugadora`),
  CONSTRAINT `FK_Pla_Mat` FOREIGN KEY (`Partido`) REFERENCES `partidos` (`idpartido`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_Pla_Pla` FOREIGN KEY (`Jugadora`) REFERENCES `jugadoras` (`idJugadora`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `juegos`
--

LOCK TABLES `juegos` WRITE;
/*!40000 ALTER TABLE `juegos` DISABLE KEYS */;
INSERT INTO `juegos` VALUES (3,0,2,1,'0'),(5,0,6,6,'0'),(14,1,6,6,'0'),(13,1,3,3,'0'),(10,2,3,6,'3'),(11,2,6,2,'6'),(9,3,6,0,'1'),(6,3,4,6,'6'),(5,4,3,6,'6'),(6,4,6,2,'1'),(14,5,3,6,'4'),(11,5,6,1,'6'),(5,6,4,1,'0'),(11,6,6,6,'0'),(15,7,4,6,'6'),(12,7,6,2,'4'),(14,8,0,0,'0'),(1,8,6,6,'0'),(16,9,6,6,'0'),(5,9,3,0,'0'),(11,10,6,6,'0'),(7,10,1,4,'0'),(15,11,2,6,'6'),(11,11,6,0,'3'),(1,12,6,1,'1'),(16,12,2,6,'6'),(15,13,6,6,'0'),(16,13,2,2,'0'),(15,14,1,1,'0'),(13,14,6,6,'0'),(16,15,6,3,'6'),(5,15,4,6,'0'),(14,16,3,4,'0'),(7,16,6,6,'0'),(11,17,6,2,'2'),(4,17,2,6,'6'),(13,18,2,6,'6'),(4,18,6,2,'0'),(16,19,6,6,'0'),(7,19,4,1,'0'),(13,20,6,6,'0'),(16,20,2,2,'0'),(3,21,6,0,'3'),(2,21,3,6,'6'),(16,22,1,6,'6'),(5,22,6,3,'3'),(14,23,4,6,'6'),(6,23,6,1,'0'),(11,24,6,6,'0'),(7,24,0,2,'0'),(2,25,2,0,'0'),(11,25,6,6,'0'),(16,26,6,6,'0'),(14,26,3,1,'0'),(11,27,6,2,'6'),(16,27,3,6,'3'),(15,28,6,6,'0'),(12,28,2,1,'0'),(16,29,6,0,'0'),(2,29,0,6,'6'),(4,30,6,3,'6'),(13,30,1,6,'3'),(7,31,6,6,'0'),(9,31,0,1,'0'),(15,32,1,6,'6'),(7,32,6,2,'1'),(2,33,6,6,'0'),(4,33,2,4,'0'),(15,34,3,1,'0'),(2,34,6,6,'0'),(11,35,0,2,'0'),(15,35,6,6,'0'),(14,36,0,3,'0'),(5,36,6,6,'0'),(4,37,6,6,'0'),(2,37,0,1,'0'),(10,38,0,6,'4'),(6,38,6,1,'6'),(15,39,2,4,'0'),(6,39,6,6,'0'),(5,40,3,1,'0'),(4,40,6,6,'0'),(6,41,6,0,'6'),(4,41,2,6,'2'),(16,42,2,1,'0'),(15,42,6,6,'0'),(6,43,6,6,'0'),(12,43,3,3,'0'),(10,44,3,6,'3'),(5,44,6,2,'6'),(7,45,6,0,'1'),(13,45,4,6,'6'),(15,46,3,6,'6'),(13,46,6,2,'1'),(6,47,3,6,'4'),(5,47,6,1,'6'),(15,48,4,1,'0'),(5,48,6,6,'0'),(16,49,4,6,'6'),(15,49,6,2,'4'),(3,50,0,0,'0'),(12,50,6,6,'0'),(11,51,6,6,'0'),(1,51,3,0,'0'),(4,52,6,6,'0'),(10,52,1,4,'0'),(16,53,2,6,'6'),(4,53,6,0,'3'),(12,54,6,1,'1'),(11,54,2,6,'6'),(16,55,6,6,'0'),(11,55,2,2,'0'),(11,56,1,1,'0'),(15,56,6,6,'0'),(4,57,6,3,'6'),(12,57,4,6,'0'),(10,58,3,4,'0'),(2,58,6,6,'0'),(7,59,6,2,'2'),(13,59,2,6,'6'),(15,60,2,6,'6'),(13,60,6,2,'0'),(4,61,6,6,'0'),(2,61,4,1,'0'),(15,62,6,6,'0'),(4,62,2,2,'0'),(16,63,6,0,'3'),(15,63,3,6,'6'),(11,64,1,6,'6'),(8,64,6,3,'3'),(4,65,4,6,'6'),(9,65,6,1,'0'),(14,66,6,6,'0'),(10,66,0,2,'0'),(15,67,2,0,'0'),(14,67,6,6,'0'),(11,68,6,6,'0'),(4,68,3,1,'0'),(14,69,6,2,'6'),(11,69,3,6,'3'),(3,70,6,6,'0'),(15,70,2,1,'0'),(14,71,6,0,'0'),(12,71,0,6,'6'),(4,72,6,3,'6'),(9,72,1,6,'3'),(5,73,6,6,'0'),(13,73,0,1,'0'),(3,74,1,6,'6'),(5,74,6,2,'1'),(12,75,6,6,'0'),(4,75,2,4,'0'),(3,76,3,1,'0'),(12,76,6,6,'0'),(3,77,0,2,'0'),(12,77,6,6,'0'),(4,78,0,3,'0'),(13,78,6,6,'0'),(14,79,6,6,'0'),(7,79,0,1,'0'),(6,80,0,6,'4'),(5,80,6,1,'6'),(12,81,2,4,'0'),(5,81,6,6,'0'),(13,82,3,1,'0'),(14,82,6,6,'0'),(5,83,6,0,'6'),(14,83,2,6,'2'),(14,84,2,6,'6'),(12,84,6,2,'3'),(4,85,6,1,'6'),(8,85,3,6,'1'),(6,86,6,6,'0'),(9,86,2,2,'0'),(10,87,6,6,'0'),(13,87,4,0,'0'),(14,88,3,3,'0'),(10,88,6,6,'0'),(4,89,6,6,'0'),(6,89,4,4,'0'),(10,90,6,1,'6'),(4,90,0,6,'0'),(14,91,6,6,'0'),(15,91,0,3,'0'),(10,92,2,6,'3'),(12,92,6,2,'6'),(7,93,6,0,'3'),(1,93,4,6,'6'),(2,94,6,6,'0'),(8,94,2,1,'0'),(14,95,4,2,'0'),(2,95,6,6,'0'),(12,96,1,6,'0'),(1,96,6,2,'6'),(2,97,1,6,'6'),(1,97,6,0,'2'),(4,98,2,6,'6'),(15,98,6,4,'1'),(3,99,6,0,'4'),(12,99,1,6,'6'),(6,100,4,2,'0'),(8,100,6,6,'0'),(13,101,0,3,'0'),(9,101,6,6,'0'),(4,102,6,6,'0'),(9,102,0,1,'0'),(12,103,0,3,'0'),(8,103,6,6,'0'),(4,104,1,4,'0'),(8,104,6,6,'0'),(14,105,2,1,'0'),(12,105,6,6,'0'),(11,106,6,6,'0'),(1,106,3,3,'0'),(10,107,3,6,'3'),(13,107,6,2,'6'),(2,108,6,0,'1'),(7,108,4,6,'6'),(12,109,3,6,'6'),(7,109,6,2,'1'),(11,110,3,6,'4'),(13,110,6,1,'6'),(12,111,4,1,'0'),(13,111,6,6,'0');
/*!40000 ALTER TABLE `juegos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jugadoras`
--

DROP TABLE IF EXISTS `jugadoras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jugadoras` (
  `idJugadora` int(11) NOT NULL AUTO_INCREMENT,
  `NombreJugadora` varchar(45) NOT NULL,
  `FechaNacimientoJugadora` date NOT NULL,
  `PuntosJugadora` varchar(45) NOT NULL,
  `PaisJugadora` char(3) NOT NULL,
  PRIMARY KEY (`idJugadora`),
  UNIQUE KEY `NombreJugadora_UNIQUE` (`NombreJugadora`),
  KEY `FK_Pla_Cou_idx` (`PaisJugadora`),
  CONSTRAINT `FK_Pla_Cou` FOREIGN KEY (`PaisJugadora`) REFERENCES `paises` (`idPais`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jugadoras`
--

LOCK TABLES `jugadoras` WRITE;
/*!40000 ALTER TABLE `jugadoras` DISABLE KEYS */;
INSERT INTO `jugadoras` VALUES (1,'Maria The rock','2000-01-01','565','ESP'),(2,'Abella peligro','2000-02-02','765','FRC'),(3,'Adriana Chechik','2022-04-05','955','ESP'),(4,'Aletta Oceano','2022-04-05','1005','ESP'),(5,'Alexis Fawx','2022-04-05','835','FRC'),(6,'Alina Li','2022-04-05','800','FRC'),(7,'apolonia the rock','2022-04-05','760','FRC'),(8,'Asa Akira','2022-04-05','755','FRC'),(9,'Brandy Amor','2022-04-05','715','FRC'),(10,'Shasa Gris','2022-04-19','865','ESP'),(11,'Lana Roda','2022-04-19','960','ESP'),(12,'Tuya Khalifa','2022-04-19','1855','ESP'),(13,'Nicol Aniston','2022-04-19','835','ESP'),(14,'Alexis Tejas','2022-04-19','1000','ESP'),(15,'Alexa Flexibilidad','2022-04-19','1285','ESP'),(16,'Nekane','2022-04-19','990','ESP');
/*!40000 ALTER TABLE `jugadoras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paises`
--

DROP TABLE IF EXISTS `paises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paises` (
  `idPais` char(3) NOT NULL,
  `NombrePais` varchar(45) NOT NULL,
  PRIMARY KEY (`idPais`),
  UNIQUE KEY `CountryName_UNIQUE` (`NombrePais`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paises`
--

LOCK TABLES `paises` WRITE;
/*!40000 ALTER TABLE `paises` DISABLE KEYS */;
INSERT INTO `paises` VALUES ('AND','Andorra '),('CHN','China'),('ESP','España'),('EEU','Estados Unidos'),('FIL','Filipinas'),('FRC','Francia'),('IND','India'),('ING','Inglaterra'),('ITA','Italia'),('JAP','Japon'),('MAD','Madagascar'),('MEX','Mexico'),('MON','Monaco'),('POR','Portugal'),('RUS','Rusia');
/*!40000 ALTER TABLE `paises` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partidos`
--

DROP TABLE IF EXISTS `partidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partidos` (
  `idpartido` int(11) NOT NULL,
  `Anualidad` int(11) NOT NULL,
  `Torneo` int(11) NOT NULL,
  `Ganadora` int(11) NOT NULL,
  `Ronda` char(1) NOT NULL,
  PRIMARY KEY (`idpartido`),
  KEY `KF_Mat_Edi_idx` (`Anualidad`,`Torneo`),
  KEY `FK_Mat_Play_idx` (`Ganadora`),
  CONSTRAINT `FK_Mat_Edi` FOREIGN KEY (`Anualidad`, `Torneo`) REFERENCES `ediciones` (`Anualidad`, `Torneo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_Mat_Play` FOREIGN KEY (`Ganadora`) REFERENCES `jugadoras` (`idJugadora`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partidos`
--

LOCK TABLES `partidos` WRITE;
/*!40000 ALTER TABLE `partidos` DISABLE KEYS */;
INSERT INTO `partidos` VALUES (0,1993,2,5,'C'),(1,1993,2,14,'C'),(2,1993,2,11,'C'),(3,1993,2,6,'C'),(4,1993,2,5,'S'),(5,1993,2,11,'S'),(6,1993,2,11,'F'),(7,2003,2,15,'C'),(8,2003,2,1,'C'),(9,2003,2,16,'C'),(10,2003,2,11,'C'),(11,2003,2,15,'S'),(12,2003,2,16,'S'),(13,2003,2,15,'F'),(14,2012,2,13,'C'),(15,2012,2,16,'C'),(16,2012,2,7,'C'),(17,2012,2,4,'C'),(18,2012,2,13,'S'),(19,2012,2,16,'S'),(20,2012,2,13,'F'),(21,2024,2,2,'C'),(22,2024,2,16,'C'),(23,2024,2,14,'C'),(24,2024,2,11,'C'),(25,2024,2,11,'S'),(26,2024,2,16,'S'),(27,2024,2,11,'F'),(28,2010,1,15,'C'),(29,2010,1,2,'C'),(30,2010,1,4,'C'),(31,2010,1,7,'C'),(32,2010,1,15,'S'),(33,2010,1,2,'S'),(34,2010,1,2,'F'),(35,1990,1,15,'C'),(36,1990,1,5,'C'),(37,1990,1,4,'C'),(38,1990,1,6,'C'),(39,1990,1,6,'S'),(40,1990,1,4,'S'),(41,1990,1,6,'F'),(42,2021,9,15,'C'),(43,2021,9,6,'C'),(44,2021,9,5,'C'),(45,2021,9,13,'C'),(46,2021,9,15,'S'),(47,2021,9,5,'S'),(48,2021,9,5,'F'),(49,2021,6,16,'C'),(50,2021,6,12,'C'),(51,2021,6,11,'C'),(52,2021,6,4,'C'),(53,2021,6,16,'S'),(54,2021,6,11,'S'),(55,2021,6,16,'F'),(56,2008,14,15,'C'),(57,2008,14,4,'C'),(58,2008,14,2,'C'),(59,2008,14,13,'C'),(60,2008,14,15,'S'),(61,2008,14,4,'S'),(62,2008,14,15,'F'),(63,2022,4,15,'C'),(64,2022,4,11,'C'),(65,2022,4,4,'C'),(66,2022,4,14,'C'),(67,2022,4,14,'S'),(68,2022,4,11,'S'),(69,2022,4,14,'F'),(70,2022,9,3,'C'),(71,2022,9,12,'C'),(72,2022,9,4,'C'),(73,2022,9,5,'C'),(74,2022,9,3,'S'),(75,2022,9,12,'S'),(76,2022,9,12,'F'),(77,1991,9,12,'C'),(78,1991,9,13,'C'),(79,1991,9,14,'C'),(80,1991,9,5,'C'),(81,1991,9,5,'S'),(82,1991,9,14,'S'),(83,1991,9,5,'F'),(84,2028,9,14,'C'),(85,2028,9,4,'C'),(86,2028,9,6,'C'),(87,2028,9,10,'C'),(88,2028,9,10,'S'),(89,2028,9,4,'S'),(90,2028,9,10,'F'),(91,2010,13,14,'C'),(92,2010,13,12,'C'),(93,2010,13,1,'C'),(94,2010,13,2,'C'),(95,2010,13,2,'S'),(96,2010,13,1,'S'),(97,2010,13,2,'F'),(98,2020,7,4,'C'),(99,2020,7,12,'C'),(100,2020,7,8,'C'),(101,2020,7,9,'C'),(102,2020,7,4,'S'),(103,2020,7,8,'S'),(104,2020,7,8,'F'),(105,2003,14,12,'C'),(106,2003,14,11,'C'),(107,2003,14,13,'C'),(108,2003,14,7,'C'),(109,2003,14,12,'S'),(110,2003,14,13,'S'),(111,2003,14,13,'F');
/*!40000 ALTER TABLE `partidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `torneos`
--

DROP TABLE IF EXISTS `torneos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `torneos` (
  `idTorneo` int(11) NOT NULL,
  `NombreTorneo` varchar(45) NOT NULL,
  `CiudadTorneo` varchar(45) NOT NULL,
  `PaisTorneo` char(3) NOT NULL,
  PRIMARY KEY (`idTorneo`),
  UNIQUE KEY `NombreTorneo_UNIQUE` (`NombreTorneo`),
  KEY `FK_Tou_Cou_idx` (`PaisTorneo`),
  CONSTRAINT `FK_Tou_Cou` FOREIGN KEY (`PaisTorneo`) REFERENCES `paises` (`idPais`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `torneos`
--

LOCK TABLES `torneos` WRITE;
/*!40000 ALTER TABLE `torneos` DISABLE KEYS */;
INSERT INTO `torneos` VALUES (1,'Gran Prix','Madrid','ESP'),(2,'Roland Garros','Moscu','CHN'),(3,'Wilvemdon','Barcelona','ESP'),(4,'SuperTenis','Marsella','FRC'),(5,'ATP CUP','Pekin','CHN'),(6,'MUTUA MADRID OPEN','Madrid','ESP'),(7,'Limeba Open','Pekin','CHN'),(8,'Wissenhof','Mexico DC','MEX'),(9,'Rolex Monte-Carlo','Monte Carlo','MON'),(10,'Barcelona Open','Barcelona','ESP'),(11,'Serbia Open','Roma','ITA'),(12,'BMW Open','Nueva Deli','IND'),(13,'Citi Open','Moscu','RUS'),(14,'US Open','Washintong','EEU'),(15,'China Open','Tokyo','JAP');
/*!40000 ALTER TABLE `torneos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-25  4:46:35
