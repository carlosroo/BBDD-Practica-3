﻿Public Class Form1

    Public Property j As Jugadora
    Public Property p As Pais
    Public Property t As Torneo
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActualizarPaises()
        ActualizarListaTorneo()
        ActualizarListaJugadoras()

    End Sub

    Private Sub ActualizarPaises()
        Me.p = New Pais
        Dim paux As Pais
        Dim aux As String
        SelectPais.Items.Clear()
        SelectPaisTorneo.Items.Clear()
        lista_paises.Items.Clear()
        Try
            Me.p.LeerTodas()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End Try
        For Each paux In Me.p.pDAO.paises
            aux = New String(paux.idPais)
            SelectPais.Items.Add(aux)
            SelectPaisTorneo.Items.Add(aux)
            Me.lista_paises.Items.Add(paux.NombrePais)
        Next
    End Sub

    Private Sub ActualizarListaTorneo()
        SeleccionarTorneo.Items.Clear()
        Lista_Torneos.Items.Clear()
        Dim taux As Torneo
        Me.t = New Torneo
        Try
            Me.t.LeerTodas()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End Try
        For Each taux In Me.t.tDAO.torneos
            Me.Lista_Torneos.Items.Add(taux.NombreTorneo)
            Me.SeleccionarTorneo.Items.Add(taux.NombreTorneo)
        Next
    End Sub


    Private Sub ActualizarListaJugadoras()
        Dim jaux As Jugadora
        Me.j = New Jugadora
        Me.p = New Pais
        Me.t = New Torneo
        Me.Lista_jugadoras.Items.Clear()

        Try
            Me.j.LeerTodas()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End Try
        For Each jaux In Me.j.jDAO.jugadoras
            Me.Lista_jugadoras.Items.Add(jaux.NombreJugadora)
        Next

    End Sub
    Private Function formatoFecha(fechaInicial As String) As String
        Dim fechaux As String()
        fechaux = Split(fechaInicial, "/")
        Return fechaux(2) + "-" + fechaux(1) + "-" + fechaux(0)
    End Function
    Private Sub boton_insertarjugadora_Click(sender As Object, e As EventArgs) Handles boton_insertarjugadora.Click
        If Me.nombre_textbox.Text <> String.Empty And Me.SelectPais.Text <> String.Empty Then
            j = New Jugadora()
            j.LeerTodas()
            If j.jDAO.jugadoras.Count = 0 Then
                j.idJugadora = 1
            Else
                j.idJugadora = j.MaxID() + 1
            End If
            j.NombreJugadora = nombre_textbox.Text
            Dim auxPaisString As Char()
            Dim auxPais As Pais
            auxPaisString = SelectPais.Text.ToCharArray()
            auxPais = New Pais(auxPaisString)
            j.PaisJugadora = auxPais
            Dim fechaux As String()
            fechaux = Split(FechaNacimiento.Value.ToString)
            j.FechaNacimientoJugadora = formatoFecha(fechaux(0))
            j.PuntosJugadora = 0

            Try
                If j.InsertarJugadora() <> 1 Then
                    MessageBox.Show("INSERT return <> 1", String.Empty, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub

            End Try
            Me.Lista_jugadoras.Items.Add(j.NombreJugadora)
        End If
    End Sub

    Private Sub Boton_Insertar_Pais_Click(sender As Object, e As EventArgs) Handles Boton_Insertar_Pais.Click
        If Me.NombrePais_Text.Text <> String.Empty Then
            p = New Pais()
            p.NombrePais = NombrePais_Text.Text
            Dim nombreaux As String = UCase(p.NombrePais)
            Dim aux2 As String = nombreaux.Substring(0, 3)
            p.idPais = aux2
            Dim aux As String
            aux = New String(p.idPais)
            Try
                If p.InsertarPais() <> 1 Then
                    MessageBox.Show("INSERT return <> 1", String.Empty, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub

            End Try
            Me.lista_paises.Items.Add(p.NombrePais)
            SelectPais.Items.Add(aux)
            ActualizarPaises()
        End If
    End Sub

    Private Sub Boton_Insertar_Torneo_Click(sender As Object, e As EventArgs) Handles Boton_Insertar_Torneo.Click
        If Me.NombreTorneo_Text.Text <> String.Empty And Me.CiudadTorneo_Text.Text <> String.Empty And Me.SelectPaisTorneo.Text <> String.Empty Then
            t = New Torneo()
            t.LeerTodas()
            If t.tDAO.torneos.Count = 0 Then
                t.idTorneo = 1
            Else
                t.idTorneo = t.MaxID() + 1
            End If
            t.NombreTorneo = NombreTorneo_Text.Text
            t.CiudadTorneo = CiudadTorneo_Text.Text
            Dim auxPaisTorneo As Pais
            Dim auxChar As Char() = SelectPaisTorneo.Text.ToCharArray()
            auxPaisTorneo = New Pais(auxChar)
            t.PaisTorneo = auxPaisTorneo
            Try
                If t.InsertarTorneo() <> 1 Then
                    MessageBox.Show("INSERT return <> 1", String.Empty, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub

            End Try
            ActualizarListaTorneo()
        End If
    End Sub

    Private Sub idjugadoras_textbox_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub idPais_Text_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub BotonBorrarJugadora_Click(sender As Object, e As EventArgs) Handles BotonBorrarJugadora.Click
        If Lista_jugadoras.SelectedItem IsNot Nothing Then
            Try
                Dim jugadora As Jugadora = New Jugadora(Lista_jugadoras.SelectedItem.ToString)
                Lista_jugadoras.Items.Remove(jugadora.NombreJugadora)
                jugadora.Borrar_NombreJugadora()

            Catch ex As Exception

            End Try
            LimpiarJugadoras()
        End If

    End Sub

    Private Sub Boton_Borrar_Pais_Click(sender As Object, e As EventArgs) Handles Boton_Borrar_Pais.Click
        If lista_paises.SelectedItem IsNot Nothing Then
            Try
                Dim p As Pais = New Pais(lista_paises.SelectedItem.ToString)
                lista_paises.Items.Remove(lista_paises.SelectedItem)
                p.BorrarPais()
                SelectPais.Items.Clear()
                ActualizarPaises()
            Catch ex As Exception

            End Try
            LimpiarPais()
        End If
    End Sub

    Private Sub BotonBorrar_Torneo_Click(sender As Object, e As EventArgs) Handles BotonBorrar_Torneo.Click
        If Lista_Torneos.SelectedItem IsNot Nothing Then
            Try
                Dim t As Torneo = New Torneo(Lista_Torneos.SelectedItem.ToString)
                Lista_Torneos.Items.Remove(Lista_Torneos.SelectedItem)
                t.BorrarTorneo_Nombre()
                ActualizarListaTorneo()
            Catch ex As Exception

            End Try
            LimpiarTorneos()
        End If

    End Sub

    Private Sub Lista_Torneos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Lista_Torneos.SelectedIndexChanged
        If Lista_Torneos.SelectedItem IsNot Nothing Then
            Dim torneo As Torneo = New Torneo(Lista_Torneos.SelectedItem.ToString)
            torneo.LeerDatosTorneo()
            NombreTorneo_Text.Text = torneo.NombreTorneo
            CiudadTorneo_Text.Text = torneo.CiudadTorneo
            SelectPaisTorneo.Text = torneo.PaisTorneo.idPais
            LabelidTorneo.Text = torneo.idTorneo
        End If
    End Sub
    Private Sub lista_paises_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lista_paises.SelectedIndexChanged
        If lista_paises.SelectedItem IsNot Nothing Then
            Dim p As Pais = New Pais(lista_paises.SelectedItem.ToString)
            p.LeerPaisNombre()
            Dim aux As New String(p.idPais)
            Labelid.Text = aux
            NombrePais_Text.Text = p.NombrePais
        End If
    End Sub
    Private Sub ActualizarTorneos_Click(sender As Object, e As EventArgs) Handles ActualizarTorneos.Click
        If Me.NombreTorneo_Text.Text <> String.Empty And Me.CiudadTorneo_Text.Text <> String.Empty And Me.SelectPaisTorneo.Text <> String.Empty And Lista_Torneos.SelectedItem IsNot Nothing Then
            Dim t As Torneo = New Torneo(Lista_Torneos.SelectedItem.ToString)
            t.LeerDatosTorneo()
            Dim nuevoNombre As String
            nuevoNombre = NombreTorneo_Text.Text
            t.NombreTorneo = nuevoNombre
            t.CiudadTorneo = CiudadTorneo_Text.Text
            Dim auxPaisTorneo As Pais
            Dim auxChar As Char() = SelectPaisTorneo.Text.ToCharArray()
            auxPaisTorneo = New Pais(auxChar)
            t.PaisTorneo = auxPaisTorneo
            t.ActualizarTorneo()
            ActualizarListaTorneo()
        End If
    End Sub

    Private Sub Boton_Actualizar_Pais_Click(sender As Object, e As EventArgs) Handles Boton_Actualizar_Pais.Click
        If Me.NombrePais_Text.Text <> String.Empty And lista_paises.SelectedItem IsNot Nothing Then
            Dim p As Pais = New Pais(lista_paises.SelectedItem.ToString)
            p.LeerDatosPais()
            Dim nuevoPais As String = NombrePais_Text.Text
            p.NombrePais = nuevoPais
            p.ActualizarPais()
            ActualizarPaises()

        End If
    End Sub

    Private Function elegirJugadoras(cantidad As Integer) As Integer()
        Randomize()
        Dim i As Integer
        Dim j As Integer
        j = 0
        Dim n As Integer
        Dim vector(7) As Integer
        Dim repetido As Boolean
        repetido = False

        For j = 0 To 7 Step 1

            Do
                repetido = False
                n = Int((cantidad - 1 + 1) * Rnd() + 1)
                For i = 0 To 7 Step 1
                    If n = vector(i) Then
                        repetido = True
                        Exit For

                    End If
                Next

            Loop While (repetido)
            vector(j) = n
        Next
        Return vector
    End Function

    Private Sub Boton_InsertarEdicion_Click(sender As Object, e As EventArgs) Handles Boton_InsertarEdicion.Click
        If Me.SeleccionarTorneo.Text <> String.Empty And Me.AnoTorneo.Text <> String.Empty And
            IsNumeric(Me.AnoTorneo.Text) And Int(Me.AnoTorneo.Text) >= 0 Then

            Dim j As New Jugadora
            j.LeerTodas()
            If j.jDAO.jugadoras.Count < 8 Then
                MessageBox.Show("No hay suficientes jugadoras para realizar el Torneo")
                Exit Sub
            End If
            Dim edi As New Ediciones
            edi.anualidad = Int(AnoTorneo.Text)
            Dim t As New Torneo(SeleccionarTorneo.Text.ToString)
            t.LeerDatosTorneo()
            edi.torneo = t
            Dim participantes(7) As Integer
            participantes = elegirJugadoras(j.jDAO.jugadoras.Count)
            Array.Sort(participantes)
            Dim vectorJugadorasCuartos(7) As Jugadora
            vectorJugadorasCuartos = j.LeerRandom(participantes)
            incrementarPuntos(vectorJugadorasCuartos, 10)
            escribirCuartos(vectorJugadorasCuartos)

            edi.ganadora = vectorJugadorasCuartos(0)
            Try
                If edi.InsertarEdicion() <> 1 Then
                    MessageBox.Show("INSERT return <> 1", String.Empty, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub

            End Try
            Dim partidoAUX As Partido
            partidoAUX = New Partido()
            partidoAUX.anualidad = edi.anualidad
            partidoAUX.torneo = t
            partidoAUX.ronda = "C"
            Dim vectorPartidosCuartos(3) As Partido
            Dim ganadorasCuartos(3) As Jugadora
            For i = 0 To 3 Step 1
                ganadorasCuartos(i) = SimularPartido(vectorJugadorasCuartos(2 * i), vectorJugadorasCuartos(2 * i + 1), edi, "C")
                partidoAUX.ganadora = ganadorasCuartos(i)
                vectorPartidosCuartos(i) = New Partido(edi.leerIDPartido(partidoAUX))
            Next
            escribirSemis(ganadorasCuartos)
            incrementarPuntos(ganadorasCuartos, 15)

            Dim ganadorasSemis(1) As Jugadora
            For i = 0 To 1 Step 1
                ganadorasSemis(i) = SimularPartido(ganadorasCuartos(2 * i), ganadorasCuartos(2 * i + 1), edi, "S")
            Next
            escribirFinal(ganadorasSemis)
            incrementarPuntos(ganadorasSemis, 25)

            Dim ganadora As Jugadora
            ganadora = SimularPartido(ganadorasSemis(0), ganadorasSemis(1), edi, "F")
            escribirGanadora(ganadora)
            ganadora.LeerDatosJugadora()
            ganadora.PuntosJugadora += 50
            ganadora.ActualizarJugadora()
            edi.ganadora = ganadora
            edi.ActualizarEdicion()
        End If
    End Sub

    Private Sub escribirCuartos(ByRef v() As Jugadora)
        Cuartos1.Text = v(7).NombreJugadora
        Cuartos2.Text = v(6).NombreJugadora
        Cuartos3.Text = v(5).NombreJugadora
        Cuartos4.Text = v(4).NombreJugadora
        Cuartos5.Text = v(3).NombreJugadora
        Cuartos6.Text = v(2).NombreJugadora
        Cuartos7.Text = v(1).NombreJugadora
        Cuartos8.Text = v(0).NombreJugadora
    End Sub
    Private Sub escribirSemis(ByRef v() As Jugadora)
        Semis1.Text = v(3).NombreJugadora
        Semis2.Text = v(2).NombreJugadora
        Semis3.Text = v(1).NombreJugadora
        Semis4.Text = v(0).NombreJugadora
    End Sub
    Private Sub escribirFinal(ByRef v() As Jugadora)
        Final1.Text = v(1).NombreJugadora
        Final2.Text = v(0).NombreJugadora
    End Sub

    Private Sub escribirGanadora(ByRef v As Jugadora)
        Ganadora_TextBox.Text = v.NombreJugadora
    End Sub

    Private Sub Lista_jugadoras_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Lista_jugadoras.SelectedIndexChanged
        If Lista_jugadoras.SelectedItem IsNot Nothing Then
            Dim jug As Jugadora = New Jugadora(Lista_jugadoras.SelectedItem.ToString)
            jug.LeerDatosJugadora()
            idText.Text = jug.idJugadora
            puntosJug.Text = jug.PuntosJugadora
            nombre_textbox.Text = jug.NombreJugadora
            SelectPais.Text = jug.PaisJugadora.NombrePais
            FechaNacimiento.Value = jug.FechaNacimientoJugadora
        End If
    End Sub


    Private Function SimularPartido(p1 As Jugadora, p2 As Jugadora, edicion As Ediciones, ronda As Char) As Jugadora
        Dim partido = New Partido
        Dim juego1 = New Juegos
        Dim juego2 = New Juegos

        juego1.jugadora = New Jugadora(p1.idJugadora)
        juego2.jugadora = New Jugadora(p2.idJugadora)

        partido.torneo = New Torneo(edicion.torneo.idTorneo)
        partido.anualidad = edicion.anualidad
        partido.ronda = ronda
        edicion.LeerTodosPartidos()
        If edicion.eDAO.partidos.Count = 0 Then
            partido.idPartido = 1
        Else
            partido.idPartido = edicion.MaxIDPartido() + 1
        End If

        Randomize()
        Dim aleatorio As Integer
        Dim aux As Integer = 0
        Dim ganadora As Integer

        juego1.partido = New Partido(partido.idPartido)
        juego2.partido = New Partido(partido.idPartido)
        For i = 0 To 2 Step 1

            aleatorio = Int((1 - 0 + 1) * Rnd() + 0)
            aux += aleatorio

            Select Case [i]
                Case 0
                    If aleatorio = 0 Then
                        juego1.set1 = 6
                        juego2.set1 = Int((4 - 0 + 1) * Rnd() + 0)

                    ElseIf aleatorio = 1 Then
                        juego2.set1 = 6
                        juego1.set1 = Int((4 - 0 + 1) * Rnd() + 0)

                    End If
                Case 1
                    If aleatorio = 0 Then
                        juego1.set2 = 6
                        juego2.set2 = Int((4 - 0 + 1) * Rnd() + 0)

                    ElseIf aleatorio = 1 Then
                        juego2.set2 = 6
                        juego1.set2 = Int((4 - 0 + 1) * Rnd() + 0)

                    End If
                    ganadora = aux
                Case 2
                    If aux = 1 Then
                        If aleatorio = 0 Then
                            juego1.set3 = 6
                            juego2.set3 = Int((4 - 0 + 1) * Rnd() + 0)

                        ElseIf aleatorio = 1 Then
                            juego2.set3 = 6
                            juego1.set3 = Int((4 - 0 + 1) * Rnd() + 0)

                        End If
                        ganadora = aleatorio
                    End If
            End Select
        Next
        If ganadora > 0 Then
            partido.ganadora = New Jugadora(juego2.jugadora.idJugadora)
        Else
            partido.ganadora = New Jugadora(juego1.jugadora.idJugadora)
        End If
        Try
            If edicion.InsertarPartido(partido) <> 1 Then
                MessageBox.Show("INSERT return <> 1", String.Empty, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Function
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Function

        End Try
        Try
            If edicion.InsertarJuego(juego1) <> 1 Then
                MessageBox.Show("INSERT return <> 1", String.Empty, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Function
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Function

        End Try
        Try
            If edicion.InsertarJuego(juego2) <> 1 Then
                MessageBox.Show("INSERT return <> 1", String.Empty, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Function
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Function

        End Try
        Return partido.ganadora
    End Function

    Public Sub incrementarPuntos(v() As Jugadora, c As Integer)
        For Each aux In v
            aux.LeerDatosJugadora()
            aux.PuntosJugadora += c
            aux.ActualizarJugadora()
        Next
    End Sub

    Private Sub BotonLimpiarJugadoras_Click(sender As Object, e As EventArgs) Handles BotonLimpiarJugadoras.Click
        LimpiarJugadoras()
    End Sub

    Private Sub LimpiarJugadoras()
        puntosJug.Text = ""
        idText.Text = ""
        nombre_textbox.Text = ""
        SelectPais.Text = ""
    End Sub

    Private Sub LimpiarPais()
        Labelid.Text = ""
        NombrePais_Text.Text = ""
    End Sub

    Private Sub LimpiarTorneos()
        NombreTorneo_Text.Text = ""
        CiudadTorneo_Text.Text = ""
        SelectPaisTorneo.Text = ""
        LabelidTorneo.Text = ""
    End Sub

    Private Sub BotonLimpiarPais_Click(sender As Object, e As EventArgs) Handles BotonLimpiarPais.Click
        LimpiarPais()
    End Sub

    Private Sub BotonLimpiarTorneo_Click(sender As Object, e As EventArgs) Handles BotonLimpiarTorneo.Click
        LimpiarTorneos()
    End Sub

    Private Sub BotonActualizarJugadora_Click(sender As Object, e As EventArgs) Handles BotonActualizarJugadora.Click
        Dim j As Jugadora
        j = New Jugadora(Lista_jugadoras.SelectedItem.ToString)
        j.LeerDatosJugadora()
        j.NombreJugadora = nombre_textbox.Text
        Dim auxPaisString As Char()
        Dim auxPais As Pais
        auxPaisString = SelectPais.Text.ToCharArray()
        auxPais = New Pais(auxPaisString)
        j.PaisJugadora = auxPais
        Dim fechaux As String()
        fechaux = Split(FechaNacimiento.Value.ToString)
        j.FechaNacimientoJugadora = formatoFecha(fechaux(0))
        j.ActualizarJugadora()
        ActualizarListaJugadoras()
    End Sub

    Public Sub ActualizarListaPuntos()
        Dim aux As Jugadora
        Dim str As String
        Dim jug As Jugadora
        jug = New Jugadora()
        jug.LeerTodasPuntos()
        ListaPuntoJug.Items.Clear()
        For Each aux In jug.jDAO.jugadoras
            str = aux.NombreJugadora.ToString + " - " + aux.PuntosJugadora.ToString
            ListaPuntoJug.Items.Add(str)
        Next
    End Sub

    Private Sub BotonActualizarTabla_Click(sender As Object, e As EventArgs) Handles BotonActualizarTabla.Click
        ActualizarListaPuntos()
    End Sub

    'Public Sub ResultadosPartidos(j1 As Jugadora, j2 As Jugadora, pa As Partido)
    'Dim 
    'End Sub

End Class
