﻿Public Class Jugadora
    Private _idJugadora As Integer
    Private _NombreJugadora As String
    Private _FechaNacimientoJugadora As String
    Private _PuntosJugadora As Integer
    Private _PaisJugadora As Pais

    Public ReadOnly Property jDAO As JugadoraDAO

    Public Property idJugadora As Integer
        Get
            Return _idJugadora
        End Get
        Set(value As Integer)
            _idJugadora = value
        End Set
    End Property
    Public Property NombreJugadora As String
        Get
            Return _NombreJugadora
        End Get
        Set(value As String)
            _NombreJugadora = value
        End Set
    End Property
    Public Property PaisJugadora As Pais
        Get
            Return _PaisJugadora
        End Get
        Set(value As Pais)
            _PaisJugadora = value
        End Set
    End Property
    Public Property PuntosJugadora As Integer
        Get
            Return _PuntosJugadora
        End Get
        Set(value As Integer)
            _PuntosJugadora = value
        End Set
    End Property
    Public Property FechaNacimientoJugadora As String
        Get
            Return _FechaNacimientoJugadora
        End Get
        Set(value As String)
            _FechaNacimientoJugadora = value
        End Set
    End Property

    Public Sub New()
        Me.jDAO = New JugadoraDAO
    End Sub
    Public Sub New(id As Integer)
        Me.jDAO = New JugadoraDAO
        Me.idJugadora = id
        Me.LeerJugadora()
    End Sub
    Public Sub New(nombre As String)
        Me.jDAO = New JugadoraDAO
        Me.NombreJugadora = nombre
    End Sub
    Public Sub LeerTodas()
        Me.jDAO.LeerTodas()
    End Sub

    Public Sub LeerTodasPuntos()
        Me.jDAO.LeerTodasPuntos()
    End Sub
    Public Sub LeerJugadora()
        Me.jDAO.Leer(Me)
    End Sub

    Public Sub LeerDatosJugadora()
        Me.jDAO.LeerDatosJugadora(Me)
    End Sub
    Public Function InsertarJugadora() As Integer
        Return Me.jDAO.Insertar(Me)
    End Function

    Public Function ActualizarJugadora() As Integer
        Return Me.jDAO.Actualizar(Me)
    End Function

    Public Function BorrarJugadora() As Integer
        Return Me.jDAO.Borrar(Me)
    End Function
    Public Function Borrar_NombreJugadora() As Integer
        Return Me.jDAO.Borrar_Nombre(Me)
    End Function

    Public Function LeerRandom(ByRef v As Integer()) As Jugadora()
        Return Me.jDAO.LeerRandom(v)
    End Function


    Public Function MaxID() As Integer
        Return Me.jDAO.MaxID()
    End Function

End Class
