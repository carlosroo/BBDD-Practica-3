﻿Public Class Juegos
    Private _jugadora As Jugadora
    Private _partido As Partido
    Private _set1 As Integer
    Private _set2 As Integer
    Private _set3 As Integer

    Public Property jugadora As Jugadora
        Get
            Return _jugadora
        End Get
        Set(value As Jugadora)
            _jugadora = value
        End Set
    End Property

    Public Property partido As Partido
        Get
            Return _partido
        End Get
        Set(value As Partido)
            _partido = value

        End Set
    End Property
    Public Property set1 As Integer
        Get
            Return _set1
        End Get
        Set(value As Integer)
            _set1 = value
        End Set
    End Property
    Public Property set2 As Integer
        Get
            Return _set2
        End Get
        Set(value As Integer)
            _set2 = value
        End Set
    End Property
    Public Property set3 As Integer
        Get
            Return _set3
        End Get
        Set(value As Integer)
            _set3 = value
        End Set
    End Property

End Class
