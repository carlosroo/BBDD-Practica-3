﻿Public Class Partido
    Private _idpartido As Integer
    Private _anualidad As Integer
    Private _torneo As Torneo
    Private _ganadora As Jugadora
    Private _ronda As Char

    Public ReadOnly Property eDAO As EdicionesDAO

    Public Property idPartido As Integer
        Get
            Return _idpartido
        End Get
        Set(value As Integer)
            _idpartido = value
        End Set
    End Property
    Public Property anualidad As Integer
        Get
            Return _anualidad
        End Get
        Set(value As Integer)
            _anualidad = value
        End Set
    End Property
    Public Property torneo As Torneo
        Get
            Return _torneo
        End Get
        Set(value As Torneo)
            _torneo = value
        End Set
    End Property
    Public Property ganadora As Jugadora
        Get
            Return _ganadora
        End Get
        Set(value As Jugadora)
            _ganadora = value
        End Set
    End Property
    Public Property ronda As Char
        Get
            Return _ronda
        End Get
        Set(value As Char)
            _ronda = value
        End Set
    End Property
    Public Sub New()
        Me.eDAO = New EdicionesDAO
    End Sub
    Public Sub New(id As Integer)
        _idpartido = id
    End Sub

End Class
