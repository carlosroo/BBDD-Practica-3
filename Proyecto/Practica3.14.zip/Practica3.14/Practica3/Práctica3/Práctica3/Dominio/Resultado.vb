﻿Public Class Resultado

End Class
