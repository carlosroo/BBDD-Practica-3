﻿Public Class EdicionesDAO
    Public ReadOnly Property tenis As Collection
    Public ReadOnly Property partidos As Collection

    Public Sub New()
        Me.tenis = New Collection
        Me.partidos = New Collection
    End Sub

    Public Sub LeerTodas()
        Dim e As Ediciones
        Dim t As Torneo = New Torneo()
        Dim j As Jugadora = New Jugadora()
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente().Leer("SELECT * FROM Ediciones ORDER BY Anualidad")
        For Each aux In col
            e = New Ediciones(aux(1).ToString)
            e.anualidad = aux(1).ToString
            t.idTorneo = aux(2)
            t.LeerTorneo()
            e.torneo = t
            j.idJugadora = aux(3)
            j.LeerJugadora()
            e.ganadora = j

            Me.tenis.Add(e)
        Next
    End Sub

    Public Sub Leer(ByRef e As Ediciones)
        Dim col As Collection : Dim aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT * FROM Ediciones WHERE Torneo='" & e.torneo.idTorneo & "';")
        Dim j As Jugadora = New Jugadora()
        For Each aux In col
            j.idJugadora = aux(3)
            e.ganadora = j
            e.anualidad = aux(1)
        Next
    End Sub

    Public Function InsertarEdicion(ByVal e As Ediciones) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("INSERT INTO ediciones VALUES ('" & e.anualidad & "', '" & e.torneo.idTorneo & "','" & e.ganadora.idJugadora & "');")
    End Function


    Public Function InsertarPartido(ByVal p As Partido) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("INSERT INTO partidos VALUES ('" & p.idPartido & "', '" & p.anualidad & "','" & p.torneo.idTorneo & "','" & p.ganadora.idJugadora & "','" & p.ronda & "');")

    End Function

    Public Function InsertarJuego(ByVal j As Juegos) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("INSERT INTO juegos VALUES ('" & j.jugadora.idJugadora & "', '" & j.partido.idPartido & "','" & j.set1 & "','" & j.set2 & "','" & j.set3 & "');")

    End Function


    Public Function Actualizar(ByVal e As Ediciones) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("UPDATE ediciones SET Ganadora='" & e.ganadora.idJugadora & "' WHERE Anualidad='" & e.anualidad & "' AND Torneo='" & e.torneo.idTorneo & "';")
    End Function

    Public Function MaxIDPArtido() As Integer
        Dim col As Collection : Dim aux As Collection
        Dim max As Integer
        col = AgenteBD.ObtenerAgente.Leer("SELECT * FROM partidos ORDER BY idpartido DESC;")
        max = col(1)(1)
        Return max
    End Function

    Public Sub LeerTodosPartidos()
        Dim p As Partido
        Dim col, aux As Collection
        Dim torneo As Torneo = New Torneo()
        Dim ganadora As Jugadora = New Jugadora()
        col = AgenteBD.ObtenerAgente().Leer("SELECT * FROM Partidos ORDER BY idpartido")
        For Each aux In col
            p = New Partido(aux(1))
            p.idPartido = aux(1)
            p.anualidad = aux(2)
            torneo.idTorneo = aux(3)
            torneo.LeerTorneo()
            p.torneo = torneo
            ganadora.idJugadora = aux(4)
            ganadora.LeerJugadora()
            p.ganadora = ganadora
            p.ronda = aux(5)

            Me.partidos.Add(p)
        Next
    End Sub

    Public Function leerIDPartido(ByVal pa As Partido)
        Dim col As Collection : Dim aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT idpartido FROM partidos WHERE Anualidad ='" & pa.anualidad & "' AND Torneo ='" & pa.torneo.idTorneo & "' AND Ganadora='" & pa.ganadora.idJugadora & "' AND Ronda='" & pa.ronda & "';")
        Dim intAux As Integer
        For Each aux In col
            intAux = aux(1)
        Next
        Return intAux
    End Function
End Class
