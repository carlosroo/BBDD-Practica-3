﻿Public Class JugadoraDAO

    Public ReadOnly Property jugadoras As Collection

    Public Sub New()
        Me.jugadoras = New Collection
    End Sub

    Public Sub LeerTodas()
        Dim p As Jugadora
        Dim c As Pais
        c = New Pais()
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente().Leer("SELECT * FROM jugadoras ORDER BY idJugadora")
        For Each aux In col
            p = New Jugadora(aux(1).ToString)
            p.NombreJugadora = aux(2).ToString
            p.FechaNacimientoJugadora = aux(3)
            p.PuntosJugadora = aux(4)
            c.idPais = aux(5).ToString
            c.LeerPais()
            p.PaisJugadora = c
            Me.jugadoras.Add(p)
        Next
    End Sub

    Public Sub Leer(ByRef p As Jugadora)
        Dim col As Collection : Dim aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT * FROM jugadoras WHERE idJugadora='" & p.idJugadora & "';")
        For Each aux In col
            p.NombreJugadora = aux(2).ToString
        Next
    End Sub

    Public Function LeerRandom(ByRef v As Integer())
        Dim col As Collection : Dim aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT * FROM jugadoras ORDER BY PuntosJugadora;")
        Dim vAux(7) As Jugadora
        Dim jAux As Jugadora
        Dim cAux As Pais
        cAux = New Pais()
        For i = 0 To 7 Step 1

            jAux = New Jugadora(col(v(i))(1).ToString)
            jAux.idJugadora = col(v(i))(1)
            jAux.NombreJugadora = col(v(i))(2).ToString
            jAux.FechaNacimientoJugadora = col(v(i))(3)
            jAux.PuntosJugadora = col(v(i))(4)
            cAux.idPais = col(v(i))(5).ToString
            cAux.LeerPais()
            jAux.PaisJugadora = cAux
            vAux(i) = jAux
        Next
        Return vAux
    End Function

    Public Sub LeerDatosJugadora(ByRef p As Jugadora)
        Dim col As Collection
        Dim i As Integer
        col = AgenteBD.ObtenerAgente.LeerFila("SELECT * FROM jugadoras WHERE NombreJugadora='" & p.NombreJugadora & "';")
        p.idJugadora = col(1)
        p.NombreJugadora = col(2)
        p.FechaNacimientoJugadora = col(3)
        p.PuntosJugadora = col(4)
        p.PaisJugadora = New Pais(CType(col(5), Char()))

    End Sub

    Public Function Insertar(ByVal p As Jugadora) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("INSERT INTO jugadoras  VALUES ('" & p.idJugadora & "', '" & p.NombreJugadora & "','" & p.FechaNacimientoJugadora & "','" & p.PuntosJugadora & "','" & p.PaisJugadora.idPais & "');")
    End Function

    Public Function Actualizar(ByVal p As Jugadora) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("UPDATE jugadoras SET NombreJugadora='" & p.NombreJugadora & "', PuntosJugadora='" & p.PuntosJugadora & "', PaisJugadora='" & p.PaisJugadora.idPais & "' WHERE idJugadora='" & p.idJugadora & "';")
    End Function

    Public Function Borrar(ByVal p As Jugadora) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("DELETE FROM jugadoras WHERE idJugadora='" & p.idJugadora & "';")
    End Function

    Public Function Borrar_Nombre(ByVal p As Jugadora) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("DELETE FROM jugadoras WHERE NombreJugadora='" & p.NombreJugadora & "';")
    End Function

    Public Function MaxID() As Integer
        Return AgenteBD.ObtenerAgente.Modificar("SELECT MAX(idJugadora) FROM jugadoras;")
    End Function

    Public Sub LeerTodasPuntos()
        Dim p As Jugadora
        Dim c As Pais
        c = New Pais()
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente().Leer("SELECT NombreJugadora, PuntosJugadora FROM jugadoras ORDER BY PuntosJugadora DESC")
        For Each aux In col
            p = New Jugadora()
            p.NombreJugadora = aux(1).ToString
            p.PuntosJugadora = aux(2)
            Me.jugadoras.Add(p)
        Next
    End Sub
End Class
