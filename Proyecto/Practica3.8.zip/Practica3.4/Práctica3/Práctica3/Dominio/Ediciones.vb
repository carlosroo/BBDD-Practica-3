﻿Public Class Ediciones

    Private _anualidad As Integer
    Private _torneo As Integer
    Private _ganadora As Integer
    Public ReadOnly Property eDAO As EdicionesDAO

    Public Property anualidad As Integer
        Get
            Return _anualidad
        End Get
        Set(value As Integer)
            _anualidad = value
        End Set
    End Property

    Public Property torneo As Integer
        Get
            Return _torneo
        End Get
        Set(value As Integer)
            _torneo = value
        End Set
    End Property

    Public Property ganadora As Integer
        Get
            Return _ganadora
        End Get
        Set(value As Integer)
            _ganadora = value
        End Set
    End Property

    Public Sub New()
        Me.eDAO = New EdicionesDAO
    End Sub


    Public Sub LeerTodas()
        Me.eDAO.LeerTodas()
    End Sub
    Public Sub LeerEdiciones()
        Me.eDAO.Leer(Me)
    End Sub
    Public Function InsertarEdicion() As Integer
        Return Me.eDAO.Insertar(Me)
    End Function

    Public Function ActualizarEdicion() As Integer
        Return Me.eDAO.Actualizar(Me)
    End Function

    Public Function BorrarEdicion() As Integer
        Return Me.eDAO.Borrar(Me)
    End Function



    Private toString As String

    Public Sub New(toString As String)
        Me.toString = toString
    End Sub


End Class
