﻿Public Class Form1

    Public Property j As Jugadora
    Public Property p As Pais
    Public Property t As Torneo
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' ActualizarListas()
        ActualizarPaises()
        ConectarBBDD()

    End Sub
    'Private Sub ActualizarListas()
    '    Dim jugadoras As Jugadora
    '    jugadoras = New Jugadora()

    '    Lista_jugadoras.Items.Clear()

    '    Try
    '        jugadoras.LeerTodas()

    '        For Each player As Jugadora In jugadoras.jDAO.jugadoras
    '            Lista_jugadoras.Items.Add(player.NombreJugadora)
    '        Next
    '    Catch ex As Exception
    '        MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    '    End Try
    'End Sub


    Private Sub ActualizarPaises()
        Me.p = New Pais
        Dim paux As Pais
        Dim aux As String
        SelectPais.Items.Clear()
        Try
            Me.p.LeerTodas()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End Try
        For Each paux In Me.p.pDAO.paises
            'paux = p.pDAO.paises(1)'
            aux = New String(paux.idPais)
            SelectPais.Items.Add(aux)
        Next
    End Sub

    Private Sub ActualizarListaTorneo()
        Lista_Torneos.Items.Clear()
        Dim taux As Torneo
        Me.t = New Torneo
        Try
            Me.t.LeerTodas()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End Try
        For Each taux In Me.t.tDAO.torneos
            Me.Lista_Torneos.Items.Add(taux.NombreTorneo)
        Next
    End Sub


    Private Sub ConectarBBDD()
        Dim jaux As Jugadora
        Me.j = New Jugadora
        Dim paux As Pais
        Me.p = New Pais
        Dim taux As Torneo
        Me.t = New Torneo
        Dim auxIDPais As String

        Try
            Me.j.LeerTodas()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End Try
        For Each jaux In Me.j.jDAO.jugadoras
            Me.Lista_jugadoras.Items.Add(jaux.NombreJugadora)
        Next

        Try
            Me.p.LeerTodas()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End Try
        For Each paux In Me.p.pDAO.paises
            Me.lista_paises.Items.Add(paux.NombrePais)
        Next

        Try
            Me.t.LeerTodas()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End Try
        For Each taux In Me.t.tDAO.torneos
            Me.Lista_Torneos.Items.Add(taux.NombreTorneo)
        Next
    End Sub
    Private Sub boton_insertarjugadora_Click(sender As Object, e As EventArgs) Handles boton_insertarjugadora.Click
        If Me.nombre_textbox.Text <> String.Empty And Me.SelectPais.Text <> String.Empty Then
            j = New Jugadora()
            j.idJugadora = j.MaxID() + 1
            j.NombreJugadora = nombre_textbox.Text
            Dim auxPaisString As String
            Dim auxPais As Pais
            auxPaisString = SelectPais.Text.ToCharArray()
            auxPais = New Pais(auxPaisString)
            j.PaisJugadora = auxPais
            j.FechaNacimientoJugadora = FechaNacimiento.Value.ToShortDateString
            Dim fechaAux As String
            fechaAux = Format(j.FechaNacimientoJugadora, "dd-mm-yyyy")
            j.FechaNacimientoJugadora = fechaAux
            MessageBox.Show(fechaAux)
            j.PuntosJugadora = 0

            Try
                If j.InsertarJugadora() <> 1 Then
                    MessageBox.Show("INSERT return <> 1", String.Empty, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub

            End Try
            Me.Lista_jugadoras.Items.Add(j.idJugadora)
        End If
    End Sub

    Private Sub Boton_Insertar_Pais_Click(sender As Object, e As EventArgs) Handles Boton_Insertar_Pais.Click
        If Me.NombrePais_Text.Text <> String.Empty Then
            p = New Pais()
            p.NombrePais = NombrePais_Text.Text
            Dim nombreaux As String = UCase(p.NombrePais)
            Dim aux2 As String = nombreaux.Substring(0, 3)
            p.idPais = aux2
            Dim aux As String
            aux = New String(p.idPais)
            Try
                If p.InsertarPais() <> 1 Then
                    MessageBox.Show("INSERT return <> 1", String.Empty, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub

            End Try
            Me.lista_paises.Items.Add(p.NombrePais)
            SelectPais.Items.Add(aux)
            ActualizarPaises()
        End If
    End Sub

    Private Sub Boton_Insertar_Torneo_Click(sender As Object, e As EventArgs) Handles Boton_Insertar_Torneo.Click
        If Me.NombreTorneo_Text.Text <> String.Empty And Me.CiudadTorneo_Text.Text <> String.Empty And Me.PaisTorneo_Text.Text <> String.Empty Then
            t = New Torneo()
            t.idTorneo = t.MaxID() + 1
            t.NombreTorneo = NombreTorneo_Text.Text
            t.CiudadTorneo = CiudadTorneo_Text.Text
            Dim auxPaisTorneo As Pais
            Dim auxChar As Char() = PaisTorneo_Text.Text.ToCharArray()
            auxPaisTorneo = New Pais(auxChar)
            t.PaisTorneo = auxPaisTorneo
            Try
                If t.InsertarTorneo() <> 1 Then
                    MessageBox.Show("INSERT return <> 1", String.Empty, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub

            End Try
            Me.Lista_Torneos.Items.Add(t.NombreTorneo)
        End If
    End Sub

    Private Sub idjugadoras_textbox_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub idPais_Text_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub BotonBorrarJugadora_Click(sender As Object, e As EventArgs) Handles BotonBorrarJugadora.Click
        Try
            Dim jugadora As Jugadora = New Jugadora(Lista_jugadoras.SelectedItem.ToString)
            Lista_jugadoras.Items.Remove(jugadora.NombreJugadora)
            jugadora.Borrar_NombreJugadora()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Boton_Borrar_Pais_Click(sender As Object, e As EventArgs) Handles Boton_Borrar_Pais.Click
        Try
            Dim p As Pais = New Pais(lista_paises.SelectedItem.ToString)
            lista_paises.Items.Remove(lista_paises.SelectedItem)
            p.BorrarPais()
            SelectPais.Items.Clear()
            ActualizarPaises()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub BotonBorrar_Torneo_Click(sender As Object, e As EventArgs) Handles BotonBorrar_Torneo.Click
        Try
            Dim t As Torneo = New Torneo(Lista_Torneos.SelectedItem.ToString)
            Lista_Torneos.Items.Remove(Lista_Torneos.SelectedItem)
            t.BorrarTorneo_Nombre()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Lista_Torneos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Lista_Torneos.SelectedIndexChanged
        If Lista_Torneos.SelectedItem IsNot Nothing Then
            Dim torneo As Torneo = New Torneo(Lista_Torneos.SelectedItem.ToString)
            torneo.LeerDatosTorneo()
            NombreTorneo_Text.Text = torneo.NombreTorneo
            CiudadTorneo_Text.Text = torneo.CiudadTorneo
            PaisTorneo_Text.Text = torneo.PaisTorneo.idPais
        End If
    End Sub

    Private Sub ActualizarTorneos_Click(sender As Object, e As EventArgs) Handles ActualizarTorneos.Click
        If Me.NombreTorneo_Text.Text <> String.Empty And Me.CiudadTorneo_Text.Text <> String.Empty And Me.PaisTorneo_Text.Text <> String.Empty Then
            Dim t As Torneo = New Torneo(Lista_Torneos.SelectedItem.ToString)
            t.LeerDatosTorneo()
            Dim nuevoNombre As String
            nuevoNombre = NombreTorneo_Text.Text
            t.NombreTorneo = nuevoNombre
            t.ActualizarTorneo()
            ActualizarListaTorneo()
        End If
    End Sub
End Class
