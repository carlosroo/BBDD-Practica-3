﻿Public Class Form1

    Public Property j As Jugadora
    Public Property p As Pais
    Public Property t As Torneo
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActualizarListas()

    End Sub
    Private Sub ActualizarListas()
        Dim jugadoras As Jugadora
        jugadoras = New Jugadora()

        Lista_jugadoras.Items.Clear()

        Try
            jugadoras.LeerTodas()

            For Each player As Jugadora In jugadoras.jDAO.jugadoras
                Lista_jugadoras.Items.Add(player.NombreJugadora)
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Dim jaux As Jugadora
        Me.j = New Jugadora
        Dim paux As Pais
        Me.p = New Pais
        Dim taux As Torneo
        Me.t = New Torneo
        Dim auxIDPais As String

        Try
            Me.j.LeerTodas()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End Try
        For Each jaux In Me.j.jDAO.jugadoras
            Me.Lista_jugadoras.Items.Add(jaux.idJugadora)
        Next

        Try
            Me.p.LeerTodas()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End Try
        For Each paux In Me.p.pDAO.paises
            auxIDPais = convertir_String(paux.idPais)
            Me.lista_paises.Items.Add(auxIDPais)
        Next

        Try
            Me.t.LeerTodas()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End Try
        For Each taux In Me.t.tDAO.torneos
            Me.Lista_Torneos.Items.Add(taux.idTorneo)
        Next
    End Sub

    Private Function convertir_String(vector As Char()) As String
        Dim cadena As String
        cadena = ""
        For Each aux In vector
            cadena += aux
        Next
        Return cadena
    End Function

    Private Sub boton_insertarjugadora_Click(sender As Object, e As EventArgs) Handles boton_insertarjugadora.Click
        If Me.nombre_textbox.Text <> String.Empty And Me.SelectPais.Text <> String.Empty Then
            j = New Jugadora()
            j.idJugadora = Int((1000000 - 0 + 1) * Rnd() + 0)
            j.NombreJugadora = nombre_textbox.Text
            Dim auxPaisString As String
            Dim auxPais As Pais
            auxPaisString = SelectPais.Text.ToCharArray()
            auxPais = New Pais(auxPaisString)
            j.PaisJugadora = auxPais
            j.FechaNacimientoJugadora = FechaNacimiento.Value.ToShortDateString
            Dim fechaAux As Date = Format(CDate(j.FechaNacimientoJugadora), "yyyy-mm-dd")
            MessageBox.Show(fechaAux)
            j.PuntosJugadora = 0

            Try
                If j.InsertarJugadora() <> 1 Then
                    MessageBox.Show("INSERT return <> 1", String.Empty, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub

            End Try
            Me.Lista_jugadoras.Items.Add(j.idJugadora)
        End If
    End Sub

    Private Sub Boton_Insertar_Pais_Click(sender As Object, e As EventArgs) Handles Boton_Insertar_Pais.Click
        If Me.idPais_Text.Text <> String.Empty And Me.NombrePais_Text.Text <> String.Empty Then
            p = New Pais()
            p.idPais = idPais_Text.Text
            p.NombrePais = NombrePais_Text.Text
            Dim cadena_idPais As String
            cadena_idPais = convertir_String(p.idPais)

            Try
                If p.InsertarPais() <> 1 Then
                    MessageBox.Show("INSERT return <> 1", String.Empty, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub

            End Try
            Me.lista_paises.Items.Add(cadena_idPais)
        End If
    End Sub

    Private Sub Boton_Insertar_Torneo_Click(sender As Object, e As EventArgs) Handles Boton_Insertar_Torneo.Click
        If Me.NombreTorneo_Text.Text <> String.Empty And Me.CiudadTorneo_Text.Text <> String.Empty And Me.PaisTorneo_Text.Text <> String.Empty Then
            t = New Torneo()
            t.idTorneo = Int((1000000 - 0 + 1) * Rnd() + 0)
            t.NombreTorneo = NombreTorneo_Text.Text
            t.CiudadTorneo = CiudadTorneo_Text.Text
            Dim auxPaisTorneo As Pais
            Dim auxChar As Char() = PaisTorneo_Text.Text.ToCharArray()
            auxPaisTorneo = New Pais(auxChar)
            t.PaisTorneo = auxPaisTorneo
            Try
                If t.InsertarTorneo() <> 1 Then
                    MessageBox.Show("INSERT return <> 1", String.Empty, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub

            End Try
            Me.Lista_Torneos.Items.Add(t.NombreTorneo)
        End If
    End Sub

    Private Sub idjugadoras_textbox_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub idPais_Text_TextChanged(sender As Object, e As EventArgs) Handles idPais_Text.TextChanged

    End Sub
End Class
