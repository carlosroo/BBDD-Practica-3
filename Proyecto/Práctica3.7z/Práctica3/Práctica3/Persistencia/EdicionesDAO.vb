﻿Public Class EdicionesDAO
    Public ReadOnly Property tenis As Collection

    Public Sub New()
        Me.tenis = New Collection
    End Sub

    Public Sub LeerTodas()
        Dim e As Ediciones
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente().Leer("SELECT * FROM Ediciones ORDER BY Anualidad")
        For Each aux In col
            e = New Ediciones(aux(1).ToString)
            e.anualidad = aux(2).ToString
            e.torneo = aux(3).ToString
            e.ganadora = aux(4).ToString
            Me.tenis.Add(e)
        Next
    End Sub

    Public Sub Leer(ByRef e As Ediciones)
        Dim col As Collection : Dim aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT * FROM Ediciones WHERE Torneo='" & e.torneo & "';")
        For Each aux In col
            e.torneo = aux(2).ToString
        Next
    End Sub

    Public Function Insertar(ByVal e As Ediciones) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("INSERT INTO Ediciones VALUES ('" & e.anualidad & "', '" & e.torneo & "';" & e.ganadora & "';")
    End Function

    Public Function Actualizar(ByVal e As Ediciones) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("UPDATE INTO Ediciones VALUES ('" & e.anualidad & "', '" & e.torneo & "';" & e.ganadora & "';")
    End Function

    Public Function Borrar(ByVal e As Ediciones) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("DELETE INTO Ediciones VALUES ('" & e.anualidad & "', '" & e.torneo & "';" & e.ganadora & "';")
    End Function
End Class
