﻿Public Class PartidoDAO

    Public ReadOnly Property partidos As Collection

    Public Sub New()
        Me.partidos = New Collection
    End Sub

    Public Sub LeerTodos()
        Dim p As Partido
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente().Leer("SELECT * FROM Partidos ORDER BY idPartido")
        For Each aux In col
            p = New Partido(aux(1).ToString)
            p.idPartido = aux(2).ToString
            p.anualidad = aux(3).ToString
            p.torneo = aux(4).ToString
            p.ganadora = aux(5).ToString
            p.ronda = aux(6).ToString
            Me.partidos.Add(p)
        Next
    End Sub

    Public Sub Leer(ByRef p As Partido)
        Dim col As Collection : Dim aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT * FROM Partido WHERE idPartido='" & p.idPartido & "';")
        For Each aux In col
            p.idPartido = aux(2).ToString
        Next
    End Sub

    Public Function Insertar(ByVal p As Partido) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("INSERT INTO Partido  VALUES ('" & p.idPartido & "', '" & p.anualidad & "','" & p.torneo & "','" & p.ganadora & "','" & p.ronda & "');")
    End Function

    Public Function Actualizar(ByVal p As Partido) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("UPDATE INTO Partido  VALUES ('" & p.idPartido & "', '" & p.anualidad & "','" & p.torneo & "','" & p.ganadora & "','" & p.ronda & "');")
    End Function

    Public Function Borrar(ByVal p As Partido) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("DELETE INTO Partido  VALUES ('" & p.idPartido & "', '" & p.anualidad & "','" & p.torneo & "','" & p.ganadora & "','" & p.ronda & "');")
    End Function
End Class
