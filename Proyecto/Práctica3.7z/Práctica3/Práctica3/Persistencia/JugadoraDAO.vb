﻿Public Class JugadoraDAO

    Public ReadOnly Property jugadoras As Collection

    Public Sub New()
        Me.jugadoras = New Collection
    End Sub

    Public Sub LeerTodas()
        Dim p As Jugadora
        Dim c As Pais
        c = New Pais()
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente().Leer("SELECT * FROM Jugadoras ORDER BY idJugadora")
        For Each aux In col
            p = New Jugadora(aux(1).ToString)
            p.NombreJugadora = aux(2).ToString
            p.FechaNacimientoJugadora = aux(3)
            p.PuntosJugadora = aux(4)
            c.idPais = aux(5).ToString
            c.LeerPais()
            Me.jugadoras.Add(p)
        Next
    End Sub

    Public Sub Leer(ByRef p As Jugadora)
        Dim col As Collection : Dim aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT * FROM Jugadoras WHERE idJugadora='" & p.idJugadora & "';")
        For Each aux In col
            p.NombreJugadora = aux(2).ToString
        Next
    End Sub

    Public Function Insertar(ByVal p As Jugadora) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("INSERT INTO Jugadoras  VALUES ('" & p.idJugadora & "', '" & p.NombreJugadora & "','" & p.FechaNacimientoJugadora & "','" & p.PuntosJugadora & "','" & p.PaisJugadora.idPais & "');")
    End Function

    Public Function Actualizar(ByVal p As Jugadora) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("UPDATE Jugadoras SET NombreJugadora='" & p.NombreJugadora & "' WHERE idJugadora='" & p.idJugadora & "';")
    End Function

    Public Function Borrar(ByVal p As Jugadora) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("DELETE FROM Jugadoras WHERE idJugadora='" & p.idJugadora & "';")
    End Function




End Class
