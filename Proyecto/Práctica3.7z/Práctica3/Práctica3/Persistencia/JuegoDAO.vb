﻿Public Class JuegoDAO
    Public ReadOnly Property juego As Collection

    Public Sub New()
        Me.juego = New Collection
    End Sub

    Public Sub LeerTodas()
        Dim j As Juegos
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente().Leer("SELECT * FROM Juego ORDER BY Partido")
        For Each aux In col
            j = New Juegos(aux(1).ToString)
            j.jugadora = aux(2).ToString
            j.partido = aux(3).ToString
            j.set1 = aux(4).ToString
            j.set2 = aux(5).ToString
            j.set3 = aux(6).ToString
            Me.juego.Add(j)
        Next
    End Sub

    Public Sub Leer(ByRef j As Juegos)
        Dim col As Collection : Dim aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT * FROM Juegos WHERE partido='" & j.partido & "';")
        For Each aux In col
            j.partido = aux(3).ToString
        Next
    End Sub

    Public Function Insertar(ByVal j As Juegos) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("INSERT INTO Juegos  VALUES ('" & j.jugadora & "', '" & j.partido & "','" & j.set1 & "','" & j.set2 & "','" & j.set3 & "');")
    End Function

    Public Function Actualizar(ByVal j As Juegos) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("UPDATE INTO Juegos  VALUES ('" & j.jugadora & "', '" & j.partido & "','" & j.set1 & "','" & j.set2 & "','" & j.set3 & "');")
    End Function

    Public Function Borrar(ByVal j As Juegos) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("DELETE INTO Juegos  VALUES ('" & j.jugadora & "', '" & j.partido & "','" & j.set1 & "','" & j.set2 & "','" & j.set3 & "');")
    End Function
End Class
