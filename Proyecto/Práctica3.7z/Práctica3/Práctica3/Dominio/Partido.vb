﻿Public Class Partido
    Private _idpartido As Integer
    Private _anualidad As Integer
    Private _torneo As Integer
    Private _ganadora As Integer
    Private _ronda As Char

    Public ReadOnly Property partidoDAO As PartidoDAO
    Public Property idPartido As Integer
        Get
            Return _idpartido
        End Get
        Set(value As Integer)
            _idpartido = value
        End Set
    End Property
    Public Property anualidad As Integer
        Get
            Return anualidad
        End Get
        Set(value As Integer)
            _anualidad = value
        End Set
    End Property
    Public Property torneo As Integer
        Get
            Return _torneo
        End Get
        Set(value As Integer)
            _torneo = value
        End Set
    End Property
    Public Property ganadora As Integer
        Get
            Return _ganadora
        End Get
        Set(value As Integer)
            _ganadora = value
        End Set
    End Property
    Public Property ronda As Char
        Get
            Return _ronda
        End Get
        Set(value As Char)
            _ronda = value
        End Set
    End Property

    Public Sub New()
        Me.partidoDAO = New PartidoDAO
    End Sub
    Public Sub New(id As Integer)
        Me.partidoDAO = New PartidoDAO
        Me.idPartido = id
        Me.LeerPartido()
    End Sub

    Public Sub LeerPartido()
        Me.partidoDAO.Leer(Me)
    End Sub

    Public Sub LeerTodos()
        Me.partidoDAO.LeerTodos()
    End Sub

    Public Function InsertarPartido() As Integer
        Return Me.partidoDAO.Insertar(Me)
    End Function

    Public Function ActualizarPartido() As Integer
        Return Me.partidoDAO.Actualizar(Me)
    End Function

    Public Function BorrarPartido() As Integer
        Return Me.partidoDAO.Borrar(Me)
    End Function
End Class
