﻿Public Class Juegos
    Private _jugadora As Integer
    Private _partido As Integer
    Private _set1 As Integer
    Private _set2 As Integer
    Private _set3 As Integer

    Public ReadOnly Property partDAO As JuegoDAO

    Public Property jugadora As Integer
        Get
            Return _jugadora
        End Get
        Set(value As Integer)
            _jugadora = value
        End Set
    End Property

    Public Property partido As Integer
        Get
            Return _partido
        End Get
        Set(value As Integer)
            _partido = value

        End Set
    End Property
    Public Property set1 As Integer
        Get
            Return _set1
        End Get
        Set(value As Integer)
            _set1 = value
        End Set
    End Property
    Public Property set2 As Integer
        Get
            Return _set2
        End Get
        Set(value As Integer)
            _set2 = value
        End Set
    End Property
    Public Property set3 As Integer
        Get
            Return _set3
        End Get
        Set(value As Integer)
            _set3 = value
        End Set
    End Property
    Public Sub New()
        Me.partDAO = New JuegoDAO
    End Sub
    Public Sub New(partido As Integer)
        Me.partDAO = New JuegoDAO
        Me.partido = partido
        Me.LeerJuegos()
    End Sub
    Public Sub LeerTodas()
        Me.partDAO.LeerTodas()
    End Sub
    Public Sub LeerJuegos()
        Me.partDAO.Leer(Me)
    End Sub
    Public Function InsertarJuegos() As Integer
        Return Me.partDAO.Insertar(Me)
    End Function

    Public Function ActualizarJuegos() As Integer
        Return Me.partDAO.Actualizar(Me)
    End Function

    Public Function BorrarJuegos() As Integer
        Return Me.partDAO.Borrar(Me)
    End Function
End Class
