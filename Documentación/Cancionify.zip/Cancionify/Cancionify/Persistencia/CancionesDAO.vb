﻿Imports System.Data.OleDb
Imports System.Collections
Public Class CancionesDAO
    Public ReadOnly Property _listaCanciones As Collection
    Public Sub New()
        Me._listaCanciones = New Collection
    End Sub
    Public ReadOnly Property listaCanciones As Collection
        Get
            Return _listaCanciones
        End Get
    End Property
    Public Function get_Lista()
        Return _listaCanciones
    End Function
    Public Sub readID(ByRef cancion As Canciones)
        Dim lista As OleDbDataReader
        lista = AgenteBD.getAgente().leer2("SELECT * FROM Canciones WHERE IdCancion = (SELECT MAX(IdCancion) from Canciones);")
        If lista.Read() Then
            cancion.IdCancion = lista(0)
        End If
    End Sub
    Public Sub read(ByRef cancion As Canciones)
        Dim col As Collection
        Dim aux As Collection
        col = AgenteBD.getAgente.leer("SELECT * FROM Canciones WHERE Nombre='" & cancion.Nombre & "';")
        For Each aux In col
            cancion.IdCancion = CInt(aux(1).ToString)
            cancion.Nombre = aux(2).ToString
            cancion.Album = New Albumnes(CInt(aux(3)))
            cancion.Duracion = CInt(aux(4).ToString)
        Next
    End Sub
    Public Sub obtenerCancion(ByRef canc As Canciones)
        Dim col As Collection
        Dim aux As Collection
        col = AgenteBD.getAgente.leer("SELECT * FROM Canciones WHERE IdCancion=" & canc.IdCancion & ";")
        For Each aux In col
            canc.IdCancion = CInt(aux(1))
            canc.Nombre = aux(2).ToString
            canc.Album = New Albumnes(CInt(aux(3)))
            canc.Duracion = aux(4).ToString
        Next
    End Sub
    Public Sub readAll(ruta As String)
        Dim can As Canciones
        Dim col, aux As Collection
        col = AgenteBD.getAgente(ruta).leer("SELECT * FROM Canciones ORDER BY IdCancion")
        For Each aux In col
            can = New Canciones(CInt(aux(1).ToString), aux(2).ToString, CInt(aux(3)), CInt(aux(4).ToString))
            Me._listaCanciones.Add(can)
        Next
    End Sub

    Public Sub ordenarNRepr(ruta As String)
        Dim col As Collection
        Dim aux As Collection
        col = AgenteBD.getAgente.leer("SELECT c.Nombre, COUNT(r.IdReproduccion) FROM ARTISTAS ar, REPRODUCCIONES r, CANCIONES c, ALBUMES alb WHERE c.idcancion = r.cancion AND alb.idalbum = c.album AND ar.idartista = alb.Artista GROUP BY c.Nombre ORDER BY 2 DESC;")
        For Each aux In col
            Me._listaCanciones.Add(aux(1).ToString)
        Next
    End Sub
    Public Function insert(ByRef cancion As Canciones) As Integer
        Return AgenteBD.getAgente().modificar("INSERT INTO Canciones (Nombre,Album,Duracion) VALUES ('" & cancion.Nombre & "', '" & cancion.Album.IdAlbum.ToString & "', '" & cancion.Duracion & "');") 'Se quita la comilla simple en saldopuntos
    End Function
    Public Function update(ByVal cancion As Canciones) As Integer
        Return AgenteBD.getAgente().modificar("UPDATE Canciones SET NOMBRE= '" & cancion.Nombre & "', ALBUM='" & cancion.Album.IdAlbum & "', DURACION= '" & cancion.Duracion & "' WHERE IdCancion=" & cancion.IdCancion & ";")
    End Function
    Public Function delete(cancion As Canciones) As Integer
        Return AgenteBD.getAgente().modificar("DELETE FROM CANCIONES WHERE Nombre='" & cancion.Nombre & "';")
    End Function
End Class
