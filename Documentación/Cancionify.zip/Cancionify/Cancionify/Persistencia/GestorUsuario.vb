﻿Imports System.Data.OleDb
Imports System.Collections
Public Class GestorUsuario
    Public ReadOnly Property listaUsuarios As Collection
    Public ReadOnly Property MasEscuchados As Collection
    Public ReadOnly Property totalRepr As Collection

    Public ReadOnly Property Artistas_Favoritos As Collection

    Public Sub New()
        Me.listaUsuarios = New Collection
    End Sub

    Public Function get_Lista()
        Return listaUsuarios
    End Function

    Public Sub readAll(ruta As String)
        Dim Usuario As Usuarios
        Dim col, aux As Collection
        col = AgenteBD.getAgente(ruta).leer("SELECT * FROM Usuarios ORDER BY Email")
        For Each aux In col
            Usuario = New Usuarios(aux(1).ToString)
            Usuario.Nombre = aux(2).ToString
            Usuario.Apellidos = aux(3).ToString
            Usuario.Fecha = aux(4).ToString
            Me.listaUsuarios.Add(Usuario)
        Next
    End Sub

    Public Sub read(ByRef usuario As Usuarios)
        Dim col As Collection
        Dim aux As Collection
        col = AgenteBD.getAgente.leer("SELECT * FROM Usuarios WHERE Email='" & usuario.Email & "';")
        For Each aux In col
            usuario.Email = aux(1).ToString
            usuario.Nombre = aux(2).ToString
            usuario.Apellidos = aux(3).ToString
            usuario.Fecha = aux(4).ToString
        Next
    End Sub
    Function leerEmailCliente(ByRef email As Usuarios) As String
        Dim col As Collection
        Dim aux As Collection
        col = AgenteBD.getAgente.leer("SELECT Email FROM Usuarios WHERE Email='" & email.Email & "' ; ")
        For Each aux In col
            email.Email = aux(1).ToString
        Next
        Return email.Email
    End Function
    Public Function insert(ByRef usuario As Usuarios) As Integer
        Return AgenteBD.getAgente().modificar("INSERT INTO Usuarios VALUES('" & usuario.Email & "', '" & usuario.Nombre & "', '" & usuario.Apellidos & "', '" & usuario.Fecha & "');")
    End Function
    Public Function modify(ByVal usuario As Usuarios) As Integer
        Return AgenteBD.getAgente().modificar("UPDATE Usuarios SET EMAIL='" & usuario.Email & "', NOMBRE='" & usuario.Nombre & "', APELLIDOS='" & usuario.Apellidos & "', FECHANACIMIENTO='" & usuario.Fecha & "';")
    End Function
    Public Function delete(ByVal usuario As Usuarios) As Integer
        Return AgenteBD.getAgente().modificar("DELETE FROM Usuarios WHERE Email='" & usuario.Email & "';")
    End Function
    Public Function BorrarArtistasFavoritos(ByVal usuario As Usuarios) As Integer
        Return AgenteBD.getAgente().modificar("DELETE FROM Artistas_Favoritos WHERE Usuarios LIKE '" & usuario.Email & "';")
    End Function
    Public Function LeerArtistaFavorito(ByVal usuario As Usuarios, a As Artistas) As Boolean
        Dim col, aux As Collection
        Dim fav As Boolean = False
        col = AgenteBD.getAgente().leer("SELECT * FROM ARTISTAS_FAVORITOS WHERE Usuario= '" & usuario.Email & "';")
        For Each aux In col
            If a.IdArtista = aux(2) Then
                fav = True
            End If
        Next
        Return fav
    End Function
    Public Function MarcarFavorito(ByVal usuario As Usuarios, a As Artistas) As Integer
        Dim fecha As String
        fecha = Format(Now(), "dd/MM/yyyy")
        Return AgenteBD.getAgente.modificar("INSERT INTO Artistas_Favoritos VALUES ('" & usuario.Email & "', '" & a.IdArtista & "', '" & CDate(fecha) & "');")
    End Function
    Public Function DesmarcarFavorito(ByVal usuario As Usuarios, a As Artistas) As Integer
        Return AgenteBD.getAgente.modificar("DELETE FROM Artistas_favoritos WHERE Usuario LIKE '" & usuario.Email & "' AND Artista LIKE '" & a.IdArtista & "';")
    End Function
    Public Sub ordenarActivo(ruta As String)
        Dim usuario As Usuarios
        Dim col As Collection
        Dim aux As Collection
        col = AgenteBD.getAgente.leer("SELECT u.Email FROM USUARIOS u, REPRODUCCIONES r, CANCIONES c WHERE c.idCancion=r.Cancion AND r.Usuario=u.Email GROUP BY u.EMAIL ORDER BY sum(c.Duracion) DESC")
        For Each aux In col
            usuario = New Usuarios(aux(1).ToString)
            usuario.Email = aux(1).ToString
            Me.listaUsuarios.Add(usuario)
        Next
    End Sub
    Public Function ArtistasMasEscuchados(ByVal usuario As Usuarios, Fecha1 As Date, Fecha2 As Date) As Collection
        Dim col, aux, retorno As Collection
        retorno = New Collection()
        col = AgenteBD.getAgente(ruta).leer("SELECT ar.Nombre, COUNT(c.duracion) FROM ARTISTAS ar, ALBUMES al, CANCIONES c, REPRODUCCIONES r WHERE
r.Cancion = c.IdCancion AND c.Album = al.IdAlbum AND al.Artista = ar.IdArtista AND r.Usuario LIKE '" & usuario.Email & "' AND (r.Fecha BETWEEN #" & Fecha1 & "# AND #" & Fecha2 & "#) GROUP BY ar.Nombre ORDER BY 2 DESC;")
        For Each aux In col
            retorno.Add(aux(1))
        Next
        Return retorno
    End Function

End Class
