﻿Public Class GestorBBDD
    Public Sub New()
        comprobarBBDD()
    End Sub
    Public Sub comprobarBBDD()
        leerAlbumnes()
        leerArtistas()
        leerArtistas_Fav()
        leerCanciones()
        leerReproducciones()
        leerUsuarios()
    End Sub

    Public Sub leerAlbumnes()
        AgenteBD.getAgente().leer("SELECT * FROM Albumes")
    End Sub
    Public Sub leerArtistas()
        AgenteBD.getAgente().leer("SELECT * FROM Artistas")
    End Sub
    Public Sub leerArtistas_Fav()
        AgenteBD.getAgente().leer("SELECT * FROM Artistas_Favoritos")
    End Sub
    Public Sub leerCanciones()
        AgenteBD.getAgente().leer("SELECT * FROM Canciones")
    End Sub
    Public Sub leerReproducciones()
        AgenteBD.getAgente().leer("SELECT * FROM Reproducciones")
    End Sub
    Public Sub leerUsuarios()
        AgenteBD.getAgente().leer("SELECT * FROM Usuarios")
    End Sub

End Class
