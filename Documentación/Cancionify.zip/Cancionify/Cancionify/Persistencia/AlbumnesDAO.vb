﻿Imports System.Data.OleDb
Imports System.Collections
Public Class AlbumnesDAO
    Public ReadOnly Property _listaAlbum As Collection

    Public Sub New()
        Me._listaAlbum = New Collection
    End Sub
    Public ReadOnly Property listaAlbum As Collection
        Get
            Return _listaAlbum
        End Get
    End Property

    Public Sub readID(ByRef album As Albumnes)
        Dim lista As OleDbDataReader
        lista = AgenteBD.getAgente().leer2("SELECT * FROM ALBUMES WHERE IdAlbum = (SELECT MAX(IdAlbum) from Albumes);")
        If lista.Read() Then
            album.IdAlbum = lista(0)
        End If
    End Sub
    Public Sub read(ByRef album As Albumnes)
        Dim col As Collection
        Dim aux As Collection
        col = AgenteBD.getAgente.leer("SELECT * FROM Albumes WHERE Nombre='" & album.Nombre & "';")
        For Each aux In col
            album.IdAlbum = CInt(aux(1))
            album.Nombre = aux(2).ToString
            album.Fecha = aux(3).ToString
            album.Artista = New Artistas(CInt(aux(4)))
        Next
    End Sub
    Public Sub obtenerAlbum(ByRef album As Albumnes)
        Dim col As Collection
        Dim aux As Collection
        col = AgenteBD.getAgente.leer("SELECT * FROM Albumes WHERE IdAlbum=" & album.IdAlbum & ";")
        For Each aux In col
            album.IdAlbum = CInt(aux(1))
            album.Nombre = aux(2).ToString
            album.Fecha = aux(3).ToString
            album.Artista = New Artistas(CInt(aux(4)))
        Next
    End Sub
    Public Sub readAll(ruta As String)
        Dim albumes As Albumnes
        Dim col, aux As Collection
        col = AgenteBD.getAgente(ruta).leer("SELECT * FROM Albumes ORDER BY IdAlbum")
        For Each aux In col
            albumes = New Albumnes(CInt(aux(1)), aux(2).ToString, aux(3), CInt(aux(4)))
            ''albumes.Nombre = aux(2).ToString
            ''albumes.Fecha = aux(3).ToString
            ''albumes.Artista = New Artistas(CInt(aux(4)))

            Me.listaAlbum.Add(albumes)
        Next
    End Sub
    Public Function insertar(album As Albumnes) As Integer
        Return AgenteBD.getAgente().modificar("INSERT INTO ALBUMES (Nombre,Fecha,Artista) VALUES ('" & album.Nombre & "', '" & album.Fecha.ToString & "', '" & album.Artista.IdArtista.ToString & "');") 'Se quita la comilla simple en saldopuntos
    End Function
    Public Function modificar(album As Albumnes) As Integer
        Return AgenteBD.getAgente().modificar("UPDATE ALBUMES SET NOMBRE = '" & album.Nombre & "', FECHA = '" & album.Fecha & "', ARTISTA = '" & album.Artista.IdArtista.ToString & "' WHERE IdAlbum= " & album.IdAlbum & ";")
    End Function

    Public Function borrar(ByVal album As Albumnes) As Integer
        Return AgenteBD.getAgente().modificar("DELETE FROM ALBUMES WHERE Nombre='" & album.Nombre & "';")
    End Function
End Class

