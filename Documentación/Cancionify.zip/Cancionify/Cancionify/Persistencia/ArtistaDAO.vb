﻿Imports System.Data.OleDb
Imports System.Collections

Public Class ArtistaDAO
    Public ReadOnly Property _listArtistas As Collection
    Public Sub New()
        Me._listArtistas = New Collection
    End Sub
    Public ReadOnly Property listaAlbum As Collection
        Get
            Return _listArtistas
        End Get
    End Property
    Public Sub readAll()
        Dim artista As Artistas
        Dim col, aux As Collection
        col = AgenteBD.getAgente().leer("SELECT * FROM Artistas ORDER BY IdArtista")
        For Each aux In col
            artista = New Artistas(CInt(aux(1)), aux(2).ToString, aux(3).ToString)
            Me._listArtistas.Add(artista)
        Next
    End Sub
    Public Sub read(ByRef artistas As Artistas)
        Dim col As Collection
        Dim aux As Collection
        col = AgenteBD.getAgente.leer("SELECT * FROM Artistas WHERE Nombre='" & artistas.Nombre & "';")
        For Each aux In col
            artistas.Nombre = aux(2).ToString
            artistas.Pais = aux(3).ToString
            artistas.IdArtista = CInt(aux(1))
        Next
    End Sub
    Public Sub readArtist(ByRef artistas As Artistas)
        Dim col As Collection
        Dim aux As Collection
        col = AgenteBD.getAgente.leer("SELECT * FROM Artistas WHERE IdArtista=" & artistas.IdArtista & ";")
        For Each aux In col
            artistas.IdArtista = CInt(aux(1))
            artistas.Nombre = aux(2).ToString
            artistas.Pais = aux(3).ToString
        Next
    End Sub
    Public Sub ordenarPais(ruta As String)
        Dim artista As Artistas
        Dim col As Collection
        Dim aux As Collection
        col = AgenteBD.getAgente.leer("SELECT * FROM Artistas ORDER BY Pais")
        For Each aux In col
            artista = New Artistas(CInt(aux(1)))
            artista.Nombre = aux(2)
            artista.Pais = aux(3)
            Me._listArtistas.Add(artista)
        Next
    End Sub
    Public Sub ordenarNRepr(pais As String)
        Dim col As Collection
        Dim aux As Collection
        col = AgenteBD.getAgente.leer("SELECT ar.Nombre, COUNT(r.IdReproduccion) FROM ARTISTAS ar, REPRODUCCIONES r, CANCIONES c, ALBUMES alb WHERE c.idcancion = r.cancion AND alb.idalbum = c.album AND ar.idartista = alb.Artista AND ar.Pais LIKE '" & pais & "' GROUP BY ar.Nombre ORDER BY 2 DESC;")
        For Each aux In col
            ''artista = New Artistas(CInt(aux(1)), aux(2), aux(3))
            Me._listArtistas.Add(aux(1))
        Next
    End Sub
    Public Sub ordenarNRepr()
        Dim col As Collection
        Dim aux As Collection
        col = AgenteBD.getAgente.leer("SELECT ar.Nombre, COUNT(r.IdReproduccion) FROM ARTISTAS ar, REPRODUCCIONES r, CANCIONES c, ALBUMES alb WHERE c.idcancion = r.cancion AND alb.idalbum = c.album AND ar.idartista = alb.Artista GROUP BY ar.Nombre ORDER BY 2 DESC;")
        For Each aux In col
            Me._listArtistas.Add(aux(1))
        Next
    End Sub
    Public Sub readID(ByRef Artista As Artistas)
        Dim lista As OleDbDataReader
        lista = AgenteBD.getAgente().leer2("SELECT * FROM Artistas WHERE IdArtista = (SELECT MAX(IdArtista) from Artistas);")
        If lista.Read() Then
            Artista.IdArtista = lista(0)
        End If
    End Sub
    Public Function delete(artista As Artistas) As Integer
        Return AgenteBD.getAgente().modificar("DELETE FROM ARTISTAS WHERE Nombre='" & artista.Nombre & "';")
    End Function

    Public Function update(artista As Artistas) As Integer
        Return AgenteBD.getAgente().modificar("UPDATE ARTISTAS SET NOMBRE='" & artista.Nombre & "', PAIS='" & artista.Pais & "' WHERE IdArtista=" & artista.IdArtista & ";")
    End Function

    Public Function insert(artista As Artistas) As Integer
        Return AgenteBD.getAgente().modificar("INSERT INTO ARTISTAS (Nombre, Pais) VALUES ('" & artista.Nombre & "', '" & artista.Pais & "');")
    End Function







End Class