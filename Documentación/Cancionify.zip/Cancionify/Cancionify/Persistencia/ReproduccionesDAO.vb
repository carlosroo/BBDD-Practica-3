﻿Imports System.Data.OleDb
Imports System.Collections
Public Class ReproduccionesDAO
    Private _listaReprod As Collection
    Private Agente As AgenteBD = AgenteBD.getAgente
    Public Sub New()
        Me._listaReprod = New Collection
    End Sub
    Public ReadOnly Property ListaReprod As Collection
        Get
            Return _listaReprod
        End Get
    End Property
    Public Sub readID(ByRef reproduc As Reproducciones)
        Dim lista As OleDbDataReader
        lista = AgenteBD.getAgente().leer2("SELECT * FROM Reproducciones WHERE IdReproduccion = (SELECT MAX(IdReproduccion) from Reproducciones);")
        If lista.Read() Then
            reproduc.idRepr = lista(0)
        End If
    End Sub
    Public Sub read(ByRef reproc As Reproducciones)
        Dim lista As OleDbDataReader
        lista = AgenteBD.getAgente().leer2("SELECT * FROM Reproducciones WHERE IdReproudccion = " & reproc.idRepr & ";")
        If lista.Read() Then
            reproc.idRepr = lista(1)
            reproc.Usuario.Email = lista(2)
            reproc.Cancion.IdCancion = lista(3)
            reproc.Fecha = lista(3)
        End If
    End Sub
    Public Sub leertodo(ruta As String)
        Dim reprod As Reproducciones
        Dim lista, aux As Collection
        lista = AgenteBD.getAgente(ruta).leer("SELECT * FROM Reproducciones ORDER BY IdReproduccion")
        For Each aux In lista
            reprod = New Reproducciones(aux(1), aux(2), aux(3), aux(4))
            Me._listaReprod.Add(reprod)
        Next
    End Sub
    Public Sub cancionesUser(ruta As String, email As String)
        Dim reprod As Reproducciones
        Dim lista, aux As Collection
        lista = AgenteBD.getAgente(ruta).leer("SELECT * FROM Reproducciones WHERE Usuario='" & email & "' ORDER BY Cancion")
        For Each aux In lista
            reprod = New Reproducciones(aux(1), aux(2), aux(3), aux(4))
            Me._listaReprod.Add(reprod)
        Next
    End Sub
    Public Function insertar(ByRef repr As Reproducciones) As Integer
        Return AgenteBD.getAgente().modificar("INSERT INTO Reproducciones (Usuario,Cancion,Fecha) VALUES ('" & repr.Usuario.Email & "', '" & repr.Cancion.IdCancion & "', '" & repr.Fecha & "');") 'Se quita la comilla simple en saldopuntos
    End Function
    Public Function modificar(ByVal repr As Reproducciones) As Integer
        Return AgenteBD.getAgente().modificar("UPDATE Reproducciones Set ='" & repr.Usuario.Email & "'WHERE IdReproudccion=" & repr.idRepr & ";")
    End Function
    Public Function borrar(ByVal repr As Reproducciones) As Integer
        Return AgenteBD.getAgente().modificar("DELETE FROM Reproducciones WHERE IdReproudccion=" & repr.idRepr & ";")
    End Function
    Public Sub tiempoFav(ruta As String)
        Dim col As Collection
        Dim aux As Collection
        Dim u As Usuarios = New Usuarios()
        col = AgenteBD.getAgente.leer("SELECT IdReproduccion, Usuario, Cancion, Fecha FROM REPRODUCCIONES WHERE usuario LIKE '" & u.Email & "' AND cancion IN (SELECT IdReproduccion FROM CANCIONES WHERE album IN (SELECT IdAlbum FROM ALBUMES WHERE artista IN (SELECT IdArtista FROM ARTISTAS WHERE IdArtista IN (SELECT artista FROM ARTISTAS_FAVORITOS WHERE usuario LIKE '" & u.Email & "'))));")
        For Each aux In col
            Me._listaReprod.Add(aux(1).ToString)
        Next
    End Sub

End Class
