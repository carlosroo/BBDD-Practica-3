﻿Public Class Reproducciones
    Private Property mIdReproudccion As Integer
    Private Property mUsuario As Usuarios
    Private Property mCancion As Canciones
    Private Property mFecha As Date
    Public ReadOnly Property gestorReproducciones As ReproduccionesDAO
    Public ReadOnly Property mcancionDAO As CancionesDAO

    Sub New(idReprod As Integer, User As String, IdCancion As Integer, fecha As Date)
        mIdReproudccion = idReprod
        mUsuario = New Usuarios(User)
        mCancion = New Canciones(IdCancion)
        mCancion.obtenerCancion()
        mUsuario.leer()
        mFecha = fecha
        gestorReproducciones = New ReproduccionesDAO
    End Sub
    Sub New(User As String, IdCancion As Integer, fecha As Date)
        mUsuario = New Usuarios(User)
        mCancion = New Canciones(IdCancion)
        mCancion.obtenerCancion()
        mUsuario.leer()
        mFecha = fecha
        gestorReproducciones = New ReproduccionesDAO
    End Sub
    Sub New()
        gestorReproducciones = New ReproduccionesDAO
    End Sub
    Public Property Fecha As Date
        Get
            Return mFecha
        End Get
        Set(value As Date)
            mFecha = value
        End Set
    End Property
    Public Property idRepr As Integer
        Get
            Return mIdReproudccion
        End Get
        Set(value As Integer)
            mIdReproudccion = value
        End Set
    End Property
    Public Property Usuario As Usuarios
        Get
            Return mUsuario
        End Get
        Set(value As Usuarios)
            mUsuario = value
        End Set
    End Property
    Public Property Cancion As Canciones
        Get
            Return mCancion
        End Get
        Set(value As Canciones)
            mCancion = value
        End Set
    End Property
    Public ReadOnly Property repDAO As ReproduccionesDAO
        Get
            Return Me.gestorReproducciones
        End Get
    End Property
    Public Sub insertar()
        Me.gestorReproducciones.insertar(Me)
    End Sub
    Public Sub eliminar()
        Me.gestorReproducciones.borrar(Me)
    End Sub
    Public Function modificar() As Integer
        Dim estado As Integer
        estado = Me.gestorReproducciones.modificar(Me)
        Return estado
    End Function
    Public Sub leertodo(ruta As String)
        Me.gestorReproducciones.leertodo(ruta)
    End Sub
    Public Sub cancionesUser(ruta As String, email As String)
        Me.gestorReproducciones.cancionesUser(ruta, email)
    End Sub
    Public Sub leer()
        Me.gestorReproducciones.read(Me)
    End Sub
    Public Sub leerId()
        Me.gestorReproducciones.readID(Me)
    End Sub
    Public Sub tiempoFav(ruta As String)
        Me.gestorReproducciones.tiempoFav(ruta)
    End Sub
End Class
