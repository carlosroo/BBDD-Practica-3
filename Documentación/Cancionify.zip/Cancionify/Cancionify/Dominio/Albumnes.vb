﻿Public Class Albumnes

    Private Property mIdAlbum As Integer
    Private Property mNombre As String
    Private Property mFecha As Date
    Private Property mArtista As Artistas
    ''Public Property Portada As 
    Public ReadOnly Property malbumDAO As AlbumnesDAO

    Sub New(ByRef id As Integer)
        mIdAlbum = id
        Me.malbumDAO = New AlbumnesDAO
        Me.malbumDAO.obtenerAlbum(Me)
    End Sub
    Sub New(id As Integer, nom As String, fecha As Date, idArtist As Integer)
        mIdAlbum = id
        mNombre = nom
        mFecha = fecha
        mArtista = New Artistas(idArtist)
        mArtista.leer()

        Me.malbumDAO = New AlbumnesDAO
    End Sub
    Sub New(nom As String, fecha As Date, idArtist As Integer)
        mNombre = nom
        mFecha = fecha
        mArtista = New Artistas(idArtist)
        Me.malbumDAO = New AlbumnesDAO
        malbumDAO.readID(Me)
    End Sub
    Sub New(nombre As String)
        mNombre = nombre
        Me.malbumDAO = New AlbumnesDAO
    End Sub
    Sub New()
        Me.malbumDAO = New AlbumnesDAO
    End Sub
    Public ReadOnly Property albumDAO As AlbumnesDAO
        Get
            Return Me.malbumDAO
        End Get
    End Property
    Public Property IdAlbum As Integer
        Get
            Return mIdAlbum
        End Get
        Set(value As Integer)
            mIdAlbum = value
        End Set
    End Property
    Public Property Nombre As String
        Get
            Return Me.mNombre
        End Get
        Set(value As String)
            Me.mNombre = value
        End Set
    End Property
    Public Property Fecha As Date
        Get
            Return mFecha
        End Get
        Set(value As Date)
            mFecha = value
        End Set
    End Property
    Public Property Artista As Artistas
        Get
            Return mArtista
        End Get
        Set(value As Artistas)
            mArtista = New Artistas(value.IdArtista)
        End Set
    End Property

    Public ReadOnly Property nombreArtista As String
        Get
            Return mArtista.Nombre
        End Get
    End Property

    Public Sub insertar()
        Me.malbumDAO.insertar(Me)
    End Sub
    Public Sub eliminar()
        Me.malbumDAO.borrar(Me)
    End Sub
    Public Function modificar() As Integer
        Return Me.malbumDAO.modificar(Me)
    End Function
    Public Sub leertodo(ruta As String)
        Me.albumDAO.readAll(ruta)
    End Sub
    Public Sub obtenerAlbum()
        Me.albumDAO.obtenerAlbum(Me)
    End Sub
    Public Sub leer()
        Me.albumDAO.read(Me)
    End Sub
    Public Sub leerId()
        Me.albumDAO.readID(Me)
    End Sub

End Class