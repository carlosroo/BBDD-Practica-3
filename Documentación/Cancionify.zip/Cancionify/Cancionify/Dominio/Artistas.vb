﻿Public Class Artistas
    Private Property mIdArtista As Integer
    Private Property mNombre As String
    Private Property mPais As String
    Public ReadOnly Property mArtistaDAO As ArtistaDAO
    Public ReadOnly Property ArtistasMasEscuchados As String
    Sub New(ByRef IdArtista As Integer)
        mIdArtista = IdArtista
        Me.mArtistaDAO = New ArtistaDAO
    End Sub
    Sub New(nombre As String)
        mNombre = nombre
        Me.mArtistaDAO = New ArtistaDAO
    End Sub
    Sub New(id As String, nom As String, pais As String)
        mIdArtista = id
        mNombre = nom
        mPais = pais
        Me.mArtistaDAO = New ArtistaDAO
    End Sub
    Sub New(nom As String, pais As String)
        mNombre = nom
        mPais = pais
        mArtistaDAO = New ArtistaDAO
    End Sub
    Sub New()
        Me.mArtistaDAO = New ArtistaDAO
    End Sub
    Public Property Nombre As String
        Get
            Return Me.mNombre
        End Get
        Set(value As String)
            Me.mNombre = value
        End Set
    End Property
    Public Property Pais As String
        Get
            Return Me.mPais
        End Get
        Set(value As String)
            Me.mPais = value
        End Set
    End Property
    Public Property IdArtista As Integer
        Get
            Return mIdArtista
        End Get
        Set(value As Integer)
            mIdArtista = value
        End Set
    End Property
    Public Property artistaDAO As ArtistaDAO
        Get
            Return Me.mArtistaDAO
        End Get
        Set(value As ArtistaDAO)
        End Set
    End Property
    Public Sub insertar()
        Me.mArtistaDAO.insert(Me)
    End Sub

    Public Sub eliminar()
        Me.mArtistaDAO.delete(Me)
    End Sub

    Public Sub eliminarArtistas_Favoritos()
        Me.mArtistaDAO.delete(Me)
    End Sub
    Public Function modificar() As Integer
        Return Me.mArtistaDAO.update(Me)
    End Function
    Public Sub leer()
        Me.mArtistaDAO.read(Me)
    End Sub
    Public Sub leerBID()
        Me.mArtistaDAO.readArtist(Me)
    End Sub
    Public Sub readAll()
        Me.mArtistaDAO.readAll()
    End Sub
    Public Sub ordenarPais(ruta As String)
        Me.mArtistaDAO.ordenarPais(ruta)
    End Sub
    Public Sub ordenarNRep(pais As String)
        Me.mArtistaDAO.ordenarNRepr(pais)
    End Sub
    Public Sub ordenarNRep()
        Me.mArtistaDAO.ordenarNRepr()
    End Sub
End Class