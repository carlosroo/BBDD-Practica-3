﻿Public Class Canciones
    Private Property mIdCancion As Integer
    Private Property mNombre As String
    Private Property mDuracion As Integer
    Private Property mAlbum As Albumnes
    Private Property mAlbumnesDAO As AlbumnesDAO

    Public ReadOnly Property mcancionDAO As CancionesDAO

    Sub New(id As Integer, nomb As String, alb As Integer, dura As Integer)
        mIdCancion = id
        mNombre = nomb
        mAlbum = New Albumnes(alb)
        mAlbum.leer()
        mDuracion = dura
        Me.mcancionDAO = New CancionesDAO
    End Sub
    Sub New(nomb As String, alb As Integer, dura As Integer)
        mNombre = nomb
        mAlbum = New Albumnes(alb)
        mDuracion = dura
        Me.mcancionDAO = New CancionesDAO
    End Sub
    Sub New(IdCan As Integer)
        mIdCancion = IdCan
        mAlbum = New Albumnes()
        Me.mcancionDAO = New CancionesDAO
        Me.mcancionDAO.obtenerCancion(Me)
        mAlbum.obtenerAlbum()
    End Sub
    Sub New(nombre As String)
        mNombre = nombre
        mAlbum = New Albumnes()
        Me.mcancionDAO = New CancionesDAO
        mAlbum.obtenerAlbum()
    End Sub
    Sub New()
        Me.mcancionDAO = New CancionesDAO
        mAlbum = New Albumnes()
    End Sub

    Public Property IdCancion As Integer
        Get
            Return Me.mIdCancion
        End Get
        Set(value As Integer)
            Me.mIdCancion = value
        End Set
    End Property
    Public Property Nombre As String
        Get
            Return Me.mNombre
        End Get
        Set(value As String)
            Me.mNombre = value
        End Set
    End Property
    Public Property Album As Albumnes
        Get
            Return mAlbum
        End Get
        Set(value As Albumnes)
            mAlbum = New Albumnes(value.IdAlbum)
        End Set
    End Property
    Public Property Duracion As Integer
        Get
            Return Me.mDuracion
        End Get
        Set(value As Integer)
            Me.mDuracion = value
        End Set
    End Property
    Public ReadOnly Property CancionDAO As CancionesDAO
        Get
            Return Me.mcancionDAO
        End Get
    End Property
    Public Sub insertar()
        Me.cancionDAO.insert(Me)
    End Sub

    Public Sub eliminar()
        Me.cancionDAO.delete(Me)
    End Sub
    Public Function modificar() As Integer
        Return Me.cancionDAO.update(Me)
    End Function
    Public Sub obtenerCancion()
        Me.CancionDAO.obtenerCancion(Me)
    End Sub
    Public Sub leer()
        Me.cancionDAO.read(Me)
    End Sub
    Public Sub leertodo(ruta As String)
        Me.cancionDAO.readAll(ruta)
    End Sub

    Public Sub leerID()
        Me.cancionDAO.readID(Me)
    End Sub
    Public Sub ordenarRepr(ruta As String)
        Me.CancionDAO.ordenarNRepr(ruta)
    End Sub
End Class
