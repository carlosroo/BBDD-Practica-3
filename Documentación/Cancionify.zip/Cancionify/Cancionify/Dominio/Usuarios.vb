﻿Public Class Usuarios
    Private Property mEmail As String
    Private Property mNombre As String
    Private Property mApellidos As String
    Private Property mFechaNacimiento As String
    Public ReadOnly Property gestorUsuario As GestorUsuario

    Public Sub New()
        Me.gestorUsuario = New GestorUsuario
    End Sub
    Public Sub New(email As String)
        Me.gestorUsuario = New GestorUsuario
        Me.mEmail = email
    End Sub
    Sub New(eml As String, nom As String, apell As String, feNa As String)
        mEmail = eml
        mNombre = nom
        mApellidos = apell
        mFechaNacimiento = feNa
    End Sub
    Public Property Email As String
        Get
            Return Me.mEmail
        End Get
        Set(value As String)
            Me.mEmail = value
        End Set
    End Property
    Public Property Fecha As String
        Get
            Return Me.mFechaNacimiento
        End Get
        Set(value As String)
            Me.mFechaNacimiento = value
        End Set
    End Property
    Public Property Apellidos As String
        Get
            Return Me.mApellidos
        End Get
        Set(value As String)
            Me.mApellidos = value
        End Set
    End Property
    Public Property Nombre As String
        Get
            Return Me.mNombre
        End Get
        Set(value As String)
            Me.mNombre = value
        End Set
    End Property
    Public Sub readAll(ruta As String)
        Me.gestorUsuario.readAll(ruta)
    End Sub
    Public Sub leerCliente(ByVal email As String)
        Me.mEmail = email
        gestorUsuario.read(Me)
    End Sub
    Function leerEmail() As String
        Return Me.gestorUsuario.leerEmailCliente(Me)
    End Function
    Public Sub leer()
        Me.gestorUsuario.read(Me)
    End Sub

    Public Sub Insetar()
        Me.gestorUsuario.insert(Me)
    End Sub

    Public Sub Borrar()
        Me.gestorUsuario.delete(Me)
    End Sub

    Public Sub BorrarArtistasFavoritos()
        Me.gestorUsuario.delete(Me)
    End Sub
    Public Sub MarcarFavorito(a As Artistas)
        Me.gestorUsuario.MarcarFavorito(Me, a)
    End Sub
    Public Sub DesmarcarFavorito(a As Artistas)
        Me.gestorUsuario.DesmarcarFavorito(Me, a)
    End Sub
    Public Function actualizarUsuario() As Integer
        Return Me.gestorUsuario.modify(Me)
    End Function
    Public Sub ordenarMasActivo(ruta As String)
        Me.gestorUsuario.ordenarActivo(ruta)
    End Sub

    Public Function ArtistasMasEscuchados(Fecha1 As Date, Fecha2 As Date) As Collection
        Return Me.gestorUsuario.ArtistasMasEscuchados(Me, Fecha1, Fecha2)
    End Function
End Class
