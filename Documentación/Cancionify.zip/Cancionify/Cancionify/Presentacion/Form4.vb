﻿Imports System.IO
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports System.DateTime
Imports System.Math
Public Class Form4
    Private artista As Artistas
    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActualizarListas()
        Label1.Visible = False
        Label38.Visible = False
        Button19.Visible = False
        Button8.Enabled = False
        Button1.Enabled = False
        Button5.Enabled = False
        Button10.Enabled = False
        Button21.Enabled = False
        Button12.Enabled = False
        Button3.Enabled = False
        Button24.Enabled = False
        Button13.Enabled = False
        Call cargarIdArtistas()
        Call cargaridAlbum()
        ActualizarHistorial()
    End Sub
    Private Sub ActualizarListas()
        Dim artistas As Artistas
        artistas = New Artistas()
        Dim canciones As Canciones
        canciones = New Canciones()
        Dim album As Albumnes
        album = New Albumnes()
        Dim usu As Usuarios
        usu = New Usuarios()

        ruta = Module1.ruta
        ListBox1.Items.Clear()
        ListBox2.Items.Clear()
        ListBox3.Items.Clear()
        ListBox5.Items.Clear()
        ListBox6.Items.Clear()
        ListBox8.Items.Clear()
        Label33.Text = String.Empty

        Try
            artistas.readAll()
            canciones.leertodo(ruta)
            album.leertodo(ruta)
            usu.readAll(ruta)

            For Each artist As Artistas In artistas.artistaDAO._listArtistas()
                ListBox1.Items.Add(artist.Nombre)
                ListBox6.Items.Add(artist.Nombre)
                ComboBox3.Items.Add(artist.Pais)
            Next
            For Each song As Canciones In canciones.CancionDAO._listaCanciones()
                ListBox2.Items.Add(song.Nombre)
                ListBox8.Items.Add(song.Nombre)
            Next
            For Each alb As Albumnes In album.albumDAO.listaAlbum()
                ListBox3.Items.Add(alb.Nombre)
            Next
            For Each us As Usuarios In usu.gestorUsuario.listaUsuarios()
                ListBox5.Items.Add(us.Email)
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub
    Public Sub ActualizarHistorial() ''reproducciones
        ListBox4.Items.Clear()

        Dim repros As Reproducciones = New Reproducciones()
        Dim repro As Reproducciones = New Reproducciones()
        repros.leertodo(ruta)
        For Each repro In repros.gestorReproducciones.ListaReprod
            If repro.Usuario.Email = TextBox12.Text Then
                ListBox4.Items.Add(repro.Cancion.Nombre + vbTab + repro.Fecha)
            End If
        Next
    End Sub
    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        If ListBox1.SelectedItem IsNot Nothing Then
            listInfoAlbumArtista.Items.Clear()
            ListBox3.Items.Clear()
            Dim art As Artistas = New Artistas(ListBox1.SelectedItem.ToString)
            Dim album As Albumnes
            album = New Albumnes()
            Dim canciones As Canciones
            canciones = New Canciones()
            Try
                art.leer()
                If Form2.UsuarioActual.gestorUsuario.LeerArtistaFavorito(Form2.UsuarioActual, art) Then
                    Label33.Text = "Sí"
                Else
                    Label33.Text = "No"
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End Try

            TextBox4.Text = art.Nombre
            TextBox5.Text = art.Pais
            TextBox20.Text = art.IdArtista.ToString
            album.leertodo(Module1.ruta)
            canciones.leertodo(Module1.ruta)
            Dim albums As Collection
            albums = New Collection
            Dim albm As Albumnes
            For Each albm In album.albumDAO.listaAlbum()
                If art.IdArtista = albm.Artista.IdArtista Then
                    ListBox3.Items.Add(albm.Nombre)
                    listInfoAlbumArtista.Items.Add(albm.Nombre)
                    albums.Add(albm)
                End If
            Next
            ListBox2.Items.Clear()
            Dim ca As Canciones
            For Each ca In canciones.mcancionDAO._listaCanciones()
                For Each albm In albums
                    If ca.Album.IdAlbum = albm.IdAlbum Then
                        ListBox2.Items.Add(ca.Nombre)
                    End If
                Next
            Next
        Else
            ActualizarListas()
        End If
        Button1.Enabled = True
    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim a As Artistas = New Artistas(ListBox1.SelectedItem.ToString)
        a.leer()
        If Form2.UsuarioActual.gestorUsuario.LeerArtistaFavorito(Form2.UsuarioActual, a) Then
            Try
                Form2.UsuarioActual.DesmarcarFavorito(a)
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End Try
            Label33.Text = "No"
        Else
            Try
                Form2.UsuarioActual.MarcarFavorito(a)
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End Try
            Label33.Text = "Sí"
        End If
    End Sub
    Private Sub ListBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox2.SelectedIndexChanged
        If ListBox2.SelectedItem IsNot Nothing Then
            Dim can As Canciones = New Canciones(ListBox2.SelectedItem.ToString)
            Dim album As Albumnes
            album = New Albumnes()
            Try
                can.leer()
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End Try
            Dim t As TimeSpan = TimeSpan.FromSeconds(can.Duracion)
            TextBox7.Text = can.Nombre
            TextBox6.Text = t.Days.ToString() + ":" + t.Hours.ToString() + ":" + t.Minutes.ToString() + ":" + t.Seconds.ToString()
            TextBox23.Text = can.IdCancion.ToString
            album.leertodo(Module1.ruta)
            Dim albm As Albumnes
            For Each albm In album.albumDAO.listaAlbum()
                If can.Album.IdAlbum = albm.IdAlbum Then
                    TextBox2.Text = albm.Nombre
                End If
            Next
        End If
        Button8.Enabled = True
        Button5.Enabled = True
    End Sub
    Private Sub CalcularTiempo(segs As Integer)
        Dim t As TimeSpan = TimeSpan.FromSeconds(segs)
        TextBoxDuraAlbum.Text = t.Days.ToString() + ":" + t.Hours.ToString() + ":" + t.Minutes.ToString() + ":" + t.Seconds.ToString()
    End Sub
    Private Sub ListBox3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox3.SelectedIndexChanged
        If ListBox3.SelectedItem IsNot Nothing Then
            ListBox2.Items.Clear()
            Dim alb As Albumnes = New Albumnes(ListBox3.SelectedItem.ToString)
            Dim artistas As Artistas
            artistas = New Artistas()
            Dim canc = New Canciones()
            Try
                alb.leer()
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End Try
            artistas.readAll()
            TextBox8.Text = alb.Nombre.ToString
            TextBox3.Text = alb.Fecha.ToString
            TextBox24.Text = alb.IdAlbum.ToString
            Dim arts As Artistas
            For Each arts In artistas.artistaDAO._listArtistas()
                If arts.IdArtista = alb.Artista.IdArtista Then
                    TextBox9.Text = arts.Nombre
                End If
            Next

            canc.leertodo(Module1.ruta)
            Dim ca As Canciones
            Dim segTotal As String
            segTotal = 0
            For Each ca In canc.mcancionDAO._listaCanciones()
                If ca.Album.IdAlbum = alb.IdAlbum Then
                    ListBox2.Items.Add(ca.Nombre)
                    segTotal += ca.Duracion
                End If
            Next
            CalcularTiempo(segTotal)
        Else
            ListBox1_SelectedIndexChanged(sender, e)
        End If
        Button10.Enabled = True
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs)
        ListBox1.Items.Clear()
        Dim artistas As Artistas = New Artistas()
        Try
            artistas.ordenarPais(ruta)

            For Each artist As Artistas In artistas.artistaDAO._listArtistas()
                ListBox1.Items.Add(artist.Nombre)
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

    Private Sub BorrarArtista_Click(sender As Object, e As EventArgs) Handles BorrarArtista.Click
        Dim art As Artistas = New Artistas
        Dim alb As Albumnes = New Albumnes
        Try
            Dim artis As Artistas = New Artistas(ListBox1.SelectedItem.ToString)
            art.artistaDAO.delete(artis)
            ListBox1.Items.Remove(art)

            ListBox1.Items.Remove(artis.Nombre)
            MessageBox.Show("El artista se ha eliminado correctamente")
        Catch ex As Exception
            MessageBox.Show("Este artista no se puede eliminar por que esta incluido en Album")
        End Try
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub ButtAddArtist_Click(sender As Object, e As EventArgs) Handles ButtAddArtist.Click
        Dim nombre As String = TextBox13.Text
        Dim pais As String = TextBox19.Text
        Dim artistas As Artistas
        artistas = New Artistas()
        artistas.readAll()
        Dim lista As Boolean = True
        If (TextBox13.Text = Nothing Or TextBox19.Text = Nothing) Then
            MsgBox("Introduzca el/los datos restantes para poder añadir el artista")
            Return
        ElseIf (lista) Then
            Dim art As Artistas = New Artistas(nombre, pais)
            artistas.artistaDAO.insert(art)
            art.mArtistaDAO.read(art)
            ListBox1.Items.Add(art.Nombre)
            MessageBox.Show("El artista se ha insertado correctamente")
        End If
        cargarIdArtistas()
    End Sub
    Private Sub ButtAddAlbum_Click(sender As Object, e As EventArgs) Handles ButtAddAlbum.Click
        Dim nombre As String = TextBox17.Text
        Dim fecha As String = DateTimePicker1.Text
        Dim idArtist As String = (ComboBox1.SelectedIndex + 1).ToString
        Dim album As Albumnes
        album = New Albumnes()
        album.leertodo(Module1.ruta)
        Dim lista As Boolean = True
        If (TextBox17.Text = Nothing Or DateTimePicker1.Text = Nothing Or ComboBox1.SelectedIndex.ToString = Nothing) Then
            MsgBox("Introduzca el/los datos restantes para poder añadir el album")
            Return
        ElseIf (lista) Then
            Dim alb As Albumnes = New Albumnes(nombre, fecha, CInt(idArtist))
            album.albumDAO.insertar(alb)
            album.albumDAO.read(alb)
            ListBox3.Items.Add(alb.Nombre)
            MessageBox.Show("El album se ha insertado correctamente")
        End If
        cargaridAlbum()
    End Sub

    Private Sub ButtAddCanc_Click(sender As Object, e As EventArgs) Handles ButtAddCanc.Click
        Dim nombre As String = TextBox15.Text
        Dim idAlb As String = (ComboBox2.SelectedIndex + 1).ToString
        Dim duracion As String = calcularSegundos(TextBox21.Text)
        Dim canciones As Canciones
        canciones = New Canciones()
        canciones.leertodo(Module1.ruta)
        If (TextBox15.Text = Nothing Or ComboBox2.SelectedItem.ToString = Nothing Or TextBox21.Text = Nothing) Then
            MsgBox("Introduzca el/los datos restantes para poder añadir el producto")
            Return
        Else
            Dim can As Canciones = New Canciones(nombre, CInt(idAlb), duracion)
            canciones.CancionDAO.insert(can)
            canciones.CancionDAO.readID(can)
            ListBox2.Items.Add(can.Nombre)
            MessageBox.Show("La canción se ha insertado correctamente")
        End If
        ActualizarListas()

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        ListBox1.ClearSelected()
        TextBox4.Text = Nothing
        TextBox5.Text = Nothing
        listInfoAlbumArtista.Items.Clear()
        Button1.Enabled = False
        ActualizarListas()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        ListBox2.ClearSelected()
        TextBox7.Text = Nothing
        TextBox6.Text = Nothing
        TextBox2.Text = Nothing
        Button5.Enabled = False
        ListBox3_SelectedIndexChanged(sender, e)
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        ListBox3.ClearSelected()
        TextBox8.Text = Nothing
        TextBox3.Text = Nothing
        TextBox9.Text = Nothing
        Button10.Enabled = False
        TextBox24.Text = Nothing

        ListBox1_SelectedIndexChanged(sender, e)
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        TextBox13.Text = Nothing
        TextBox19.Text = Nothing
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        TextBox15.Text = Nothing
        TextBox10.Text = Nothing
        TextBox21.Text = Nothing
    End Sub

    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        TextBox17.Text = Nothing
    End Sub
    Private Sub Button16_Click_1(sender As Object, e As EventArgs)
        ListBox1.Items.Clear()
        Dim artistas As Artistas = New Artistas()
        ruta = Module1.ruta
        Try
            artistas.readAll()
            For Each artist As Artistas In artistas.artistaDAO._listArtistas()
                ListBox1.Items.Add(artist.Nombre)
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub
    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        If ListBox2.SelectedItem IsNot Nothing Then
            Dim canc = ListBox2.SelectedItem.ToString
            Dim canciones As Canciones
            canciones = New Canciones()
            canciones.leertodo(Module1.ruta)
            For Each aux As Canciones In canciones.CancionDAO._listaCanciones()
                If aux.Nombre = canc Then
                    canciones.CancionDAO.delete(aux)
                    MessageBox.Show("La canción se ha eliminado correctamente")
                End If
            Next
            ActualizarListas()
        End If

    End Sub


    Private Sub cargarIdArtistas()
        Me.ComboBox1.Items.Clear()
        Dim artistas As Artistas = New Artistas
        Try
            artistas.readAll()
            For Each artis As Artistas In artistas.artistaDAO._listArtistas()
                Me.ComboBox1.Items.Add(artis.IdArtista.ToString + vbTab + artis.Nombre.ToString)
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try
    End Sub
    Private Sub cargaridAlbum()
        Me.ComboBox2.Items.Clear()
        Dim alb As Albumnes = New Albumnes
        Try
            alb.leertodo(ruta)
            For Each albm As Albumnes In alb.albumDAO._listaAlbum()
                Me.ComboBox2.Items.Add(albm.IdAlbum.ToString + vbTab + albm.Nombre.ToString)
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click

        If ListBox3.SelectedItem IsNot Nothing Then
            Dim album As Albumnes
            album = New Albumnes()
            album.leertodo(Module1.ruta)
            Try
                For Each aux As Albumnes In album.albumDAO.listaAlbum()
                    If aux.Nombre = ListBox3.SelectedItem.ToString Then
                        album.albumDAO.borrar(aux)
                        ListBox3.Items.Remove(aux.Nombre)
                        MessageBox.Show("El album se ha eliminado correctamente")
                    End If
                Next
            Catch
                MessageBox.Show("No se puede eliminar el album porque tiene canciones pertenecientes al mismo")
            End Try
        End If


    End Sub
    Private Sub Button18_Click(sender As Object, e As EventArgs) Handles Button18.Click
        Dim usu As Usuarios
        If Me.TextBox12.Text <> String.Empty Then
            usu = New Usuarios(Form2.ListBox1.SelectedItem.ToString)
            usu.leer()
            usu.Email = TextBox12.Text
            usu.Nombre = TextBox11.Text
            usu.Apellidos = TextBox10.Text
            usu.Fecha = TextBox1.Text
            Try
                If usu.actualizarUsuario() <> 1 Then
                    MessageBox.Show("Error al insertar. Return <>1", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Dim index As Integer = Form2.ListBox1.SelectedIndex
                Form2.ListBox1.Items(index) = usu.Email
                MessageBox.Show(usu.Email.ToString & "Modificado correctamente")
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try
        End If
    End Sub
    Private Sub BotonModificarArtista_Click(sender As Object, e As EventArgs) Handles BotonModificarArtista.Click
        Dim art As Artistas
        If Me.ListBox1.SelectedItem.ToString <> String.Empty Then
            art = New Artistas(ListBox1.SelectedItem.ToString)
            art.leer()
            Dim nombre As String = TextBox4.Text
            Dim pais As String = TextBox5.Text
            Dim idart As String = TextBox20.Text
            Dim artista As Artistas = New Artistas(idart, nombre, pais)

            Try
                artista.modificar()
                Dim index As Integer = ListBox1.SelectedIndex
                ListBox1.Items(index) = art.Nombre
                MessageBox.Show("Modificado correctamente")
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
    Private Function calcularSegundos(tiempo As String) As Integer
        Dim vectoraux() As String
        vectoraux = tiempo.Split(":")
        Dim sD = (CInt(vectoraux(0)) * 3600 * 24)
        Dim sH As Integer = (CInt(vectoraux(1)) * 3600)
        Dim sM As Integer = (CInt(vectoraux(2)) * 60)
        Return sD + sH + sM + CInt(vectoraux(3))
    End Function
    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim can As Canciones
        If Me.ListBox1.SelectedItem.ToString <> String.Empty Then
            can = New Canciones(ListBox2.SelectedItem.ToString)
            can.leer()
            Dim nombre As String = TextBox7.Text
            Dim dura As Integer = calcularSegundos(TextBox6.Text)
            Dim idC As String = TextBox23.Text
            Dim cancion As Canciones = New Canciones(idC, nombre, can.Album.IdAlbum, dura)

            Try
                cancion.modificar()
                MessageBox.Show("Modificado correctamente")
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
        Button5_Click(sender, e)
    End Sub
    Private Sub Button17_Click(sender As Object, e As EventArgs) Handles Button17.Click
        Dim albm As Albumnes
        If Me.ListBox3.SelectedItem.ToString <> String.Empty Then
            albm = New Albumnes(ListBox3.SelectedItem.ToString)
            albm.leer()
            Dim nombre As String = TextBox8.Text
            Dim fe As Date = DateAndTime.DateValue(TextBox3.Text)
            Dim idA As Integer = CInt(TextBox24.Text)
            Dim album As Albumnes = New Albumnes(idA, nombre, fe, albm.Artista.IdArtista)
            Try
                album.modificar()
                MessageBox.Show("Modificado correctamente")
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
        Button10_Click(sender, e)
    End Sub

    Private Sub Button19_Click(sender As Object, e As EventArgs) Handles Button19.Click 'Boton pausar
        Label1.Visible = False
        Label38.Visible = True
        Button8.Visible = True
        Button8.Enabled = True
        Button19.Visible = False
    End Sub
    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click 'Boton reproducir
        Label1.Visible = True
        Button19.Visible = True
        Button19.Enabled = True
        Button8.Visible = False
        Label38.Visible = False
        Dim repro As Reproducciones = New Reproducciones(TextBox12.Text, CInt(TextBox23.Text), Today)
        repro.gestorReproducciones.insertar(repro)
        repro.gestorReproducciones.readID(repro)
        ListBox4.Items.Add(repro.Cancion.Nombre + vbTab + repro.Fecha)
    End Sub

    Public Sub MostrarArtistasMasEscuchado2Fechas(email As String, date1 As Date, date2 As Date)
        Dim resultado As Collection
        Dim aux As String
        ListBox7.Items.Clear()
        Dim User As Usuarios
        User = New Usuarios(email)
        resultado = User.ArtistasMasEscuchados(date1, date2)
        For Each aux In resultado
            ListBox7.Items.Add(aux)
        Next
    End Sub

    Private Sub Button23_Click(sender As Object, e As EventArgs) Handles Button23.Click
        ListBox5.Items.Clear()
        Dim usu As Usuarios = New Usuarios()
        Try
            usu.ordenarMasActivo(ruta)

            MessageBox.Show("Solo se muestran los usuarios que tienen reproducciones, puede ser que no se muestre alguno", "AVISO", MessageBoxButtons.OK, MessageBoxIcon.Information)
            For Each usuar As Usuarios In usu.gestorUsuario.listaUsuarios()
                ListBox5.Items.Add(usuar.Email)

            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
        Button23.Enabled = False
        Button24.Enabled = True
    End Sub

    Private Sub Button24_Click(sender As Object, e As EventArgs) Handles Button24.Click
        ListBox5.Items.Clear()
        Dim usu As Usuarios = New Usuarios()
        Try
            usu.readAll(ruta)
            For Each u As Usuarios In usu.gestorUsuario.listaUsuarios()
                ListBox5.Items.Add(u.Email)
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
        Button23.Enabled = True
        Button24.Enabled = False
    End Sub

    Private Sub Button25_Click(sender As Object, e As EventArgs) Handles Button25.Click
        ListBox6.Items.Clear()
        Dim artistas As Artistas = New Artistas()
        Try
            If ComboBox3.Text <> String.Empty Then
                artistas.ordenarNRep(ComboBox3.Text)
            Else
                artistas.ordenarNRep()
            End If

            For Each artist As String In artistas.artistaDAO._listArtistas()
                ListBox6.Items.Add(artist)
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
        Button21.Enabled = True
        Button25.Enabled = False

    End Sub

    Private Sub Button22_Click_1(sender As Object, e As EventArgs) Handles Button22.Click
        Dim ar As Artistas = New Artistas(ListBox1.Items.ToString)
        Dim email As String = Form2.UsuarioActual.leerEmail()
        MostrarArtistasMasEscuchado2Fechas(email, DateTimePicker2.Value.ToString, DateTimePicker3.Value.ToString)
        Button22.Enabled = False
        Button3.Enabled = True
    End Sub

    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click
        ListBox7.Items.Clear()
        Button22.Enabled = True
        Button3.Enabled = False
    End Sub

    Private Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        ListBox8.Items.Clear()
        Dim canciones As Canciones = New Canciones()
        Try
            canciones.ordenarRepr(ruta)

            For Each can As String In canciones.CancionDAO._listaCanciones()
                ListBox8.Items.Add(can)
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
        Button12.Enabled = True
        Button16.Enabled = False

    End Sub

    Private Sub Button20_Click(sender As Object, e As EventArgs) Handles Button20.Click
        ListBox9.Items.Clear()
        Dim a As Artistas
        Dim u As Usuarios = New Usuarios()
        Dim repro As Reproducciones
        Dim repros As Reproducciones = New Reproducciones()
        Dim duraTotal As Integer
        Dim nombreArtista As String
        nombreArtista = "No ha escuchado a ningún Artista favorito"
        duraTotal = 0
        repros.cancionesUser(ruta, TextBox12.Text)
        For Each repro In repros.gestorReproducciones.ListaReprod
            If a Is Nothing Then
                a = New Artistas(repro.Cancion.Album.Artista.IdArtista())
                a.leer()
                If Form2.UsuarioActual.gestorUsuario.LeerArtistaFavorito(Form2.UsuarioActual, a) Then
                    duraTotal += repro.Cancion.Duracion
                    repro.Cancion.Album.Artista.leerBID()
                    nombreArtista = repro.Cancion.Album.Artista.Nombre()
                End If
            Else
                If a.IdArtista = repro.Cancion.Album.Artista.IdArtista() Then
                    If Form2.UsuarioActual.gestorUsuario.LeerArtistaFavorito(Form2.UsuarioActual, a) Then
                        duraTotal += repro.Cancion.Duracion
                        repro.Cancion.Album.Artista.leerBID()
                        nombreArtista = repro.Cancion.Album.Artista.Nombre()
                    End If
                    a = New Artistas(repro.Cancion.Album.Artista.IdArtista())
                    a.leer()
                Else
                    If duraTotal <> 0 Or nombreArtista = "No ha escuchado a ningún Artista favorito" Then
                        Dim t As TimeSpan = TimeSpan.FromSeconds(duraTotal)
                        ListBox9.Items.Add(nombreArtista + vbTab + t.Days.ToString() + ":" + t.Hours.ToString() + ":" + t.Minutes.ToString() + ":" + t.Seconds.ToString())
                    End If
                    a = New Artistas(repro.Cancion.Album.Artista.IdArtista())
                    a.leer()
                    duraTotal = 0
                    If Form2.UsuarioActual.gestorUsuario.LeerArtistaFavorito(Form2.UsuarioActual, a) Then
                        duraTotal += repro.Cancion.Duracion
                        repro.Cancion.Album.Artista.leerBID()
                        nombreArtista = repro.Cancion.Album.Artista.Nombre()
                    End If
                End If
            End If
        Next
        If duraTotal <> 0 Or nombreArtista = "No ha escuchado a ningún Artista favorito" Then
            Dim t0 As TimeSpan = TimeSpan.FromSeconds(duraTotal)
            ListBox9.Items.Add(nombreArtista + vbTab + t0.Days.ToString() + ":" + t0.Hours.ToString() + ":" + t0.Minutes.ToString() + ":" + t0.Seconds.ToString())
        End If
        Button13.Enabled = True
        Button20.Enabled = False

    End Sub

    Private Sub Button21_Click(sender As Object, e As EventArgs) Handles Button21.Click
        ListBox6.Items.Clear()
        Dim ar As Artistas = New Artistas()
        Try
            ar.readAll()
            For Each a As Artistas In ar.artistaDAO._listArtistas()
                ListBox6.Items.Add(a.Nombre)
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
        Button25.Enabled = True
        Button21.Enabled = False
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        ListBox8.Items.Clear()
        Dim ca As Canciones = New Canciones()
        Try
            ca.leertodo(Module1.ruta)
            For Each song As Canciones In ca.CancionDAO._listaCanciones()
                ListBox8.Items.Add(song.Nombre)
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
        Button16.Enabled = True
        Button12.Enabled = False
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        ListBox9.Items.Clear()
        Button20.Enabled = True
        Button13.Enabled = False
    End Sub



End Class