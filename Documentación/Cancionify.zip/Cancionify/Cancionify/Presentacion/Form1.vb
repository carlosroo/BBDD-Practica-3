﻿Imports System.IO
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports System.DateTime
Imports System.Math
Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.OpenFileDialog1.InitialDirectory = Application.StartupPath
        If (Me.OpenFileDialog1.ShowDialog() = DialogResult.OK) Then
            Button2.Enabled = True
        End If

        Module1.ruta = OpenFileDialog1.FileName
        TextBox1.Text = ruta.ToString
        Button2.Enabled = True
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Module1.ruta = OpenFileDialog1.FileName
        Dim u As Usuarios
        u = New Usuarios()
        Try
            u.readAll(OpenFileDialog1.FileName)
            MessageBox.Show("Conectado correctamente", "aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Button2.Enabled = False
            Button1.Enabled = False
            Button3.Enabled = True
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Button3.Enabled = False
    End Sub
End Class
