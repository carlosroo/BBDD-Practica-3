﻿Imports System.IO
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports System.DateTime
Imports System.Math
Public Class Form2
    Public Shared UsuarioActual As Usuarios
    Dim u As Usuarios
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.u = New Usuarios
        Dim aux As Usuarios = New Usuarios
        ruta = Module1.ruta
        Button1.Enabled = False
        Button3.Enabled = False
        Try
            Me.u.readAll(ruta)
            For Each aux In u.gestorUsuario.listaUsuarios
                ListBox1.Items.Add(aux.Email)
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End Try

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click 'Boton iniciar sesion
        Me.Hide()
        Form4.Show()
        Dim u As Usuarios = New Usuarios(ListBox1.SelectedItem.ToString)
        UsuarioActual = u
        Try
            UsuarioActual.leer()
            MessageBox.Show("Ha iniciado sesion correctamente, disfrute del programa", "aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try
        Form4.ActualizarHistorial()
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        Dim usu As Usuarios
        If Me.ListBox1.SelectedItem IsNot Nothing Then
            usu = New Usuarios(ListBox1.SelectedItem.ToString())
            Try
                usu.leer()
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End Try

            Button1.Enabled = True
            TextBox1.Text = usu.Email.ToString
            TextBox2.Text = usu.Nombre.ToString
            TextBox3.Text = usu.Apellidos.ToString
            TextBox4.Text = usu.Fecha

            Form4.TextBox12.Text = usu.Email.ToString
            Form4.TextBox11.Text = usu.Nombre.ToString
            Form4.TextBox10.Text = usu.Apellidos.ToString
            Form4.TextBox1.Text = usu.Fecha.ToString

        End If
        Button1.Enabled = True
        Button2.Enabled = False
        Button3.Enabled = True


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click 'Boton añadir usuario
        Dim email As String = TextBox1.Text
        Dim nombre As String = TextBox2.Text
        Dim apllido As String = TextBox3.Text
        Dim feNa As String = TextBox4.Text
        Dim usu As Usuarios = New Usuarios()
        usu.readAll(Module1.ruta)
        Dim lista As Boolean = True

        If (TextBox1.Text = Nothing Or TextBox2.Text = Nothing Or TextBox3.Text = Nothing Or TextBox4.Text = Nothing) Then
            MsgBox("Introduzca el/los datos restantes para poder añadir el usuario")
            Return
        ElseIf (ListBox1.Items.Contains(email)) Then
            MessageBox.Show("Este Email de usuario ya se encuentra en la lista")
            lista = False
        ElseIf (lista) Then
            Dim usua As Usuarios = New Usuarios(email, nombre, apllido, feNa)
            usu.gestorUsuario.insert(usua)
            ListBox1.Items.Add(usua.Email)
            MessageBox.Show("El usuario se ha insertado correctamente")
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click 'Boton deseleccionar
        ListBox1.ClearSelected()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        Button1.Enabled = False
        Button3.Enabled = False
        Button2.Enabled = True
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim usu As Usuarios = New Usuarios

        Dim usua As Usuarios = New Usuarios(ListBox1.SelectedItem)
        usu.gestorUsuario.delete(usua)
        ListBox1.Items.Remove(usua.Email)
        MessageBox.Show("El usuario se ha eliminado correctamente")

    End Sub

End Class