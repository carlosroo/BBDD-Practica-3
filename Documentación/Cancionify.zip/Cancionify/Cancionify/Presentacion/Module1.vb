﻿Module Module1
    Public ruta As String
End Module
