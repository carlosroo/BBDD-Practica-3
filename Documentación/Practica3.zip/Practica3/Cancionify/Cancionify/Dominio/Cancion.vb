﻿Public Class Cancion
    Public Property IdCancion As String
    Public Property Nombre As String
    Public Property Album As String
    Public Property Duracion As Integer
    Public ReadOnly Property CanDAO As CancionDAO

    Public Sub New()
        Me.CanDAO = New CancionDAO
    End Sub
    Public Sub New(idCancion As String)
        Me.CanDAO = New CancionDAO
        Me.IdCancion = idCancion

    End Sub
    Public Sub LeerTodasCanciones(ruta As String)
        Me.CanDAO.LeerTodas(ruta)
    End Sub

    Public Sub LeerCancion()
        Me.CanDAO.Leer(Me)
    End Sub

    Public Function InsertarCancion() As Integer
        Return Me.CanDAO.Insertar(Me)
    End Function

    Public Function ActualizarCancion() As Integer
        Return Me.CanDAO.Actualizar(Me)
    End Function

    Public Function BorrarCancion() As Integer
        Return Me.CanDAO.Borrar(Me)
    End Function

End Class
