﻿Public Class Album
    Public Property IdAlbum As String
    Public Property Nombre As String
    Public Property Fecha As String
    Public Property Artista As String
    Public Property Portada As String
    Public ReadOnly Property AlbDAO As AlbumDAO

    Public Sub New()
        Me.AlbDAO = New AlbumDAO
    End Sub
    Public Sub New(idAlbum As String)
        Me.AlbDAO = New AlbumDAO
        Me.IdAlbum = idAlbum

    End Sub
    Public Sub LeerTodosAlbum(ruta As String)
        Me.AlbDAO.LeerTodas(ruta)
    End Sub

    Public Sub LeerAlbum()
        Me.AlbDAO.Leer(Me)
    End Sub

    Public Function InsertarAlbum() As Integer
        Return Me.AlbDAO.Insertar(Me)
    End Function

    Public Function ActualizarAlbum() As Integer
        Return Me.AlbDAO.Actualizar(Me)
    End Function

    Public Function BorrarAlbum() As Integer
        Return Me.AlbDAO.Borrar(Me)
    End Function
End Class
