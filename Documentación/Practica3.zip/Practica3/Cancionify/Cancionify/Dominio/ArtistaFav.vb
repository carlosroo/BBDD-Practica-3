﻿Public Class ArtistaFav
    Public Property Usuario As String
    Public Property Artista As String
    Public Property Fecha As String
    Public ReadOnly Property ArtFavDAO As ArtistaFavDAO

    Public Sub New()
        Me.ArtFavDAO = New ArtistaFavDAO
    End Sub
    Public Sub New(Usuario As String)
        Me.ArtFavDAO = New ArtistaFavDAO
        Me.Usuario = Usuario

    End Sub
    Public Sub LeerTodosArtistasFav(ruta As String)
        Me.ArtFavDAO.LeerTodas(ruta)
    End Sub

    Public Sub LeerArtistaFav()
        Me.ArtFavDAO.Leer(Me)
    End Sub

    Public Function InsertarArtistaFav() As Integer
        Return Me.ArtFavDAO.Insertar(Me)
    End Function

    Public Function BorrarArtistaFav() As Integer
        Return Me.ArtFavDAO.Borrar(Me)
    End Function
End Class
