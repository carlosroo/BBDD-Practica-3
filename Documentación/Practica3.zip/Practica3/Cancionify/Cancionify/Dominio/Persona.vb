﻿Public Class Persona

    Public Property Nombre As String
    Public Property Email As String
    Public Property Apellido As String
    Public Property FechaNacimiento As String
    Public ReadOnly Property PerDAO As PersonaDAO

    Public Sub New()
        Me.PerDAO = New PersonaDAO
    End Sub
    Public Sub New(Email As String)
        Me.PerDAO = New PersonaDAO
        Me.Email = Email

    End Sub
    Public Sub LeerTodasPersonas(ruta As String)
        Me.PerDAO.LeerTodas(ruta)
    End Sub

    Public Sub LeerPersona()
        Me.PerDAO.Leer(Me)
    End Sub

    Public Function InsertarPersona() As Integer
        Return Me.PerDAO.Insertar(Me)
    End Function

    Public Function ActualizarPersona() As Integer
        Return Me.PerDAO.Actualizar(Me)
    End Function

    Public Function BorrarPersona() As Integer
        Return Me.PerDAO.Borrar(Me)
    End Function


End Class
