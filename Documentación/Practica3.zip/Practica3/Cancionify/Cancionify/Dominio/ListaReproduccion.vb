﻿Public Class ListaReproduccion
    Public Property IdRepodruccion As String
    Public Property Usuario As String
    Public Property idCancion As String
    Public Property Fecha As String
    Public ReadOnly Property RepDao As ListaReproduccionDAO

    Public Sub New()
        Me.RepDao = New ListaReproduccionDAO
    End Sub
    Public Sub New(idReproduccion As String)
        Me.RepDao = New ListaReproduccionDAO
        Me.IdRepodruccion = IdRepodruccion

    End Sub
    Public Sub LeerTodasReproducciones(ruta As String)
        Me.RepDao.LeerTodas(ruta)
    End Sub

    Public Sub LeerReproduccion()
        Me.RepDao.Leer(Me)
    End Sub

    Public Function InsertarReproduccion() As Integer
        Return Me.RepDao.Reproducir(Me)
    End Function

End Class
