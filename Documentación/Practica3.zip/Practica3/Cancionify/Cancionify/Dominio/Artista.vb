﻿Public Class Artista
    Public Property IdArtista As String
    Public Property Nombre As String
    Public Property Pais As String
    Public Property Imagen As String
    Public ReadOnly Property ArtDAO As ArtistaDAO

    Public Sub New()
        Me.ArtDAO = New ArtistaDAO
    End Sub
    Public Sub New(idArtista As String)
        Me.ArtDAO = New ArtistaDAO
        Me.IdArtista = idArtista

    End Sub
    Public Sub LeerTodosArtistas(ruta As String)
        Me.ArtDAO.LeerTodas(ruta)
    End Sub

    Public Sub LeerArtista()
        Me.ArtDAO.Leer(Me)
    End Sub

    Public Function InsertarArtista() As Integer
        Return Me.ArtDAO.Insertar(Me)
    End Function

    Public Function ActualizarArtista() As Integer
        Return Me.ArtDAO.Actualizar(Me)
    End Function

    Public Function BorrarArtista() As Integer
        Return Me.ArtDAO.Borrar(Me)
    End Function
End Class
