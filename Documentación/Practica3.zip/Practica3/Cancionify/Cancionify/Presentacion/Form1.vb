﻿Public Class Form1

    Private Sub btnRuta_Click(sender As Object, e As EventArgs) Handles btnRuta.Click
        '' Escoger el directorio en el que se encuentra la bbdd

        Dim OpenVentana As New OpenFileDialog
        OpenVentana.InitialDirectory = Application.StartupPath  ''coger para foto /imagenes/
        ''Si la Ruta es valida se habilida el boton para la conexión con la bbdd


        If OpenVentana.ShowDialog() = DialogResult.OK Then
            txtRuta.Text = OpenVentana.FileName
            btnRuta.Enabled = True

        End If
    End Sub

    Private Sub btnConectar_Click(sender As Object, e As EventArgs) Handles btnConectar.Click
        ''creamos un objeto persona el cual sera un auxiliar
        Dim PAux As Persona = New Persona
        Dim ArtAux As Artista = New Artista
        ''Se leen todas las personas de la bbdd, en caso de que salte una excepcion mostrar mensaje de error junto a la excepcion
        Try
            PAux.LeerTodasPersonas(txtRuta.Text)
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            lblResultado.Text = "Error de conexión"
            lblResultado.ForeColor = Color.Red
            Exit Sub
        End Try

        ''Se añade cada elemento a la listbox
        For Each Pa As Persona In PAux.PerDAO.Personas
            listaUsuarios.Items.Add(Pa.Email)
        Next
        ''Se desabilitan los botones RutaBD y la conexionBD puesto que no se utilizaran mas
        btnRuta.Enabled = False
        btnConectar.Enabled = False

        '' Para la lista de Artistas
        Try
            ArtAux.LeerTodosArtistas(listaUsuarios.SelectedItem)
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            lblResultado.Text = "Error de conexión"
            lblResultado.ForeColor = Color.Red
            Exit Sub
        End Try

        ''Se añade cada elemento a la listbox
        For Each Art As Artista In ArtAux.ArtDAO.Artistas
            listaArtistas.Items.Add(Art.IdArtista + "-" + Art.Nombre)
        Next

    End Sub

    ''Botones Usuario
    Private Sub btnAñadir_Click(sender As Object, e As EventArgs) Handles btnAñadirUsuario.Click
        ''Auxiliar
        Dim PAux As Persona
        ''Comprobar que los campos no estan vacios
        If txtEmail.Text IsNot String.Empty And txtNombreUsuario.Text IsNot String.Empty And txtApellidosUsuario.Text IsNot String.Empty And txtFechaUsuario.Text IsNot String.Empty Then
            ''Creamos la persona con el Email y modificamos su nombre por que este siempre se incializa vacio
            PAux = New Persona(txtEmail.Text)
            PAux.Nombre = txtNombreUsuario.Text
            PAux.Apellido = txtApellidosUsuario.Text
            PAux.Email = txtEmail.Text
            PAux.FechaNacimiento = txtFechaUsuario.Text
            ''Intentamos insertar la persona en la BBDD, en caso de error se muestra al usuario
            Try
                ''metemos en el if la operacion que queremos hacer para hacer la comprobacion de que ha salido bien
                If PAux.InsertarPersona() <> 1 Then
                    MessageBox.Show("Insert Return <> 1", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                Else MessageBox.Show("Se añadió el puto")
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub

            End Try
            ''Se añade la persona a la listbox
            listaUsuarios.Items.Add(PAux.Email)
        End If
    End Sub

    Private Sub btnmodificar_Click(sender As Object, e As EventArgs) Handles btnmodificarUsuario.Click
        Dim PAux As Persona
        If txtEmail.Text IsNot String.Empty And txtNombreUsuario.Text IsNot String.Empty And txtApellidosUsuario.Text IsNot String.Empty And txtFechaUsuario.Text IsNot String.Empty Then
            PAux = New Persona(txtEmail.Text)
            PAux.Nombre = txtNombreUsuario.Text
            PAux.Apellido = txtApellidosUsuario.Text
            PAux.FechaNacimiento = txtFechaUsuario.Text
            Try
                If PAux.ActualizarPersona() <> 1 Then
                    MessageBox.Show("Update Return <> 1", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try
            ''Despues de las comprobaciones mostrar la info al usuario sobre el intento de actualización
            MessageBox.Show("El nombre de la persona " & PAux.Email & " se ha actualizado correctamente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminarUsuario.Click
        Dim PAux As Persona
        If txtEmail.Text IsNot String.Empty Then
            PAux = New Persona(txtEmail.Text)
            '' messagebox eliminar si ok hace si no no lo hase xd
            If MessageBox.Show("¿Desea eliminar a " & PAux.Email & "?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                Try
                    If PAux.BorrarPersona() <> 1 Then
                        MessageBox.Show("Delete Return <> 1", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If
                Catch ex As Exception
                    MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End Try
                '' Se elimina al usuario de la lista 
                listaUsuarios.Items.Remove(PAux.Email)
                '' Se simula un click para limpiar los datos del usuario
                btnLimpiarUsuario.PerformClick()

            End If

        End If
    End Sub

    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiarUsuario.Click
        txtEmail.Text = String.Empty
        txtNombreUsuario.Text = String.Empty
        txtApellidosUsuario.Text = String.Empty
        txtFechaUsuario.Text = String.Empty
        btnAñadirUsuario.Enabled = True
        btnEliminarUsuario.Enabled = False
        btnmodificarUsuario.Enabled = False
    End Sub

    ''Botones Artista
    Private Sub btnAñadirArtista_Click(sender As Object, e As EventArgs) Handles btnAñadirArtista.Click
        ''Auxiliar
        Dim ArtAux As Artista
        ''Comprobar que los campos no estan vacios
        If txtIdArtista.Text IsNot String.Empty And txtNombreArtista.Text IsNot String.Empty And txtNacionalidadArtista.Text IsNot String.Empty Then
            ''Creamos el artista con el nombre modificamos su nombre por que este siempre se incializa vacio
            ArtAux = New Artista(txtIdArtista.Text)
            ArtAux.IdArtista = txtIdArtista.Text
            ArtAux.Nombre = txtNombreArtista.Text
            ArtAux.Pais = txtNacionalidadArtista.Text

            ''Intentamos insertar la persona en la BBDD, en caso de error se muestra al usuario
            Try
                ''metemos en el if la operacion que queremos hacer para hacer la comprobacion de que ha salido bien
                If ArtAux.InsertarArtista() <> 1 Then
                    MessageBox.Show("Insert Return <> 1", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try
            ''Se añade la persona a la listbox
            listaArtistas.Items.Add(ArtAux.IdArtista + "-" + ArtAux.Nombre)
        End If
    End Sub

    Private Sub btnmodificarArtista_Click(sender As Object, e As EventArgs) Handles btnmodificarArtista.Click
        Dim Artaux As Artista
        If txtIdArtista.Text IsNot String.Empty And txtNombreArtista.Text IsNot String.Empty And txtNacionalidadArtista.Text IsNot String.Empty Then

            Artaux = New Artista(txtIdArtista.Text)
            Artaux.Nombre = txtNombreArtista.Text
            Artaux.Pais = txtNacionalidadArtista.Text

            Try
                If Artaux.ActualizarArtista() <> 1 Then
                    MessageBox.Show("Update Return <> 1", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                Else
                    Dim cadena As String = listaArtistas.SelectedItem
                    listaArtistas.Items.Remove(cadena)

                    listaArtistas.Items.Add(Artaux.IdArtista + "-" + Artaux.Nombre)

                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try
            MessageBox.Show("El nombre del Artista " & Artaux.Nombre & " se ha actualizado correctamente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)

        End If
    End Sub

    Private Sub btnEliminarArtista_Click(sender As Object, e As EventArgs) Handles btnEliminarArtista.Click
        Dim Artaux As Artista

        If txtIdArtista.Text IsNot String.Empty And txtNombreArtista.Text IsNot String.Empty Then
            Artaux = New Artista(txtIdArtista.Text)

            '' messagebox eliminar si ok hace si no no lo hase xd
            If MessageBox.Show("¿Desea eliminar a " & Artaux.IdArtista & "?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then

                Try
                    If Artaux.BorrarArtista() <> 1 Then
                        MessageBox.Show("Delete Return <> 1", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    Else
                        '' Se elimina al artista de la lista 
                        listaArtistas.Items.Remove(Artaux.IdArtista + "-" + txtNombreArtista.Text) ''cuidao 

                        '' Se simula un click para limpiar los datos del usuario
                        btnLimpiarArtista.PerformClick()
                    End If


                Catch ex As Exception
                    MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End Try


            End If

        End If
    End Sub

    Private Sub btnLimpiarArtista_Click(sender As Object, e As EventArgs) Handles btnLimpiarArtista.Click
        txtIdArtista.Text = String.Empty
        txtNombreArtista.Text = String.Empty
        txtNacionalidadArtista.Text = String.Empty

        btnAñadirArtista.Enabled = True
        btnEliminarArtista.Enabled = False
        btnmodificarArtista.Enabled = False
    End Sub

    Private Sub btnAñadirFavorito_Click(sender As Object, e As EventArgs) Handles btnAñadirFavorito.Click
        Dim PAux As Persona
        Dim ArtFavAux As ArtistaFav = New ArtistaFav
        Dim ArtAux As Artista
        Dim fecha As String = "27/04/2021"

        ''Creamos el usuario y artista según lo tengamos cogido en las listas
        If listaUsuarios.SelectedItem IsNot Nothing Then
            PAux = New Persona(listaUsuarios.SelectedItem.ToString)

            If listaArtistas.SelectedItem IsNot Nothing Then
                Dim artisaSeparado = Split(Me.listaArtistas.SelectedItem.ToString, "-")
                ArtAux = New Artista(artisaSeparado(0))

                ''Leemos las personas
                Try
                    PAux.LeerPersona()
                Catch ex As Exception
                    MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End Try

                ''Leemos los Artistas
                Try
                    ArtAux.LeerArtista()
                Catch ex As Exception
                    MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End Try

                Try
                    ArtFavAux.LeerTodosArtistasFav(txtRuta.Text)
                Catch ex As Exception
                    MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try

                ArtFavAux.Usuario = PAux.Email
                ArtFavAux.Artista = ArtAux.IdArtista
                ArtFavAux.Fecha = fecha


                Try
                    If ArtFavAux.InsertarArtistaFav() <> 1 Then
                        MessageBox.Show("Update Return <> 1", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    Else

                        ArtFavAux.Usuario = PAux.Email
                        ArtFavAux.Artista = ArtAux.IdArtista
                        ArtFavAux.Fecha = fecha
                        listaArtistasFav.Items.Add(ArtAux.IdArtista + "-" + ArtAux.Nombre)
                    End If
                Catch ex As Exception
                    MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End Try


            End If
        End If
    End Sub

    Private Sub btnEliminarArtistaFav_Click(sender As Object, e As EventArgs) Handles btnEliminarArtistaFav.Click
        Dim ArtFavaux As ArtistaFav
        Dim Artaux As Artista
        Dim Paux As Persona

        If listaUsuarios.SelectedItem IsNot Nothing Then
            Paux = New Persona(listaUsuarios.SelectedItem.ToString)
            If listaArtistasFav.SelectedItem IsNot Nothing Then
                ArtFavaux = New ArtistaFav(Paux.Email)
                Dim artisaSeparado = Split(Me.listaArtistasFav.SelectedItem.ToString, "-")
                Artaux = New Artista(artisaSeparado(0))

                ArtFavaux.Artista = Artaux.IdArtista
                MessageBox.Show(ArtFavaux.Artista)
                Try
                    Artaux.LeerArtista()
                Catch ex As Exception
                    MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End Try
                Try
                    Paux.LeerPersona()
                Catch ex As Exception
                    MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End Try

                '' messagebox eliminar si ok hace si no no lo hase xd
                If MessageBox.Show("¿Desea eliminar a " & Artaux.Nombre & " de la lista de artistas favoritos del usuario " & Paux.Nombre & "?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then

                    Try
                        If ArtFavaux.BorrarArtistaFav() <> 1 Then
                            MessageBox.Show("Delete Return <> 1", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        Else
                            '' Se elimina al artista de la lista 
                            listaArtistasFav.Items.Remove(Artaux.IdArtista + "-" + Artaux.Nombre)
                        End If

                    Catch ex As Exception
                        MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End Try

                End If

            End If
        End If
    End Sub

    ''Botones Album
    Private Sub btnAñadirAlbum_Click(sender As Object, e As EventArgs) Handles btnAñadirAlbum.Click
        ''Auxiliar
        Dim AlbAux As Album
        Dim ArtAux As Artista
        ''Comprobar que los campos no estan vacios
        If txtIdAlbum.Text IsNot String.Empty And txtNombreAlbum.Text IsNot String.Empty And txtFechaPubli.Text IsNot String.Empty Then

            ''Creamos el artista con el nombre modificamos su nombre por que este siempre se incializa vacio
            Dim artisaSeparado = Split(Me.listaArtistas.SelectedItem.ToString, "-")
            ArtAux = New Artista(artisaSeparado(0))

            AlbAux = New Album(txtIdAlbum.Text)
            AlbAux.Nombre = txtNombreAlbum.Text
            AlbAux.Fecha = txtFechaPubli.Text

            ''Cogemos el id del artista seleccionado anteriormente
            AlbAux.Artista = ArtAux.IdArtista

            ''Intentamos insertar la persona en la BBDD, en caso de error se muestra al usuario
            Try
                ''metemos en el if la operacion que queremos hacer para hacer la comprobacion de que ha salido bien
                If AlbAux.InsertarAlbum() <> 1 Then
                    MessageBox.Show("Insert Return <> 1", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try
            ''Se añade la persona a la listbox
            listaAlbum.Items.Add(AlbAux.IdAlbum + "-" + AlbAux.Nombre)
        End If
    End Sub
    Private Sub btnModificarAlbum_Click(sender As Object, e As EventArgs) Handles btnModificarAlbum.Click
        Dim Albaux As Album
        If txtIdAlbum.Text IsNot String.Empty And txtNombreAlbum.Text IsNot String.Empty And txtFechaPubli.Text IsNot String.Empty Then
            Albaux = New Album(txtIdAlbum.Text)
            Albaux.Nombre = txtNombreAlbum.Text
            Albaux.Fecha = txtFechaPubli.Text
            Try
                If Albaux.ActualizarAlbum() <> 1 Then
                    MessageBox.Show("Update Return <> 1", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                Else
                    Dim cadena As String = listaAlbum.SelectedItem
                    listaAlbum.Items.Remove(cadena)

                    listaAlbum.Items.Add(Albaux.IdAlbum + "-" + Albaux.Nombre)
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try
            MessageBox.Show("El Album con el nombre " & Albaux.Nombre & " se ha actualizado correctamente", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)

        End If
    End Sub
    Private Sub btnEliminarAlbum_Click(sender As Object, e As EventArgs) Handles btnEliminarAlbum.Click
        Dim Albaux As Album
        If txtIdAlbum.Text IsNot String.Empty Then
            Albaux = New Album(txtIdAlbum.Text)


            '' messagebox eliminar si ok hace si no no lo hase xd
            If MessageBox.Show("¿Desea eliminar a " & txtNombreAlbum.Text & "?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                Try
                    If Albaux.BorrarAlbum() <> 1 Then
                        MessageBox.Show("Delete Return <> 1", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    Else
                        listaAlbum.Items.Remove(Albaux.IdAlbum + "-" + txtNombreAlbum.Text)
                    End If
                Catch ex As Exception
                    MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End Try


                '' Se simula un click para limpiar los datos del usuario
                btnLimpiarAlbum.PerformClick()

            End If

        End If
    End Sub
    Private Sub btnLimpiarAlbum_Click(sender As Object, e As EventArgs) Handles btnLimpiarAlbum.Click
        txtIdAlbum.Text = String.Empty
        txtNombreAlbum.Text = String.Empty
        txtFechaPubli.Text = String.Empty
        txtDuracionAlbum.Text = String.Empty

        btnAñadirAlbum.Enabled = True
        btnEliminarAlbum.Enabled = False
        btnModificarAlbum.Enabled = False
    End Sub

    ''Botones Canción
    Private Sub btnAñadirCancion_Click(sender As Object, e As EventArgs) Handles btnAñadirCancion.Click
        ''Auxiliar
        Dim CanAux As Cancion
        Dim AlbAux As Album
        ''Comprobar que los campos no estan vacios
        If txtIdCancion.Text IsNot String.Empty And txtCancion.Text IsNot String.Empty And txtDuracionCancion.Text IsNot String.Empty Then
            ''Creamos el artista con el nombre modificamos su nombre por que este siempre se incializa vacio
            Dim AlbumSeparado = Split(Me.listaAlbum.SelectedItem.ToString, "-")
            AlbAux = New Album(AlbumSeparado(0))

            CanAux = New Cancion(txtIdCancion.Text)
            CanAux.Nombre = txtCancion.Text
            CanAux.Album = AlbAux.IdAlbum
            CanAux.Duracion = txtDuracionCancion.Text


            ''Intentamos insertar la persona en la BBDD, en caso de error se muestra al usuario
            Try
                ''metemos en el if la operacion que queremos hacer para hacer la comprobacion de que ha salido bien
                If CanAux.InsertarCancion() <> 1 Then
                    MessageBox.Show("Insert Return <> 1", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try
            ''Se añade la persona a la listbox
            listaCanciones.Items.Add(CanAux.IdCancion + "-" + CanAux.Nombre)
        End If
    End Sub
    Private Sub btnmodificarCancion_Click(sender As Object, e As EventArgs) Handles btnmodificarCancion.Click
        Dim CanAux As Cancion
        If txtIdCancion.Text IsNot String.Empty And txtCancion.Text IsNot String.Empty And txtDuracionCancion.Text IsNot String.Empty Then

            CanAux = New Cancion(txtIdCancion.Text)
            CanAux.Nombre = txtCancion.Text

            ''En el texto lo tenemos en minutos pero duración está definido como int asiq lo pasamos de nuevo a seg.
            Dim Duracion = Split(txtDuracionCancion.Text, ":")
            Dim Seg As Integer
            Seg = Duracion(0) * 60 + Duracion(1)
            CanAux.Duracion = Seg

            MessageBox.Show(CanAux.ActualizarCancion.GetType().ToString)

            Try
                If CanAux.ActualizarCancion() <> 1 Then
                    MessageBox.Show("Update Return <> 1", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                Else

                    Dim cadena As String = listaCanciones.SelectedItem
                    listaCanciones.Items.Remove(cadena)
                    listaCanciones.Items.Add(CanAux.IdCancion + "-" + CanAux.Nombre)
                End If
            Catch ex As Exception

                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try
            MessageBox.Show("La cancion con el nombre" & CanAux.Nombre & "se ha actualizado correctamente", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)

        End If
    End Sub
    Private Sub btnEliminarCancion_Click(sender As Object, e As EventArgs) Handles btnEliminarCancion.Click
        Dim CanAux As Cancion
        If txtIdCancion.Text IsNot String.Empty Then
            CanAux = New Cancion(txtIdCancion.Text)
            CanAux.Nombre = txtCancion.Text ''Probar si eso va

            '' messagebox eliminar si ok hace si no no lo hase xd
            If MessageBox.Show("¿Desea eliminar a " & CanAux.IdCancion & "?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                Try
                    If CanAux.BorrarCancion() <> 1 Then
                        MessageBox.Show("Delete Return <> 1", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    Else

                        listaCanciones.Items.Remove(CanAux.IdCancion + "-" + txtCancion.Text)
                    End If
                Catch ex As Exception
                    MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End Try
                '' Se elimina al artista de la lista 
                listaAlbum.Items.Remove(CanAux.IdCancion + "-" + CanAux.Nombre)

                '' Se simula un click para limpiar los datos del usuario
                btnLimpiarCancion.PerformClick()

            End If

        End If
    End Sub
    Private Sub btnLimpiarCancion_Click(sender As Object, e As EventArgs) Handles btnLimpiarCancion.Click
        txtIdCancion.Text = String.Empty
        txtCancion.Text = String.Empty
        txtDuracionCancion.Text = String.Empty

        btnAñadirCancion.Enabled = True
        btnEliminarCancion.Enabled = False
        btnmodificarCancion.Enabled = False
    End Sub
    Private Sub btnReproducir_click(sender As Object, e As EventArgs) Handles btnReproducir.Click
        Dim PAux As Persona
        Dim CanAux As Cancion
        Dim ReAux As ListaReproduccion
        Dim ultimarepro As String
        Dim fecha As String = "27/04/2021"


        ''Cogemos el usuario que está seleccionado para añadirlo por su email
        If listaUsuarios.SelectedItem IsNot Nothing Then
            PAux = New Persona(listaUsuarios.SelectedItem.ToString)
            ''Cogemos la canción que está seleccionada para añadirla por su id 
            If listaCanciones.SelectedItem IsNot Nothing Then
                Dim CancionSeparado = Split(Me.listaCanciones.SelectedItem.ToString, "-")
                CanAux = New Cancion(CancionSeparado(0))
                ReAux = New ListaReproduccion(ultimarepro)
                txtFechahoy.Text = fecha
                ''Leemos las personas
                Try
                    PAux.LeerPersona()
                Catch ex As Exception
                    MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End Try

                ''Leemos las canciones
                Try
                    CanAux.LeerCancion()
                Catch ex As Exception
                    MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub

                End Try

                Try
                    ReAux.LeerTodasReproducciones(txtRuta.Text)
                Catch ex As Exception
                    MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub

                End Try
                ''calcular el id de la última canción reproducida
                Dim n As Integer
                For Each Re As ListaReproduccion In ReAux.RepDao.ListaRepro

                    n += 1
                Next
                n += 1

                ultimarepro = n.ToString

                ''Buscar el nombre de la canción

                For Each Re As ListaReproduccion In ReAux.RepDao.ListaRepro
                    For Each Ca As Cancion In CanAux.CanDAO.Canciones
                        If Re.idCancion = Ca.IdCancion Then
                            CanAux.Nombre = Ca.Nombre
                        End If
                    Next
                Next

                ReAux.IdRepodruccion = ultimarepro
                ReAux.Usuario = PAux.Email
                ReAux.idCancion = CanAux.IdCancion
                ReAux.Fecha = txtFechahoy.Text
                ListaReproducciones.Items.Add(ultimarepro + "-" + CanAux.Nombre)

                Try
                    If ReAux.InsertarReproduccion() <> 1 Then
                        MessageBox.Show("Update Return <> 1", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    Else

                        ReAux.IdRepodruccion = ultimarepro.ToString
                        ReAux.Usuario = PAux.Email
                        ReAux.idCancion = CanAux.IdCancion
                        ReAux.Fecha = txtFechahoy.Text

                    End If
                Catch ex As Exception

                    MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End Try

            End If
        End If

    End Sub

    ''Lista Usuario
    Private Sub listaUsuario_SelectedIndexChanged(sender As Object, e As EventArgs) Handles listaUsuarios.Click
        Dim PAux As Persona
        Dim ReAux As ListaReproduccion = New ListaReproduccion
        Dim CaAux As Cancion = New Cancion
        Dim Art As Artista = New Artista
        Dim ArtFavAux As ArtistaFav = New ArtistaFav

        If listaUsuarios.SelectedItem IsNot Nothing Then
            PAux = New Persona(listaUsuarios.SelectedItem.ToString)
            Try
                PAux.LeerPersona()
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub

            End Try
            txtEmail.Text = PAux.Email
            txtNombreUsuario.Text = PAux.Nombre
            txtApellidosUsuario.Text = PAux.Apellido
            txtFechaUsuario.Text = PAux.FechaNacimiento

            btnAñadirUsuario.Enabled = False
            btnEliminarUsuario.Enabled = True
            btnmodificarUsuario.Enabled = True

            ''Mostrar el registro de reproducciones
            ListaReproducciones.Items.Clear()
            Try
                ReAux.LeerTodasReproducciones(listaUsuarios.SelectedItems.ToString)
                CaAux.LeerTodasCanciones(ReAux.idCancion)
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            For Each Re As ListaReproduccion In ReAux.RepDao.ListaRepro
                For Each Ca As Cancion In CaAux.CanDAO.Canciones
                    ''Si tienen el mismo id igualamos los nombres de la cancion de la clase cancion con la lista de repro
                    If Re.idCancion = Ca.IdCancion Then
                        CaAux.Nombre = Ca.Nombre
                    End If
                Next
                If PAux.Email = Re.Usuario Then
                    ListaReproducciones.Items.Add(Re.idCancion + "-" + CaAux.Nombre)
                End If
            Next

            '' Mostrar Artista favorito

            listaArtistasFav.Items.Clear()
            Try
                ArtFavAux.LeerTodosArtistasFav(listaUsuarios.SelectedItem.ToString)
                Art.LeerTodosArtistas(listaUsuarios.SelectedItem.ToString)
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            For Each Fav As ArtistaFav In ArtFavAux.ArtFavDAO.ArtistasFav
                For Each Arti As Artista In Art.ArtDAO.Artistas
                    If Fav.Usuario = PAux.Email Then
                        If Fav.Artista = Arti.IdArtista Then
                            listaArtistasFav.Items.Add(Arti.IdArtista + "-" + Arti.Nombre)
                        End If

                    End If
                Next
            Next
        End If
    End Sub
    ''Lista Artista
    Private Sub listaArtista_SelectedIndexChanged(sender As Object, e As EventArgs) Handles listaArtistas.Click
        Dim Albaux As Album = New Album
        Dim ArtAux As Artista

        If listaArtistas.SelectedItem IsNot Nothing Then
            Dim artisaSeparado = Split(Me.listaArtistas.SelectedItem.ToString, "-")
            ArtAux = New Artista(artisaSeparado(0))

            Try
                ArtAux.LeerArtista()
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try
            txtNombreArtista.Text = ArtAux.Nombre
            txtNacionalidadArtista.Text = ArtAux.Pais
            txtIdArtista.Text = ArtAux.IdArtista
            btnEliminarArtista.Enabled = True
            btnmodificarArtista.Enabled = True
            btnAñadirArtista.Enabled = False

            '' Se imprime la imagen del artista
            PictureBox1_Click(ArtAux.Imagen)

            '' Añadir los albumes según el artista seleccionado
            Try
                Albaux.LeerTodosAlbum(listaArtistas.SelectedItem)
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)

                Exit Sub
            End Try

            ''Se añade cada elemento a la listbox
            listaAlbum.Items.Clear()

            For Each Art As Album In Albaux.AlbDAO.Albumes

                If ArtAux.IdArtista = Art.Artista Then
                    listaAlbum.Items.Add(Art.IdAlbum + "-" + Art.Nombre)
                End If
            Next

        End If
    End Sub
    ''Lista Album
    Private Sub listaAlbum_SelectedIndexChanged(sender As Object, e As EventArgs) Handles listaAlbum.SelectedIndexChanged
        Dim AlbAux As Album
        Dim CanAux As Cancion = New Cancion
        Dim duracion As Integer
        If listaAlbum.SelectedItem IsNot Nothing Then
            Dim AlbumSeparado = Split(Me.listaAlbum.SelectedItem.ToString, "-")
            AlbAux = New Album(AlbumSeparado(0))
            Try
                AlbAux.LeerAlbum()
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try
            txtIdAlbum.Text = AlbAux.IdAlbum
            txtNombreAlbum.Text = AlbAux.Nombre
            txtFechaPubli.Text = AlbAux.Fecha
            btnAñadirAlbum.Enabled = False
            btnEliminarAlbum.Enabled = True
            btnModificarAlbum.Enabled = True

            '' Se imprime la Portada del Album
            PictureBox2_Click(AlbAux.Portada)

            Try
                CanAux.LeerTodasCanciones(listaArtistas.SelectedItem)
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)

                Exit Sub
            End Try

            ''Se añade cada elemento a la listbox
            listaCanciones.Items.Clear()

            For Each Ca As Cancion In CanAux.CanDAO.Canciones

                If AlbAux.IdAlbum = Ca.Album Then
                    listaCanciones.Items.Add(Ca.IdCancion + "-" + Ca.Nombre)
                    duracion = duracion + Ca.Duracion
                End If
            Next
            '' Para mostrar la duracion del album 
            Dim hor As Integer
            Dim min As Integer
            Dim seg As Integer
            hor = Math.Floor(duracion / 3600)
            min = Math.Floor((duracion - hor * 3600) / 60)
            seg = duracion - (hor * 3600 + min * 60)
            If hor = 0 Then
                txtDuracionAlbum.Text = Trim(min) + ":" + Trim(seg)
            Else
                txtDuracionAlbum.Text = Trim(hor) + ":" + Trim(min) + ":" + Trim(seg)
            End If
        End If
    End Sub
    ''Lista ListaCanciones
    Private Sub listaCanciones_SelectedIndexChanged(sender As Object, e As EventArgs) Handles listaCanciones.SelectedIndexChanged
        Dim CanAux As Cancion

        If listaCanciones.SelectedItem IsNot Nothing Then
            Dim CancionSeparado = Split(Me.listaCanciones.SelectedItem.ToString, "-")
            CanAux = New Cancion(CancionSeparado(0))
            Try
                CanAux.LeerCancion()
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub

            End Try

            Dim hor As Integer
            Dim min As Integer
            Dim seg As Integer
            hor = Math.Floor(CanAux.Duracion / 3600)
            min = Math.Floor((CanAux.Duracion - hor * 3600) / 60)
            seg = CanAux.Duracion - (hor * 3600 + min * 60)

            txtIdCancion.Text = CanAux.IdCancion
            txtCancion.Text = CanAux.Nombre
            txtDuracionCancion.Text = Trim(min) + ":" + Trim(seg)

            btnAñadirCancion.Enabled = False
            btnEliminarCancion.Enabled = True
            btnmodificarCancion.Enabled = True


        End If
    End Sub

    Private Sub PictureBox1_Click(ByVal imagen As String)
        If imagen IsNot String.Empty Then
            PictureBox1.Image = Image.FromFile(My.Application.Info.DirectoryPath & "\fotosArtistas\" & imagen)
        End If
    End Sub

    Private Sub PictureBox2_Click(ByVal portada As String)
        If portada IsNot String.Empty Then
            PictureBox2.Image = Image.FromFile(My.Application.Info.DirectoryPath & "\fotosAlbumes\" & portada)
        End If
    End Sub

    Private Sub ArtistasOrdenados_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ArtistasOrdenados.SelectedIndexChanged

    End Sub

    Private Sub BotonOrdenar_Click(sender As Object, e As EventArgs) Handles BotonOrdenar.Click
        ArtistasOrdenados.Items.Clear()
        Dim a As Artista = New Artista
        Dim ArtAux As Artista = New Artista
        Try
            a.ArtDAO.LeerPaises(txtRuta.Text)

        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End Try

        For Each shown As String In a.ArtDAO.Artistas
            Try
                If (shown = FiltroPais.Text) Then
                    Try
                        ArtAux.LeerTodosArtistas(txtRuta.Text)
                    Catch ex As Exception
                        MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End Try

                    ''Se añade cada elemento a la listbox
                    For Each Art As Artista In ArtAux.ArtDAO.Artistas
                        If (Art.Pais = FiltroPais.Text) Then
                            ArtistasOrdenados.Items.Add(Art.IdArtista + "-" + Art.Nombre)
                        End If
                    Next
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try
        Next
    End Sub

    Private Sub Empezar_Click(sender As Object, e As EventArgs) Handles Empezar.Click
        '' Rellenamos cada una de las tablas respectivamente para despues poder trabajar con ellas
        '' Creamos primero variables auxiliares
        Dim PAux As Persona = New Persona
        Dim ArtAux As Artista = New Artista
        Dim CanAux As Cancion = New Cancion
        ''ARTISTAS
        '' Se leen todos los artistas de la bbdd, en caso de que salte una excepcion mostrar mensaje de error junto a la excepcion
        Try
            ArtAux.LeerTodosArtistas(txtRuta.Text)
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End Try

        ''Se añade cada elemento a la listbox

        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT ARTISTAS.Nombre FROM ARTISTAS, ALBUMES, CANCIONES, REPRODUCCIONES
                WHERE ARTISTAS.IdArtista = ALBUMES.Artista AND ALBUMES.IdAlbum = CANCIONES.Album AND CANCIONES.IdCancion = REPRODUCCIONES.Cancion
                GROUP BY (ARTISTAS.Nombre) ORDER BY COUNT(REPRODUCCIONES.Cancion) DESC")
        For Each aux In col
            ArtistasOrdenados.Items.Add(aux(1).ToString)
        Next

        For Each Art As Artista In ArtAux.ArtDAO.Artistas
            ArtistasMasEscuchados.Items.Add(Art.IdArtista + "-" + Art.Nombre)
        Next

        '' PERSONAS
        ''Se leen todas las personas de la bbdd, en caso de que salte una excepcion mostrar mensaje de error junto a la excepcion
        Try
            PAux.LeerTodasPersonas(txtRuta.Text)
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End Try

        ''Se añade cada elemento a la listbox
        For Each Pa As Persona In PAux.PerDAO.Personas
            UsuariosMasTiempo.Items.Add(Pa.Email)
        Next

        '' CANCIONES
        ''Se leen todas las Canciones de la bbdd, en caso de que salte una excepcion mostrar mensaje de error junto a la excepcion
        Try
            CanAux.LeerTodasCanciones(listaArtistas.SelectedItem)
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)

            Exit Sub
        End Try

        ''Se añade cada elemento a la listbox
        For Each Ca As Cancion In CanAux.CanDAO.Canciones
            CancionesOrdenadas.Items.Add(Ca.IdCancion + "-" + Ca.Nombre)
        Next

        ''Se desabilita el boton Empezar puesto que no se utilizaran mas
        Empezar.Enabled = False
    End Sub

    Private Sub OrdenarCanciones_Click(sender As Object, e As EventArgs) Handles OrdenarCanciones.Click
        '' CANCIONES
        ''Se leen todas las Canciones de la bbdd, en caso de que salte una excepcion mostrar mensaje de error junto a la excepcion
        CancionesOrdenadas.Items.Clear()
        Dim CanAux As Cancion = New Cancion
        Try
            CanAux.LeerTodasCanciones(listaArtistas.SelectedItem)
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)

            Exit Sub
        End Try

        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente(txtRuta.Text).Leer("SELECT CANCIONES.IdCancion, CANCIONES.Nombre, COUNT(REPRODUCCIONES.Cancion) as Reproducciones 
                FROM CANCIONES LEFT JOIN REPRODUCCIONES ON CANCIONES.IdCancion = REPRODUCCIONES.cancion GROUP BY CANCIONES.IdCancion, CANCIONES.Nombre ORDER BY COUNT(REPRODUCCIONES.Cancion) DESC")
        For Each aux In col
            CancionesOrdenadas.Items.Add(aux(2).ToString)
        Next

    End Sub

End Class