﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Cancionfy = New System.Windows.Forms.TabControl()
        Me.Usuarios = New System.Windows.Forms.TabPage()
        Me.txtApellidosUsuario = New System.Windows.Forms.TextBox()
        Me.txtFechaUsuario = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.btnLimpiarUsuario = New System.Windows.Forms.Button()
        Me.txtNombreUsuario = New System.Windows.Forms.TextBox()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnEliminarUsuario = New System.Windows.Forms.Button()
        Me.btnmodificarUsuario = New System.Windows.Forms.Button()
        Me.btnAñadirUsuario = New System.Windows.Forms.Button()
        Me.lblResultado = New System.Windows.Forms.Label()
        Me.txtRuta = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.listaUsuarios = New System.Windows.Forms.ListBox()
        Me.btnConectar = New System.Windows.Forms.Button()
        Me.btnRuta = New System.Windows.Forms.Button()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.txtIdArtista = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.listaArtistasFav = New System.Windows.Forms.ListBox()
        Me.btnEliminarArtistaFav = New System.Windows.Forms.Button()
        Me.btnAñadirFavorito = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnLimpiarArtista = New System.Windows.Forms.Button()
        Me.btnEliminarArtista = New System.Windows.Forms.Button()
        Me.btnmodificarArtista = New System.Windows.Forms.Button()
        Me.btnAñadirArtista = New System.Windows.Forms.Button()
        Me.txtNombreArtista = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtNacionalidadArtista = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.listaArtistas = New System.Windows.Forms.ListBox()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.txtIdAlbum = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.btnLimpiarAlbum = New System.Windows.Forms.Button()
        Me.btnEliminarAlbum = New System.Windows.Forms.Button()
        Me.btnModificarAlbum = New System.Windows.Forms.Button()
        Me.btnAñadirAlbum = New System.Windows.Forms.Button()
        Me.txtNombreAlbum = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtFechaPubli = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtDuracionAlbum = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.listaAlbum = New System.Windows.Forms.ListBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.txtFechahoy = New System.Windows.Forms.TextBox()
        Me.Fecha = New System.Windows.Forms.Label()
        Me.txtIdCancion = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.ListaReproducciones = New System.Windows.Forms.ListBox()
        Me.btnReproducir = New System.Windows.Forms.Button()
        Me.btnLimpiarCancion = New System.Windows.Forms.Button()
        Me.btnEliminarCancion = New System.Windows.Forms.Button()
        Me.btnmodificarCancion = New System.Windows.Forms.Button()
        Me.btnAñadirCancion = New System.Windows.Forms.Button()
        Me.txtCancion = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtDuracionCancion = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.listaCanciones = New System.Windows.Forms.ListBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.BotonOrdenar = New System.Windows.Forms.Button()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.FiltroPais = New System.Windows.Forms.TextBox()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.ArtistasOrdenados = New System.Windows.Forms.ListBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.CancionesOrdenadas = New System.Windows.Forms.ListBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.ArtistasMasEscuchados = New System.Windows.Forms.ListBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.UsuariosMasTiempo = New System.Windows.Forms.ListBox()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.TiempoRepArtFav = New System.Windows.Forms.ListBox()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.Empezar = New System.Windows.Forms.Button()
        Me.Filtro_Usuario = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.FiltroUsuario = New System.Windows.Forms.Button()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.OrdenarCanciones = New System.Windows.Forms.Button()
        Me.Cancionfy.SuspendLayout()
        Me.Usuarios.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.SuspendLayout()
        '
        'Cancionfy
        '
        Me.Cancionfy.Controls.Add(Me.Usuarios)
        Me.Cancionfy.Controls.Add(Me.TabPage2)
        Me.Cancionfy.Controls.Add(Me.TabPage1)
        Me.Cancionfy.Controls.Add(Me.TabPage3)
        Me.Cancionfy.Controls.Add(Me.TabPage4)
        Me.Cancionfy.Location = New System.Drawing.Point(12, 12)
        Me.Cancionfy.Name = "Cancionfy"
        Me.Cancionfy.SelectedIndex = 0
        Me.Cancionfy.Size = New System.Drawing.Size(1064, 604)
        Me.Cancionfy.TabIndex = 40
        '
        'Usuarios
        '
        Me.Usuarios.Controls.Add(Me.txtApellidosUsuario)
        Me.Usuarios.Controls.Add(Me.txtFechaUsuario)
        Me.Usuarios.Controls.Add(Me.Label15)
        Me.Usuarios.Controls.Add(Me.Label14)
        Me.Usuarios.Controls.Add(Me.btnLimpiarUsuario)
        Me.Usuarios.Controls.Add(Me.txtNombreUsuario)
        Me.Usuarios.Controls.Add(Me.txtEmail)
        Me.Usuarios.Controls.Add(Me.Label3)
        Me.Usuarios.Controls.Add(Me.Label2)
        Me.Usuarios.Controls.Add(Me.btnEliminarUsuario)
        Me.Usuarios.Controls.Add(Me.btnmodificarUsuario)
        Me.Usuarios.Controls.Add(Me.btnAñadirUsuario)
        Me.Usuarios.Controls.Add(Me.lblResultado)
        Me.Usuarios.Controls.Add(Me.txtRuta)
        Me.Usuarios.Controls.Add(Me.GroupBox1)
        Me.Usuarios.Controls.Add(Me.btnConectar)
        Me.Usuarios.Controls.Add(Me.btnRuta)
        Me.Usuarios.Location = New System.Drawing.Point(4, 25)
        Me.Usuarios.Name = "Usuarios"
        Me.Usuarios.Padding = New System.Windows.Forms.Padding(3)
        Me.Usuarios.Size = New System.Drawing.Size(1056, 575)
        Me.Usuarios.TabIndex = 0
        Me.Usuarios.Text = "Usuarios"
        Me.Usuarios.UseVisualStyleBackColor = True
        '
        'txtApellidosUsuario
        '
        Me.txtApellidosUsuario.Location = New System.Drawing.Point(811, 64)
        Me.txtApellidosUsuario.Name = "txtApellidosUsuario"
        Me.txtApellidosUsuario.Size = New System.Drawing.Size(202, 22)
        Me.txtApellidosUsuario.TabIndex = 41
        '
        'txtFechaUsuario
        '
        Me.txtFechaUsuario.Location = New System.Drawing.Point(811, 135)
        Me.txtFechaUsuario.Name = "txtFechaUsuario"
        Me.txtFechaUsuario.Size = New System.Drawing.Size(202, 22)
        Me.txtFechaUsuario.TabIndex = 40
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(660, 138)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(141, 17)
        Me.Label15.TabIndex = 39
        Me.Label15.Text = "Fecha de Nacimiento"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(660, 67)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(65, 17)
        Me.Label14.TabIndex = 38
        Me.Label14.Text = "Apellidos"
        '
        'btnLimpiarUsuario
        '
        Me.btnLimpiarUsuario.Location = New System.Drawing.Point(353, 299)
        Me.btnLimpiarUsuario.Name = "btnLimpiarUsuario"
        Me.btnLimpiarUsuario.Size = New System.Drawing.Size(473, 75)
        Me.btnLimpiarUsuario.TabIndex = 37
        Me.btnLimpiarUsuario.Text = "LIMPIAR"
        Me.btnLimpiarUsuario.UseVisualStyleBackColor = True
        '
        'txtNombreUsuario
        '
        Me.txtNombreUsuario.Location = New System.Drawing.Point(423, 135)
        Me.txtNombreUsuario.Name = "txtNombreUsuario"
        Me.txtNombreUsuario.Size = New System.Drawing.Size(208, 22)
        Me.txtNombreUsuario.TabIndex = 36
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(423, 64)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(208, 22)
        Me.txtEmail.TabIndex = 35
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(331, 138)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(58, 17)
        Me.Label3.TabIndex = 34
        Me.Label3.Text = "Nombre"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(331, 67)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(42, 17)
        Me.Label2.TabIndex = 33
        Me.Label2.Text = "Email"
        '
        'btnEliminarUsuario
        '
        Me.btnEliminarUsuario.Location = New System.Drawing.Point(686, 204)
        Me.btnEliminarUsuario.Name = "btnEliminarUsuario"
        Me.btnEliminarUsuario.Size = New System.Drawing.Size(140, 75)
        Me.btnEliminarUsuario.TabIndex = 31
        Me.btnEliminarUsuario.Text = "ELIMINAR"
        Me.btnEliminarUsuario.UseVisualStyleBackColor = True
        '
        'btnmodificarUsuario
        '
        Me.btnmodificarUsuario.Location = New System.Drawing.Point(520, 204)
        Me.btnmodificarUsuario.Name = "btnmodificarUsuario"
        Me.btnmodificarUsuario.Size = New System.Drawing.Size(140, 75)
        Me.btnmodificarUsuario.TabIndex = 30
        Me.btnmodificarUsuario.Text = "MODIFICAR"
        Me.btnmodificarUsuario.UseVisualStyleBackColor = True
        '
        'btnAñadirUsuario
        '
        Me.btnAñadirUsuario.Location = New System.Drawing.Point(353, 204)
        Me.btnAñadirUsuario.Name = "btnAñadirUsuario"
        Me.btnAñadirUsuario.Size = New System.Drawing.Size(140, 75)
        Me.btnAñadirUsuario.TabIndex = 29
        Me.btnAñadirUsuario.Text = "AÑADIR"
        Me.btnAñadirUsuario.UseVisualStyleBackColor = True
        '
        'lblResultado
        '
        Me.lblResultado.AutoSize = True
        Me.lblResultado.Location = New System.Drawing.Point(173, 505)
        Me.lblResultado.Name = "lblResultado"
        Me.lblResultado.Size = New System.Drawing.Size(0, 17)
        Me.lblResultado.TabIndex = 28
        '
        'txtRuta
        '
        Me.txtRuta.Location = New System.Drawing.Point(176, 410)
        Me.txtRuta.Multiline = True
        Me.txtRuta.Name = "txtRuta"
        Me.txtRuta.ReadOnly = True
        Me.txtRuta.Size = New System.Drawing.Size(430, 45)
        Me.txtRuta.TabIndex = 27
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.listaUsuarios)
        Me.GroupBox1.Location = New System.Drawing.Point(28, 29)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(260, 345)
        Me.GroupBox1.TabIndex = 26
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Usuarios"
        '
        'listaUsuarios
        '
        Me.listaUsuarios.FormattingEnabled = True
        Me.listaUsuarios.ItemHeight = 16
        Me.listaUsuarios.Location = New System.Drawing.Point(20, 33)
        Me.listaUsuarios.Name = "listaUsuarios"
        Me.listaUsuarios.Size = New System.Drawing.Size(221, 292)
        Me.listaUsuarios.TabIndex = 0
        '
        'btnConectar
        '
        Me.btnConectar.Location = New System.Drawing.Point(28, 484)
        Me.btnConectar.Name = "btnConectar"
        Me.btnConectar.Size = New System.Drawing.Size(132, 38)
        Me.btnConectar.TabIndex = 25
        Me.btnConectar.Text = "Conectar"
        Me.btnConectar.UseVisualStyleBackColor = True
        '
        'btnRuta
        '
        Me.btnRuta.Location = New System.Drawing.Point(28, 410)
        Me.btnRuta.Name = "btnRuta"
        Me.btnRuta.Size = New System.Drawing.Size(132, 45)
        Me.btnRuta.TabIndex = 24
        Me.btnRuta.Text = "Seleccionar fichero"
        Me.btnRuta.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.txtIdArtista)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Controls.Add(Me.GroupBox6)
        Me.TabPage2.Controls.Add(Me.btnEliminarArtistaFav)
        Me.TabPage2.Controls.Add(Me.btnAñadirFavorito)
        Me.TabPage2.Controls.Add(Me.Label6)
        Me.TabPage2.Controls.Add(Me.PictureBox1)
        Me.TabPage2.Controls.Add(Me.btnLimpiarArtista)
        Me.TabPage2.Controls.Add(Me.btnEliminarArtista)
        Me.TabPage2.Controls.Add(Me.btnmodificarArtista)
        Me.TabPage2.Controls.Add(Me.btnAñadirArtista)
        Me.TabPage2.Controls.Add(Me.txtNombreArtista)
        Me.TabPage2.Controls.Add(Me.Label5)
        Me.TabPage2.Controls.Add(Me.txtNacionalidadArtista)
        Me.TabPage2.Controls.Add(Me.Label4)
        Me.TabPage2.Controls.Add(Me.GroupBox2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1056, 575)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Artistas"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'txtIdArtista
        '
        Me.txtIdArtista.Location = New System.Drawing.Point(322, 45)
        Me.txtIdArtista.Name = "txtIdArtista"
        Me.txtIdArtista.Size = New System.Drawing.Size(208, 22)
        Me.txtIdArtista.TabIndex = 50
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(365, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(19, 17)
        Me.Label1.TabIndex = 49
        Me.Label1.Text = "Id"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.listaArtistasFav)
        Me.GroupBox6.Location = New System.Drawing.Point(311, 331)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(219, 232)
        Me.GroupBox6.TabIndex = 48
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Artistas Favoritos del Usuario"
        '
        'listaArtistasFav
        '
        Me.listaArtistasFav.FormattingEnabled = True
        Me.listaArtistasFav.ItemHeight = 16
        Me.listaArtistasFav.Location = New System.Drawing.Point(11, 28)
        Me.listaArtistasFav.Name = "listaArtistasFav"
        Me.listaArtistasFav.Size = New System.Drawing.Size(188, 180)
        Me.listaArtistasFav.TabIndex = 47
        '
        'btnEliminarArtistaFav
        '
        Me.btnEliminarArtistaFav.Location = New System.Drawing.Point(323, 284)
        Me.btnEliminarArtistaFav.Name = "btnEliminarArtistaFav"
        Me.btnEliminarArtistaFav.Size = New System.Drawing.Size(168, 41)
        Me.btnEliminarArtistaFav.TabIndex = 46
        Me.btnEliminarArtistaFav.Text = "Eliminar Artista Favorito"
        Me.btnEliminarArtistaFav.UseVisualStyleBackColor = True
        '
        'btnAñadirFavorito
        '
        Me.btnAñadirFavorito.Location = New System.Drawing.Point(323, 222)
        Me.btnAñadirFavorito.Name = "btnAñadirFavorito"
        Me.btnAñadirFavorito.Size = New System.Drawing.Size(168, 41)
        Me.btnAñadirFavorito.TabIndex = 45
        Me.btnAñadirFavorito.Text = "Añadir Artista Favorito"
        Me.btnAñadirFavorito.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(774, 284)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(54, 17)
        Me.Label6.TabIndex = 44
        Me.Label6.Text = "Imagen"
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(563, 304)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(473, 235)
        Me.PictureBox1.TabIndex = 43
        Me.PictureBox1.TabStop = False
        '
        'btnLimpiarArtista
        '
        Me.btnLimpiarArtista.Location = New System.Drawing.Point(563, 188)
        Me.btnLimpiarArtista.Name = "btnLimpiarArtista"
        Me.btnLimpiarArtista.Size = New System.Drawing.Size(473, 75)
        Me.btnLimpiarArtista.TabIndex = 42
        Me.btnLimpiarArtista.Text = "LIMPIAR"
        Me.btnLimpiarArtista.UseVisualStyleBackColor = True
        '
        'btnEliminarArtista
        '
        Me.btnEliminarArtista.Location = New System.Drawing.Point(896, 89)
        Me.btnEliminarArtista.Name = "btnEliminarArtista"
        Me.btnEliminarArtista.Size = New System.Drawing.Size(140, 75)
        Me.btnEliminarArtista.TabIndex = 41
        Me.btnEliminarArtista.Text = "ELIMINAR"
        Me.btnEliminarArtista.UseVisualStyleBackColor = True
        '
        'btnmodificarArtista
        '
        Me.btnmodificarArtista.Location = New System.Drawing.Point(730, 89)
        Me.btnmodificarArtista.Name = "btnmodificarArtista"
        Me.btnmodificarArtista.Size = New System.Drawing.Size(140, 75)
        Me.btnmodificarArtista.TabIndex = 40
        Me.btnmodificarArtista.Text = "MODIFICAR"
        Me.btnmodificarArtista.UseVisualStyleBackColor = True
        '
        'btnAñadirArtista
        '
        Me.btnAñadirArtista.Location = New System.Drawing.Point(563, 89)
        Me.btnAñadirArtista.Name = "btnAñadirArtista"
        Me.btnAñadirArtista.Size = New System.Drawing.Size(140, 75)
        Me.btnAñadirArtista.TabIndex = 39
        Me.btnAñadirArtista.Text = "AÑADIR"
        Me.btnAñadirArtista.UseVisualStyleBackColor = True
        '
        'txtNombreArtista
        '
        Me.txtNombreArtista.Location = New System.Drawing.Point(323, 115)
        Me.txtNombreArtista.Name = "txtNombreArtista"
        Me.txtNombreArtista.Size = New System.Drawing.Size(208, 22)
        Me.txtNombreArtista.TabIndex = 38
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(365, 89)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(58, 17)
        Me.Label5.TabIndex = 37
        Me.Label5.Text = "Nombre"
        '
        'txtNacionalidadArtista
        '
        Me.txtNacionalidadArtista.Location = New System.Drawing.Point(323, 188)
        Me.txtNacionalidadArtista.Name = "txtNacionalidadArtista"
        Me.txtNacionalidadArtista.Size = New System.Drawing.Size(208, 22)
        Me.txtNacionalidadArtista.TabIndex = 36
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(365, 157)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(90, 17)
        Me.Label4.TabIndex = 35
        Me.Label4.Text = "Nacionalidad"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.listaArtistas)
        Me.GroupBox2.Location = New System.Drawing.Point(16, 20)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(260, 543)
        Me.GroupBox2.TabIndex = 32
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Artistas"
        '
        'listaArtistas
        '
        Me.listaArtistas.FormattingEnabled = True
        Me.listaArtistas.ItemHeight = 16
        Me.listaArtistas.Location = New System.Drawing.Point(20, 25)
        Me.listaArtistas.Name = "listaArtistas"
        Me.listaArtistas.Size = New System.Drawing.Size(221, 484)
        Me.listaArtistas.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.txtIdAlbum)
        Me.TabPage1.Controls.Add(Me.Label13)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Controls.Add(Me.PictureBox2)
        Me.TabPage1.Controls.Add(Me.btnLimpiarAlbum)
        Me.TabPage1.Controls.Add(Me.btnEliminarAlbum)
        Me.TabPage1.Controls.Add(Me.btnModificarAlbum)
        Me.TabPage1.Controls.Add(Me.btnAñadirAlbum)
        Me.TabPage1.Controls.Add(Me.txtNombreAlbum)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.txtFechaPubli)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.txtDuracionAlbum)
        Me.TabPage1.Controls.Add(Me.Label9)
        Me.TabPage1.Controls.Add(Me.GroupBox3)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1056, 575)
        Me.TabPage1.TabIndex = 2
        Me.TabPage1.Text = "Albúm"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'txtIdAlbum
        '
        Me.txtIdAlbum.Location = New System.Drawing.Point(336, 54)
        Me.txtIdAlbum.Name = "txtIdAlbum"
        Me.txtIdAlbum.Size = New System.Drawing.Size(208, 22)
        Me.txtIdAlbum.TabIndex = 52
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(378, 19)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(19, 17)
        Me.Label13.TabIndex = 51
        Me.Label13.Text = "Id"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(776, 265)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(54, 17)
        Me.Label10.TabIndex = 50
        Me.Label10.Text = "Imagen"
        '
        'PictureBox2
        '
        Me.PictureBox2.Location = New System.Drawing.Point(669, 296)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(277, 244)
        Me.PictureBox2.TabIndex = 49
        Me.PictureBox2.TabStop = False
        '
        'btnLimpiarAlbum
        '
        Me.btnLimpiarAlbum.Location = New System.Drawing.Point(567, 173)
        Me.btnLimpiarAlbum.Name = "btnLimpiarAlbum"
        Me.btnLimpiarAlbum.Size = New System.Drawing.Size(473, 75)
        Me.btnLimpiarAlbum.TabIndex = 48
        Me.btnLimpiarAlbum.Text = "LIMPIAR"
        Me.btnLimpiarAlbum.UseVisualStyleBackColor = True
        '
        'btnEliminarAlbum
        '
        Me.btnEliminarAlbum.Location = New System.Drawing.Point(900, 74)
        Me.btnEliminarAlbum.Name = "btnEliminarAlbum"
        Me.btnEliminarAlbum.Size = New System.Drawing.Size(140, 75)
        Me.btnEliminarAlbum.TabIndex = 47
        Me.btnEliminarAlbum.Text = "ELIMINAR"
        Me.btnEliminarAlbum.UseVisualStyleBackColor = True
        '
        'btnModificarAlbum
        '
        Me.btnModificarAlbum.Location = New System.Drawing.Point(734, 74)
        Me.btnModificarAlbum.Name = "btnModificarAlbum"
        Me.btnModificarAlbum.Size = New System.Drawing.Size(140, 75)
        Me.btnModificarAlbum.TabIndex = 46
        Me.btnModificarAlbum.Text = "MODIFICAR"
        Me.btnModificarAlbum.UseVisualStyleBackColor = True
        '
        'btnAñadirAlbum
        '
        Me.btnAñadirAlbum.Location = New System.Drawing.Point(567, 74)
        Me.btnAñadirAlbum.Name = "btnAñadirAlbum"
        Me.btnAñadirAlbum.Size = New System.Drawing.Size(140, 75)
        Me.btnAñadirAlbum.TabIndex = 45
        Me.btnAñadirAlbum.Text = "AÑADIR"
        Me.btnAñadirAlbum.UseVisualStyleBackColor = True
        '
        'txtNombreAlbum
        '
        Me.txtNombreAlbum.Location = New System.Drawing.Point(336, 127)
        Me.txtNombreAlbum.Name = "txtNombreAlbum"
        Me.txtNombreAlbum.Size = New System.Drawing.Size(208, 22)
        Me.txtNombreAlbum.TabIndex = 42
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(378, 91)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(58, 17)
        Me.Label7.TabIndex = 41
        Me.Label7.Text = "Nombre"
        '
        'txtFechaPubli
        '
        Me.txtFechaPubli.Location = New System.Drawing.Point(336, 199)
        Me.txtFechaPubli.Name = "txtFechaPubli"
        Me.txtFechaPubli.Size = New System.Drawing.Size(208, 22)
        Me.txtFechaPubli.TabIndex = 40
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(378, 173)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(142, 17)
        Me.Label8.TabIndex = 39
        Me.Label8.Text = "Fecha de publicación"
        '
        'txtDuracionAlbum
        '
        Me.txtDuracionAlbum.Location = New System.Drawing.Point(336, 262)
        Me.txtDuracionAlbum.Name = "txtDuracionAlbum"
        Me.txtDuracionAlbum.Size = New System.Drawing.Size(208, 22)
        Me.txtDuracionAlbum.TabIndex = 38
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(378, 231)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(108, 17)
        Me.Label9.TabIndex = 37
        Me.Label9.Text = "Duración Album"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.listaAlbum)
        Me.GroupBox3.Location = New System.Drawing.Point(16, 19)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(260, 539)
        Me.GroupBox3.TabIndex = 36
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Album"
        '
        'listaAlbum
        '
        Me.listaAlbum.FormattingEnabled = True
        Me.listaAlbum.ItemHeight = 16
        Me.listaAlbum.Location = New System.Drawing.Point(17, 21)
        Me.listaAlbum.Name = "listaAlbum"
        Me.listaAlbum.Size = New System.Drawing.Size(221, 500)
        Me.listaAlbum.TabIndex = 0
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.txtFechahoy)
        Me.TabPage3.Controls.Add(Me.Fecha)
        Me.TabPage3.Controls.Add(Me.txtIdCancion)
        Me.TabPage3.Controls.Add(Me.Label16)
        Me.TabPage3.Controls.Add(Me.GroupBox5)
        Me.TabPage3.Controls.Add(Me.btnReproducir)
        Me.TabPage3.Controls.Add(Me.btnLimpiarCancion)
        Me.TabPage3.Controls.Add(Me.btnEliminarCancion)
        Me.TabPage3.Controls.Add(Me.btnmodificarCancion)
        Me.TabPage3.Controls.Add(Me.btnAñadirCancion)
        Me.TabPage3.Controls.Add(Me.txtCancion)
        Me.TabPage3.Controls.Add(Me.Label11)
        Me.TabPage3.Controls.Add(Me.txtDuracionCancion)
        Me.TabPage3.Controls.Add(Me.Label12)
        Me.TabPage3.Controls.Add(Me.GroupBox4)
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1056, 575)
        Me.TabPage3.TabIndex = 3
        Me.TabPage3.Text = "Canción"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'txtFechahoy
        '
        Me.txtFechahoy.Location = New System.Drawing.Point(553, 360)
        Me.txtFechahoy.Name = "txtFechahoy"
        Me.txtFechahoy.Size = New System.Drawing.Size(208, 22)
        Me.txtFechahoy.TabIndex = 61
        '
        'Fecha
        '
        Me.Fecha.AutoSize = True
        Me.Fecha.Location = New System.Drawing.Point(550, 340)
        Me.Fecha.Name = "Fecha"
        Me.Fecha.Size = New System.Drawing.Size(47, 17)
        Me.Fecha.TabIndex = 60
        Me.Fecha.Text = "Fecha"
        '
        'txtIdCancion
        '
        Me.txtIdCancion.Location = New System.Drawing.Point(299, 60)
        Me.txtIdCancion.Name = "txtIdCancion"
        Me.txtIdCancion.Size = New System.Drawing.Size(208, 22)
        Me.txtIdCancion.TabIndex = 59
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(341, 40)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(19, 17)
        Me.Label16.TabIndex = 58
        Me.Label16.Text = "Id"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.ListaReproducciones)
        Me.GroupBox5.Location = New System.Drawing.Point(281, 215)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(260, 325)
        Me.GroupBox5.TabIndex = 40
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Registro de Reproducciones"
        '
        'ListaReproducciones
        '
        Me.ListaReproducciones.FormattingEnabled = True
        Me.ListaReproducciones.ItemHeight = 16
        Me.ListaReproducciones.Location = New System.Drawing.Point(5, 30)
        Me.ListaReproducciones.Name = "ListaReproducciones"
        Me.ListaReproducciones.Size = New System.Drawing.Size(221, 276)
        Me.ListaReproducciones.TabIndex = 0
        '
        'btnReproducir
        '
        Me.btnReproducir.Location = New System.Drawing.Point(553, 260)
        Me.btnReproducir.Name = "btnReproducir"
        Me.btnReproducir.Size = New System.Drawing.Size(473, 59)
        Me.btnReproducir.TabIndex = 57
        Me.btnReproducir.Text = "Reproducir"
        Me.btnReproducir.UseVisualStyleBackColor = True
        '
        'btnLimpiarCancion
        '
        Me.btnLimpiarCancion.Location = New System.Drawing.Point(553, 159)
        Me.btnLimpiarCancion.Name = "btnLimpiarCancion"
        Me.btnLimpiarCancion.Size = New System.Drawing.Size(473, 75)
        Me.btnLimpiarCancion.TabIndex = 54
        Me.btnLimpiarCancion.Text = "LIMPIAR"
        Me.btnLimpiarCancion.UseVisualStyleBackColor = True
        '
        'btnEliminarCancion
        '
        Me.btnEliminarCancion.Location = New System.Drawing.Point(886, 60)
        Me.btnEliminarCancion.Name = "btnEliminarCancion"
        Me.btnEliminarCancion.Size = New System.Drawing.Size(140, 75)
        Me.btnEliminarCancion.TabIndex = 53
        Me.btnEliminarCancion.Text = "ELIMINAR"
        Me.btnEliminarCancion.UseVisualStyleBackColor = True
        '
        'btnmodificarCancion
        '
        Me.btnmodificarCancion.Location = New System.Drawing.Point(720, 60)
        Me.btnmodificarCancion.Name = "btnmodificarCancion"
        Me.btnmodificarCancion.Size = New System.Drawing.Size(140, 75)
        Me.btnmodificarCancion.TabIndex = 52
        Me.btnmodificarCancion.Text = "MODIFICAR"
        Me.btnmodificarCancion.UseVisualStyleBackColor = True
        '
        'btnAñadirCancion
        '
        Me.btnAñadirCancion.Location = New System.Drawing.Point(553, 60)
        Me.btnAñadirCancion.Name = "btnAñadirCancion"
        Me.btnAñadirCancion.Size = New System.Drawing.Size(140, 75)
        Me.btnAñadirCancion.TabIndex = 51
        Me.btnAñadirCancion.Text = "AÑADIR"
        Me.btnAñadirCancion.UseVisualStyleBackColor = True
        '
        'txtCancion
        '
        Me.txtCancion.Location = New System.Drawing.Point(299, 113)
        Me.txtCancion.Name = "txtCancion"
        Me.txtCancion.Size = New System.Drawing.Size(208, 22)
        Me.txtCancion.TabIndex = 46
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(341, 93)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(58, 17)
        Me.Label11.TabIndex = 45
        Me.Label11.Text = "Nombre"
        '
        'txtDuracionCancion
        '
        Me.txtDuracionCancion.Location = New System.Drawing.Point(299, 166)
        Me.txtDuracionCancion.Name = "txtDuracionCancion"
        Me.txtDuracionCancion.Size = New System.Drawing.Size(208, 22)
        Me.txtDuracionCancion.TabIndex = 44
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(341, 146)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(120, 17)
        Me.Label12.TabIndex = 43
        Me.Label12.Text = "Duración Canción"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.listaCanciones)
        Me.GroupBox4.Location = New System.Drawing.Point(15, 17)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(260, 540)
        Me.GroupBox4.TabIndex = 39
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Canciones"
        '
        'listaCanciones
        '
        Me.listaCanciones.FormattingEnabled = True
        Me.listaCanciones.ItemHeight = 16
        Me.listaCanciones.Location = New System.Drawing.Point(12, 25)
        Me.listaCanciones.Name = "listaCanciones"
        Me.listaCanciones.Size = New System.Drawing.Size(221, 500)
        Me.listaCanciones.TabIndex = 0
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.OrdenarCanciones)
        Me.TabPage4.Controls.Add(Me.Label30)
        Me.TabPage4.Controls.Add(Me.Button1)
        Me.TabPage4.Controls.Add(Me.Label29)
        Me.TabPage4.Controls.Add(Me.FiltroUsuario)
        Me.TabPage4.Controls.Add(Me.Label28)
        Me.TabPage4.Controls.Add(Me.Filtro_Usuario)
        Me.TabPage4.Controls.Add(Me.Empezar)
        Me.TabPage4.Controls.Add(Me.BotonOrdenar)
        Me.TabPage4.Controls.Add(Me.Label27)
        Me.TabPage4.Controls.Add(Me.FiltroPais)
        Me.TabPage4.Controls.Add(Me.GroupBox10)
        Me.TabPage4.Controls.Add(Me.GroupBox9)
        Me.TabPage4.Controls.Add(Me.GroupBox8)
        Me.TabPage4.Controls.Add(Me.GroupBox7)
        Me.TabPage4.Controls.Add(Me.GroupBox11)
        Me.TabPage4.Controls.Add(Me.Label26)
        Me.TabPage4.Controls.Add(Me.Label25)
        Me.TabPage4.Controls.Add(Me.Label24)
        Me.TabPage4.Controls.Add(Me.Label23)
        Me.TabPage4.Controls.Add(Me.Label22)
        Me.TabPage4.Controls.Add(Me.Label21)
        Me.TabPage4.Controls.Add(Me.Label20)
        Me.TabPage4.Controls.Add(Me.Label19)
        Me.TabPage4.Controls.Add(Me.Label18)
        Me.TabPage4.Controls.Add(Me.Label17)
        Me.TabPage4.Location = New System.Drawing.Point(4, 25)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(1056, 575)
        Me.TabPage4.TabIndex = 4
        Me.TabPage4.Text = "+ Información"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'BotonOrdenar
        '
        Me.BotonOrdenar.Location = New System.Drawing.Point(15, 400)
        Me.BotonOrdenar.Name = "BotonOrdenar"
        Me.BotonOrdenar.Size = New System.Drawing.Size(184, 49)
        Me.BotonOrdenar.TabIndex = 55
        Me.BotonOrdenar.Text = "ORDENAR"
        Me.BotonOrdenar.UseVisualStyleBackColor = True
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(18, 352)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(70, 17)
        Me.Label27.TabIndex = 48
        Me.Label27.Text = "Filtro País"
        '
        'FiltroPais
        '
        Me.FiltroPais.Location = New System.Drawing.Point(15, 372)
        Me.FiltroPais.Name = "FiltroPais"
        Me.FiltroPais.Size = New System.Drawing.Size(178, 22)
        Me.FiltroPais.TabIndex = 47
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.ArtistasOrdenados)
        Me.GroupBox11.Location = New System.Drawing.Point(21, 54)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(178, 295)
        Me.GroupBox11.TabIndex = 45
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "PorPaises"
        '
        'ArtistasOrdenados
        '
        Me.ArtistasOrdenados.FormattingEnabled = True
        Me.ArtistasOrdenados.ItemHeight = 16
        Me.ArtistasOrdenados.Location = New System.Drawing.Point(9, 26)
        Me.ArtistasOrdenados.Name = "ArtistasOrdenados"
        Me.ArtistasOrdenados.Size = New System.Drawing.Size(163, 260)
        Me.ArtistasOrdenados.TabIndex = 0
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(103, 17)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(20, 17)
        Me.Label19.TabIndex = 36
        Me.Label19.Text = "1."
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(27, 34)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(172, 17)
        Me.Label17.TabIndex = 34
        Me.Label17.Text = "ListadoArtistasOrdenados"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(217, 34)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(191, 17)
        Me.Label18.TabIndex = 35
        Me.Label18.Text = "ListadoCancionesOrdenadas"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(306, 17)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(20, 17)
        Me.Label20.TabIndex = 37
        Me.Label20.Text = "2."
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(508, 17)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(20, 17)
        Me.Label21.TabIndex = 38
        Me.Label21.Text = "3."
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(689, 17)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(20, 17)
        Me.Label22.TabIndex = 39
        Me.Label22.Text = "4."
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(871, 17)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(20, 17)
        Me.Label23.TabIndex = 40
        Me.Label23.Text = "5."
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(423, 34)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(172, 17)
        Me.Label24.TabIndex = 41
        Me.Label24.Text = "ListadoArtistasOrdenados"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(612, 34)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(181, 17)
        Me.Label25.TabIndex = 42
        Me.Label25.Text = "ListadoUsuariosOrdenados"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(799, 34)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(161, 17)
        Me.Label26.TabIndex = 43
        Me.Label26.Text = "TiempoDeReproducción"
        '
        'CancionesOrdenadas
        '
        Me.CancionesOrdenadas.FormattingEnabled = True
        Me.CancionesOrdenadas.ItemHeight = 16
        Me.CancionesOrdenadas.Location = New System.Drawing.Point(9, 26)
        Me.CancionesOrdenadas.Name = "CancionesOrdenadas"
        Me.CancionesOrdenadas.Size = New System.Drawing.Size(163, 260)
        Me.CancionesOrdenadas.TabIndex = 0
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.CancionesOrdenadas)
        Me.GroupBox7.Location = New System.Drawing.Point(220, 54)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(178, 295)
        Me.GroupBox7.TabIndex = 46
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Num_Reproducciones"
        '
        'ArtistasMasEscuchados
        '
        Me.ArtistasMasEscuchados.FormattingEnabled = True
        Me.ArtistasMasEscuchados.ItemHeight = 16
        Me.ArtistasMasEscuchados.Location = New System.Drawing.Point(9, 26)
        Me.ArtistasMasEscuchados.Name = "ArtistasMasEscuchados"
        Me.ArtistasMasEscuchados.Size = New System.Drawing.Size(160, 260)
        Me.ArtistasMasEscuchados.TabIndex = 0
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.ArtistasMasEscuchados)
        Me.GroupBox8.Location = New System.Drawing.Point(426, 54)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(183, 295)
        Me.GroupBox8.TabIndex = 46
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Escuchas1Usuario"
        '
        'UsuariosMasTiempo
        '
        Me.UsuariosMasTiempo.FormattingEnabled = True
        Me.UsuariosMasTiempo.ItemHeight = 16
        Me.UsuariosMasTiempo.Location = New System.Drawing.Point(9, 26)
        Me.UsuariosMasTiempo.Name = "UsuariosMasTiempo"
        Me.UsuariosMasTiempo.Size = New System.Drawing.Size(163, 260)
        Me.UsuariosMasTiempo.TabIndex = 0
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.UsuariosMasTiempo)
        Me.GroupBox9.Location = New System.Drawing.Point(615, 54)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(178, 295)
        Me.GroupBox9.TabIndex = 46
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "TiempoAplicacion"
        '
        'TiempoRepArtFav
        '
        Me.TiempoRepArtFav.FormattingEnabled = True
        Me.TiempoRepArtFav.ItemHeight = 16
        Me.TiempoRepArtFav.Location = New System.Drawing.Point(6, 26)
        Me.TiempoRepArtFav.Name = "TiempoRepArtFav"
        Me.TiempoRepArtFav.Size = New System.Drawing.Size(203, 404)
        Me.TiempoRepArtFav.TabIndex = 0
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.TiempoRepArtFav)
        Me.GroupBox10.Location = New System.Drawing.Point(802, 54)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(215, 447)
        Me.GroupBox10.TabIndex = 46
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Artistas Favoritos 1 Usuario"
        '
        'Empezar
        '
        Me.Empezar.Location = New System.Drawing.Point(420, 486)
        Me.Empezar.Name = "Empezar"
        Me.Empezar.Size = New System.Drawing.Size(184, 49)
        Me.Empezar.TabIndex = 56
        Me.Empezar.Text = "Empezar"
        Me.Empezar.UseVisualStyleBackColor = True
        '
        'Filtro_Usuario
        '
        Me.Filtro_Usuario.Location = New System.Drawing.Point(420, 372)
        Me.Filtro_Usuario.Name = "Filtro_Usuario"
        Me.Filtro_Usuario.Size = New System.Drawing.Size(178, 22)
        Me.Filtro_Usuario.TabIndex = 57
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(423, 352)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(92, 17)
        Me.Label28.TabIndex = 58
        Me.Label28.Text = "Filtro Usuario"
        '
        'FiltroUsuario
        '
        Me.FiltroUsuario.Location = New System.Drawing.Point(420, 400)
        Me.FiltroUsuario.Name = "FiltroUsuario"
        Me.FiltroUsuario.Size = New System.Drawing.Size(184, 49)
        Me.FiltroUsuario.TabIndex = 59
        Me.FiltroUsuario.Text = "FiltrarPorUsuario"
        Me.FiltroUsuario.UseVisualStyleBackColor = True
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(650, 372)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(99, 17)
        Me.Label29.TabIndex = 61
        Me.Label29.Text = "Filtro Usuarios"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(615, 400)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(184, 49)
        Me.Button1.TabIndex = 62
        Me.Button1.Text = "FiltrarUsuarioT"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(255, 372)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(109, 17)
        Me.Label30.TabIndex = 63
        Me.Label30.Text = "Filtro Canciones"
        '
        'OrdenarCanciones
        '
        Me.OrdenarCanciones.Location = New System.Drawing.Point(220, 400)
        Me.OrdenarCanciones.Name = "OrdenarCanciones"
        Me.OrdenarCanciones.Size = New System.Drawing.Size(184, 49)
        Me.OrdenarCanciones.TabIndex = 64
        Me.OrdenarCanciones.Text = "ORDENAR"
        Me.OrdenarCanciones.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1095, 628)
        Me.Controls.Add(Me.Cancionfy)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Cancionfy"
        Me.Cancionfy.ResumeLayout(False)
        Me.Usuarios.ResumeLayout(False)
        Me.Usuarios.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox10.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Cancionfy As TabControl
    Friend WithEvents Usuarios As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents btnLimpiarUsuario As Button
    Friend WithEvents txtNombreUsuario As TextBox
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnEliminarUsuario As Button
    Friend WithEvents btnmodificarUsuario As Button
    Friend WithEvents btnAñadirUsuario As Button
    Friend WithEvents lblResultado As Label
    Friend WithEvents txtRuta As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents listaUsuarios As ListBox
    Friend WithEvents btnConectar As Button
    Friend WithEvents btnRuta As Button
    Friend WithEvents btnEliminarArtista As Button
    Friend WithEvents btnAñadirArtista As Button
    Friend WithEvents txtNombreArtista As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtNacionalidadArtista As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents listaArtistas As ListBox
    Friend WithEvents btnLimpiarArtista As Button
    Friend WithEvents btnmodificarArtista As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label10 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents btnLimpiarAlbum As Button
    Friend WithEvents btnEliminarAlbum As Button
    Friend WithEvents btnModificarAlbum As Button
    Friend WithEvents btnAñadirAlbum As Button
    Friend WithEvents txtNombreAlbum As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtFechaPubli As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txtDuracionAlbum As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents listaAlbum As ListBox
    Friend WithEvents txtCancion As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents txtDuracionCancion As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents listaCanciones As ListBox
    Friend WithEvents btnLimpiarCancion As Button
    Friend WithEvents btnEliminarCancion As Button
    Friend WithEvents btnmodificarCancion As Button
    Friend WithEvents btnAñadirCancion As Button
    Friend WithEvents txtApellidosUsuario As TextBox
    Friend WithEvents txtFechaUsuario As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents btnAñadirFavorito As Button
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents ListaReproducciones As ListBox
    Friend WithEvents btnReproducir As Button
    Friend WithEvents btnEliminarArtistaFav As Button
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents listaArtistasFav As ListBox
    Friend WithEvents txtIdArtista As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtIdAlbum As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents txtIdCancion As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents txtFechahoy As TextBox
    Friend WithEvents Fecha As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents GroupBox11 As GroupBox
    Friend WithEvents ArtistasOrdenados As ListBox
    Friend WithEvents GroupBox10 As GroupBox
    Friend WithEvents TiempoRepArtFav As ListBox
    Friend WithEvents GroupBox9 As GroupBox
    Friend WithEvents UsuariosMasTiempo As ListBox
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents ArtistasMasEscuchados As ListBox
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents CancionesOrdenadas As ListBox
    Friend WithEvents BotonOrdenar As Button
    Friend WithEvents Empezar As Button
    Friend WithEvents FiltroUsuario As Button
    Friend WithEvents Label28 As Label
    Friend WithEvents Filtro_Usuario As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Label29 As Label
    Friend WithEvents OrdenarCanciones As Button
    Friend WithEvents Label30 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents FiltroPais As TextBox
End Class
