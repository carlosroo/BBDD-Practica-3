﻿Public Class ListaReproduccionDAO
    Public ReadOnly Property ListaRepro As Collection
    Public Sub New()
        Me.ListaRepro = New Collection
    End Sub
    Public Sub LeerTodas(ruta As String)
        Dim p As ListaReproduccion
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente(ruta).Leer("SELECT * FROM REPRODUCCIONES ORDER BY IdReproduccion")
        For Each aux In col
            p = New ListaReproduccion(aux(1).ToString)
            p.Usuario = aux(2).ToString
            p.idCancion = aux(3).ToString
            p.Fecha = aux(4).ToString
            Me.ListaRepro.Add(p)
        Next
    End Sub
    Public Sub Leer(ByRef p As ListaReproduccion)
        Dim col As Collection : Dim aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT * FROM REPRODUCCIONES  WHERE IdReproduccion=" & p.IdRepodruccion)
        For Each aux In col
            p.Usuario = aux(2).ToString
            p.idCancion = aux(3).ToString
            p.Fecha = aux(4).ToString
        Next
    End Sub
    Public Function Reproducir(ByVal p As ListaReproduccion) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("INSERT INTO REPRODUCCIONES VALUES (" & p.IdRepodruccion & ", '" & p.Usuario & "','" & p.idCancion & "','" & p.Fecha & "');")

    End Function

End Class
