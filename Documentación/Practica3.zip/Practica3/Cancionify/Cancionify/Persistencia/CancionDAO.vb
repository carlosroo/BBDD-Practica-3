﻿Public Class CancionDAO
    Public ReadOnly Property Canciones As Collection
    Public Sub New()
        Me.Canciones = New Collection
    End Sub
    Public Sub LeerTodas(ruta As String)
        Dim p As Cancion
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente(ruta).Leer("SELECT * FROM CANCIONES ORDER BY IdCancion")
        For Each aux In col
            p = New Cancion(aux(1).ToString)
            p.Nombre = aux(2).ToString
            p.Album = aux(3).ToString
            p.Duracion = aux(4)
            Me.Canciones.Add(p)
        Next
    End Sub
    Public Sub Leer(ByRef p As Cancion)
        Dim col As Collection : Dim aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT * FROM CANCIONES  WHERE IdCancion=" & p.IdCancion)
        For Each aux In col
            p.Nombre = aux(2).ToString
            p.Album = aux(3).ToString
            p.Duracion = aux(4)
        Next
    End Sub
    Public Function Insertar(ByVal p As Cancion) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("INSERT INTO CANCIONES VALUES ('" & p.IdCancion & "', '" & p.Nombre & "','" & p.Album & "','" & p.Duracion & "');") ''  faltaría añadirla a un album? da error
    End Function

    Public Function Actualizar(ByVal p As Cancion) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("UPDATE CANCIONES SET Nombre='" & p.Nombre & "', Album='" & p.Album & "', Duracion='" & p.Duracion & "' WHERE IdCancion=" & p.IdCancion & ";")
    End Function

    Public Function Borrar(ByVal p As Cancion) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("DELETE FROM CANCIONES WHERE IdCancion=" & p.IdCancion & ";")
    End Function

    Public Sub LeerPorReproducciones(ruta As String)
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente(ruta).Leer("SELECT CANCIONES.IdCancion, CANCIONES.Nombre, COUNT(REPRODUCCIONES.Cancion) as Reproducciones 
                FROM CANCIONES LEFT JOIN REPRODUCCIONES ON CANCIONES.IdCancion = REPRODUCCIONES.cancion GROUP BY CANCIONES.IdCancion, CANCIONES.Nombre ORDER BY COUNT(REPRODUCCIONES.Cancion) DESC")
        For Each aux In col
            Me.Canciones.Add(aux(2).ToString)
        Next
    End Sub
    Public Sub LeerReproduccionHistory(ByRef s As Cancion)
        Dim col As Collection : Dim aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT REPRODUCCIONES.Usuario FROM REPRODUCCIONES INNER JOIN CANCIONES ON (REPRODUCCIONES.Cancion = CANCIONES.IdCancion) WHERE REPRODUCCIONES.Cancion =" & s.IdCancion & " ORDER BY REPRODUCCIONES.IdReproduccion")
        For Each aux In col
            Me.Canciones.Add(aux(1).ToString)
        Next
    End Sub

End Class
