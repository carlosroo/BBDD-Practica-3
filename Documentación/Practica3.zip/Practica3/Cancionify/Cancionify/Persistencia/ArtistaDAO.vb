﻿Public Class ArtistaDAO
    Public ReadOnly Property Artistas As Collection
    Public Sub New()
        Me.Artistas = New Collection
    End Sub
    Public Sub LeerTodas(ruta As String)
        Dim p As Artista
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente(ruta).Leer("SELECT * FROM ARTISTAS ORDER BY IdArtista")
        For Each aux In col
            p = New Artista(aux(1).ToString)
            p.Nombre = aux(2).ToString
            p.Pais = aux(3).ToString
            p.Imagen = aux(4).ToString

            Me.Artistas.Add(p)
        Next
    End Sub
    Public Sub Leer(ByRef p As Artista)
        Dim col As Collection : Dim aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT * FROM ARTISTAS  WHERE IdArtista=" & p.IdArtista)
        For Each aux In col

            p.Nombre = aux(2).ToString
            p.Pais = aux(3).ToString
            p.Imagen = aux(4).ToString
        Next
    End Sub
    Public Function Insertar(ByVal p As Artista) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("INSERT INTO ARTISTAS VALUES (" & p.IdArtista & ", '" & p.Nombre & "','" & p.Pais & "','" & p.Imagen & "');")
    End Function

    Public Function Actualizar(ByVal p As Artista) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("UPDATE ARTISTAS SET Nombre='" & p.Nombre & "', Pais='" & p.Pais & "' WHERE IdArtista=" & p.IdArtista & ";")
    End Function

    Public Function Borrar(ByVal p As Artista) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("DELETE FROM ARTISTAS WHERE IdArtista=" & p.IdArtista & ";")
    End Function

    Public Sub ReadByListened(email As String, Initial As Date, Final As Date)
        Dim a As Artista
        ''Me.ArtistasMasEscuchados.Clear()
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT ARTISTAS.Nombre FROM ARTISTAS, ALBUMES, CANCIONES, USUARIOS, REPRODUCCIONES
                WHERE ARTISTAS.IdArtista = ALBUMES.artista AND ALBUMES.IdAlbum = CANCIONES.Album AND CANCIONES.IdCancion = REPRODUCCIONES.Cancion AND REPRODUCCIONES.usuario = USUARIOS.email
                AND USUARIOS.email = '" & email & "' AND REPRODUCCIONES.fecha BETWEEN #" & Initial & "# AND #" & Final & "#
                GROUP BY ARTISTAS.Nombre ORDER BY COUNT(ARTISTAS.Nombre) DESC")
        For Each aux In col
            a = New Artista(aux(1).ToString)
            Me.Artistas.Add(a)
        Next
    End Sub

    Public Sub LeerPaises(ruta As String)
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente(ruta).Leer("SELECT DISTINCT Pais FROM ARTISTAS ORDER BY Pais") ''Para no sacar los repetidos
        For Each aux In col
            Me.Artistas.Add(aux(1).ToString)
        Next
    End Sub

    Public Sub LeerPorPais(ByRef a As Artista)
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT ARTISTAS.Nombre FROM ARTISTAS, ALBUMES, CANCIONES, REPRODUCCIONES WHERE ARTISTAS.IdArtista = ALBUMES.Artista AND ALBUMES.IdAlbum = CANCIONES.Album AND CANCIONES.IdCancion = REPRODUCCIONES.Cancion AND ARTISTAS.Pais = '" & a.Nombre & "' GROUP BY (ARTISTAS.Nombre) ORDER BY COUNT(REPRODUCCIONES.Cancion) DESC")
        For Each aux In col
            Me.Artistas.Add(aux(1).ToString)
        Next
        col = AgenteBD.ObtenerAgente.Leer("SELECT ARTISTAS.Nombre FROM ARTISTAS WHERE Pais='" & a.Nombre & "' AND IdArtista NOT IN (
               SELECT ARTISTAS.idArtista FROM ARTISTAS, ALBUMES, CANCIONES, REPRODUCCIONES WHERE ARTISTAS.IdArtista = ALBUMES.artista AND ALBUMES.IdAlbum = CANCIONES.Album AND CANCIONES.IdCancion = REPRODUCCIONES.cancion AND ARTISTAS.pais = '" & a.Nombre & "'
               GROUP BY (ARTISTAS.IdArtista) ORDER BY COUNT(REPRODUCCIONES.cancion) DESC)")
        For Each aux In col
            Me.Artistas.Add(aux(1).ToString)
        Next
    End Sub

    Public Sub LeerPorReproduccion()
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT ARTISTAS.Nombre FROM ARTISTAS, ALBUMES, CANCIONES, REPRODUCCIONES
                WHERE ARTISTAS.IdArtista = ALBUMES.Artista AND ALBUMES.IdAlbum = CANCIONES.Album AND CANCIONES.IdCancion = REPRODUCCIONES.Cancion
                GROUP BY (ARTISTAS.Nombre) ORDER BY COUNT(REPRODUCCIONES.Cancion) DESC")
        For Each aux In col
            Me.Artistas.Add(aux(1).ToString)
        Next
        col = AgenteBD.ObtenerAgente.Leer("SELECT ARTISTAS.Nombre FROM ARTISTAS WHERE IdArtista NOT IN (
                SELECT ARTISTAS.IdArtista FROM ARTISTAS, ALBUMES, CANCIONES, REPRODUCCIONES
                WHERE ARTISTAS.IdArtista = ALBUMES.artista AND ALBUMES.IdAlbum = CANCIONES.Album AND CANCIONES.IdCancion = REPRODUCCIONES.Cancion
                GROUP BY (ARTISTAS.IdArtista) ORDER BY COUNT(REPRODUCCIONES.Cancion) DESC)")
        For Each aux In col
            Me.Artistas.Add(aux(1).ToString)
        Next
    End Sub

End Class
