﻿Public Class PersonaDAO
    Public ReadOnly Property Personas As Collection
    Public Sub New()
        Me.Personas = New Collection
    End Sub
    Public Sub LeerTodas(ruta As String)
        Dim p As Persona
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente(ruta).Leer("SELECT * FROM USUARIOS ORDER BY Email")
        For Each aux In col
            p = New Persona(aux(1).ToString)
            p.Nombre = aux(2).ToString
            p.Apellido = aux(3).ToString
            p.FechaNacimiento = aux(4).ToString
            Me.Personas.Add(p)
        Next
    End Sub
    Public Sub Leer(ByRef p As Persona)
        Dim col As Collection : Dim aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT * FROM USUARIOS WHERE Email='" & p.Email & "';")
        For Each aux In col
            p.Nombre = aux(2).ToString
            p.Apellido = aux(3).ToString
            p.FechaNacimiento = aux(4).ToString
        Next
    End Sub
    Public Function Insertar(ByVal p As Persona) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("INSERT INTO USUARIOS VALUES ('" & p.Email & "', '" & p.Nombre & "','" & p.Apellido & "','" & p.FechaNacimiento & "');")
    End Function

    Public Function Actualizar(ByVal p As Persona) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("UPDATE USUARIOS SET Nombre='" & p.Nombre & "', Apellidos='" & p.Apellido & "' where Email='" & p.Email & "';")
    End Function

    Public Function Borrar(ByVal p As Persona) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("DELETE FROM USUARIOS WHERE Email='" & p.Email & "';")
    End Function


    Public Function esFavorito(Email As String, a As Artista)
        Dim col As Collection : Dim aux As Collection : Dim n As Integer
        '' Hemos cambiado modificar por leer
        col = AgenteBD.ObtenerAgente.Leer("SELECT COUNT(*) FROM ARTISTAS_FAVORITOS, USUARIO, ARTISTAS WHERE USUARIO.Email = ARTISTAS_FAVORITOS.USUARIO And ARTISTAS.IdArtista = ARTISTAS_FAVORITOS.Artista And USUARIO.Email= '" & Email & "' And ARTISTA.IdArtista =" & a.IdArtista & ";")
        For Each aux In col
            n = aux(1)
        Next
        Return n
    End Function

    Public Sub LeerPorTiempo(ruta As String)
        Dim u As Persona
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente(ruta).Leer("SELECT Email FROM USUARIOS, REPRODUCCIONES WHERE USUARIOS.Email = REPRODUCCIONES.user
                GROUP BY Email ORDER BY COUNT(REPRODUCCIONES.user) DESC")
        For Each aux In col
            u = New Persona(aux(1).ToString)
            u.LeerPersona()
            Me.Personas.Add(u)
        Next
        col = AgenteBD.ObtenerAgente(ruta).Leer("SELECT email FROM USUARIOS WHERE Email NOT IN (
                SELECT Email FROM USUARIOS, REPRODUCCIONES WHERE USUARIOS.email = REPRODUCCINES.usuario GROUP BY Email ORDER BY COUNT(REPRODUCCIONES.usuario) DESC)")
        For Each aux In col
            u = New Persona(aux(1).ToString)
            u.LeerPersona()
            Me.Personas.Add(u)
        Next
    End Sub

    Public Sub OrdenarPorTiempo(ruta As String)
        Dim u As Persona
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente(ruta).Leer("SELECT USUARIOS.email FROM USUARIOS, REPRODUCCIONES, CANCIONES WHERE USUARIOS.email = REPRODUCCIONES.usuario AND REPRODUCCIONES.cancion = CANCIONES.IdCancion GROUP BY USUARIOS.email ORDER BY SUM(CANCIONES.Duracion) DESC")
        For Each aux In col
            u = New Persona(aux(1).ToString)
            u.LeerPersona()
            Me.Personas.Add(u)
        Next
    End Sub

End Class
