﻿Public Class ArtistaFavDAO
    Public ReadOnly Property ArtistasFav As Collection
    Public Sub New()
        Me.ArtistasFav = New Collection
    End Sub
    Public Sub LeerTodas(ruta As String)
        Dim p As ArtistaFav
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente(ruta).Leer("SELECT * FROM ARTISTAS_FAVORITOS ORDER BY Usuario")
        For Each aux In col
            p = New ArtistaFav(aux(1).ToString)

            p.Artista = aux(2).ToString
            p.Fecha = aux(3).ToString
            Me.ArtistasFav.Add(p)
        Next
    End Sub
    Public Sub Leer(ByRef p As ArtistaFav)
        Dim col As Collection : Dim aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT * FROM ARTISTAS_FAVORITOS  WHERE Usuario='" & p.Usuario & "';")
        For Each aux In col

            p.Artista = aux(2).ToString
            p.Fecha = aux(3).ToString
        Next
    End Sub
    Public Function Insertar(ByVal p As ArtistaFav) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("INSERT INTO ARTISTAS_FAVORITOS VALUES ('" & p.Usuario & "', " & p.Artista & ",'" & p.Fecha & "');")
    End Function

    Public Function Borrar(ByVal p As ArtistaFav) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("DELETE FROM ARTISTAS_FAVORITOS WHERE Artista=" & p.Artista & ";")
    End Function
End Class

