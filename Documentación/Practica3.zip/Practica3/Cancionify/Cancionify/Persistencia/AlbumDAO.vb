﻿Public Class AlbumDAO
    Public ReadOnly Property Albumes As Collection
    Public Sub New()
        Me.Albumes = New Collection
    End Sub
    Public Sub LeerTodas(ruta As String)
        Dim p As Album
        Dim col, aux As Collection
        col = AgenteBD.ObtenerAgente(ruta).Leer("SELECT * FROM ALBUMES ORDER BY IdAlbum")
        For Each aux In col
            p = New Album(aux(1).ToString)
            p.Nombre = aux(2).ToString
            p.Fecha = aux(3).ToString
            p.Artista = aux(4).ToString
            p.Portada = aux(5).ToString
            Me.Albumes.Add(p)
        Next
    End Sub
    Public Sub Leer(ByRef p As Album)
        Dim col As Collection : Dim aux As Collection
        col = AgenteBD.ObtenerAgente.Leer("SELECT * FROM ALBUMES  WHERE IdAlbum=" & p.IdAlbum)
        For Each aux In col

            p.Nombre = aux(2).ToString
            p.Fecha = aux(3).ToString
            p.Artista = aux(4).ToString
            p.Portada = aux(5).ToString
        Next
    End Sub
    Public Function Insertar(ByVal p As Album) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("INSERT INTO ALBUMES VALUES (" & p.IdAlbum & ", '" & p.Nombre & "','" & p.Fecha & "','" & p.Artista & "','" & p.Portada & "');")
    End Function

    Public Function Actualizar(ByVal p As Album) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("UPDATE ALBUMES SET Nombre='" & p.Nombre & "', Fecha='" & p.Fecha & "' WHERE IdAlbum=" & p.IdAlbum & ";")
    End Function

    Public Function Borrar(ByVal p As Album) As Integer
        Return AgenteBD.ObtenerAgente.Modificar("DELETE FROM ALBUMES WHERE IdAlbum=" & p.IdAlbum & ";")
    End Function

End Class
