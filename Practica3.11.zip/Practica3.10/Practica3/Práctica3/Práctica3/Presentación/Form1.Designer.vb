﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl = New System.Windows.Forms.TabControl()
        Me.tab_jugadora = New System.Windows.Forms.TabPage()
        Me.FechaNacimiento = New System.Windows.Forms.DateTimePicker()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.BotonBorrarJugadora = New System.Windows.Forms.Button()
        Me.boton_insertarjugadora = New System.Windows.Forms.Button()
        Me.SelectPais = New System.Windows.Forms.ComboBox()
        Me.nombre_textbox = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.label_lista_jugadoras = New System.Windows.Forms.Label()
        Me.Lista_jugadoras = New System.Windows.Forms.ListBox()
        Me.tab_pais = New System.Windows.Forms.TabPage()
        Me.Boton_Actualizar_Pais = New System.Windows.Forms.Button()
        Me.Boton_Borrar_Pais = New System.Windows.Forms.Button()
        Me.Boton_Insertar_Pais = New System.Windows.Forms.Button()
        Me.NombrePais_Text = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lista_paises = New System.Windows.Forms.ListBox()
        Me.tab_torneo = New System.Windows.Forms.TabPage()
        Me.SelectPaisTorneo = New System.Windows.Forms.ComboBox()
        Me.ActualizarTorneos = New System.Windows.Forms.Button()
        Me.BotonBorrar_Torneo = New System.Windows.Forms.Button()
        Me.Boton_Insertar_Torneo = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.CiudadTorneo_Text = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.NombreTorneo_Text = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Lista_Torneos = New System.Windows.Forms.ListBox()
        Me.Inicio = New System.Windows.Forms.TabPage()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.AnoTorneo = New System.Windows.Forms.TextBox()
        Me.Final2 = New System.Windows.Forms.TextBox()
        Me.Final1 = New System.Windows.Forms.TextBox()
        Me.Semis4 = New System.Windows.Forms.TextBox()
        Me.Semis3 = New System.Windows.Forms.TextBox()
        Me.Semis2 = New System.Windows.Forms.TextBox()
        Me.Semis1 = New System.Windows.Forms.TextBox()
        Me.Cuartos8 = New System.Windows.Forms.TextBox()
        Me.Cuartos7 = New System.Windows.Forms.TextBox()
        Me.Cuartos6 = New System.Windows.Forms.TextBox()
        Me.Cuartos5 = New System.Windows.Forms.TextBox()
        Me.Cuartos4 = New System.Windows.Forms.TextBox()
        Me.Cuartos3 = New System.Windows.Forms.TextBox()
        Me.Cuartos2 = New System.Windows.Forms.TextBox()
        Me.Cuartos1 = New System.Windows.Forms.TextBox()
        Me.SeleccionarTorneo = New System.Windows.Forms.ComboBox()
        Me.Boton_InsertarEdicion = New System.Windows.Forms.Button()
        Me.TabControl.SuspendLayout()
        Me.tab_jugadora.SuspendLayout()
        Me.tab_pais.SuspendLayout()
        Me.tab_torneo.SuspendLayout()
        Me.Inicio.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl
        '
        Me.TabControl.Controls.Add(Me.tab_jugadora)
        Me.TabControl.Controls.Add(Me.tab_pais)
        Me.TabControl.Controls.Add(Me.tab_torneo)
        Me.TabControl.Controls.Add(Me.Inicio)
        Me.TabControl.Location = New System.Drawing.Point(78, 38)
        Me.TabControl.Name = "TabControl"
        Me.TabControl.SelectedIndex = 0
        Me.TabControl.Size = New System.Drawing.Size(644, 386)
        Me.TabControl.TabIndex = 0
        '
        'tab_jugadora
        '
        Me.tab_jugadora.Controls.Add(Me.FechaNacimiento)
        Me.tab_jugadora.Controls.Add(Me.Button3)
        Me.tab_jugadora.Controls.Add(Me.BotonBorrarJugadora)
        Me.tab_jugadora.Controls.Add(Me.boton_insertarjugadora)
        Me.tab_jugadora.Controls.Add(Me.SelectPais)
        Me.tab_jugadora.Controls.Add(Me.nombre_textbox)
        Me.tab_jugadora.Controls.Add(Me.Label3)
        Me.tab_jugadora.Controls.Add(Me.Label2)
        Me.tab_jugadora.Controls.Add(Me.Label1)
        Me.tab_jugadora.Controls.Add(Me.label_lista_jugadoras)
        Me.tab_jugadora.Controls.Add(Me.Lista_jugadoras)
        Me.tab_jugadora.Location = New System.Drawing.Point(4, 22)
        Me.tab_jugadora.Name = "tab_jugadora"
        Me.tab_jugadora.Padding = New System.Windows.Forms.Padding(3)
        Me.tab_jugadora.Size = New System.Drawing.Size(636, 360)
        Me.tab_jugadora.TabIndex = 0
        Me.tab_jugadora.Text = "Jugadora"
        Me.tab_jugadora.UseVisualStyleBackColor = True
        '
        'FechaNacimiento
        '
        Me.FechaNacimiento.Location = New System.Drawing.Point(376, 185)
        Me.FechaNacimiento.Name = "FechaNacimiento"
        Me.FechaNacimiento.Size = New System.Drawing.Size(100, 20)
        Me.FechaNacimiento.TabIndex = 13
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(348, 259)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 12
        Me.Button3.Text = "Actualizar"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'BotonBorrarJugadora
        '
        Me.BotonBorrarJugadora.Location = New System.Drawing.Point(451, 259)
        Me.BotonBorrarJugadora.Name = "BotonBorrarJugadora"
        Me.BotonBorrarJugadora.Size = New System.Drawing.Size(75, 23)
        Me.BotonBorrarJugadora.TabIndex = 11
        Me.BotonBorrarJugadora.Text = "Borrar"
        Me.BotonBorrarJugadora.UseVisualStyleBackColor = True
        '
        'boton_insertarjugadora
        '
        Me.boton_insertarjugadora.Location = New System.Drawing.Point(239, 259)
        Me.boton_insertarjugadora.Name = "boton_insertarjugadora"
        Me.boton_insertarjugadora.Size = New System.Drawing.Size(75, 23)
        Me.boton_insertarjugadora.TabIndex = 10
        Me.boton_insertarjugadora.Text = "Insertar"
        Me.boton_insertarjugadora.UseVisualStyleBackColor = True
        '
        'SelectPais
        '
        Me.SelectPais.FormattingEnabled = True
        Me.SelectPais.Location = New System.Drawing.Point(376, 143)
        Me.SelectPais.Name = "SelectPais"
        Me.SelectPais.Size = New System.Drawing.Size(100, 21)
        Me.SelectPais.TabIndex = 8
        '
        'nombre_textbox
        '
        Me.nombre_textbox.Location = New System.Drawing.Point(376, 107)
        Me.nombre_textbox.Name = "nombre_textbox"
        Me.nombre_textbox.Size = New System.Drawing.Size(100, 20)
        Me.nombre_textbox.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(236, 189)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(134, 16)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Fecha de nacimiento"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(338, 148)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 16)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "País"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(313, 109)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 16)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Nombre"
        '
        'label_lista_jugadoras
        '
        Me.label_lista_jugadoras.AutoSize = True
        Me.label_lista_jugadoras.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label_lista_jugadoras.Location = New System.Drawing.Point(48, 51)
        Me.label_lista_jugadoras.Name = "label_lista_jugadoras"
        Me.label_lista_jugadoras.Size = New System.Drawing.Size(120, 16)
        Me.label_lista_jugadoras.TabIndex = 1
        Me.label_lista_jugadoras.Text = "Lista de jugadoras"
        '
        'Lista_jugadoras
        '
        Me.Lista_jugadoras.FormattingEnabled = True
        Me.Lista_jugadoras.Location = New System.Drawing.Point(41, 70)
        Me.Lista_jugadoras.Name = "Lista_jugadoras"
        Me.Lista_jugadoras.Size = New System.Drawing.Size(140, 212)
        Me.Lista_jugadoras.TabIndex = 0
        '
        'tab_pais
        '
        Me.tab_pais.Controls.Add(Me.Boton_Actualizar_Pais)
        Me.tab_pais.Controls.Add(Me.Boton_Borrar_Pais)
        Me.tab_pais.Controls.Add(Me.Boton_Insertar_Pais)
        Me.tab_pais.Controls.Add(Me.NombrePais_Text)
        Me.tab_pais.Controls.Add(Me.Label6)
        Me.tab_pais.Controls.Add(Me.Label4)
        Me.tab_pais.Controls.Add(Me.lista_paises)
        Me.tab_pais.Location = New System.Drawing.Point(4, 22)
        Me.tab_pais.Name = "tab_pais"
        Me.tab_pais.Padding = New System.Windows.Forms.Padding(3)
        Me.tab_pais.Size = New System.Drawing.Size(636, 360)
        Me.tab_pais.TabIndex = 1
        Me.tab_pais.Text = "País"
        Me.tab_pais.UseVisualStyleBackColor = True
        '
        'Boton_Actualizar_Pais
        '
        Me.Boton_Actualizar_Pais.Location = New System.Drawing.Point(361, 220)
        Me.Boton_Actualizar_Pais.Name = "Boton_Actualizar_Pais"
        Me.Boton_Actualizar_Pais.Size = New System.Drawing.Size(75, 23)
        Me.Boton_Actualizar_Pais.TabIndex = 15
        Me.Boton_Actualizar_Pais.Text = "Actualizar"
        Me.Boton_Actualizar_Pais.UseVisualStyleBackColor = True
        '
        'Boton_Borrar_Pais
        '
        Me.Boton_Borrar_Pais.Location = New System.Drawing.Point(464, 220)
        Me.Boton_Borrar_Pais.Name = "Boton_Borrar_Pais"
        Me.Boton_Borrar_Pais.Size = New System.Drawing.Size(75, 23)
        Me.Boton_Borrar_Pais.TabIndex = 14
        Me.Boton_Borrar_Pais.Text = "Borrar"
        Me.Boton_Borrar_Pais.UseVisualStyleBackColor = True
        '
        'Boton_Insertar_Pais
        '
        Me.Boton_Insertar_Pais.Location = New System.Drawing.Point(252, 220)
        Me.Boton_Insertar_Pais.Name = "Boton_Insertar_Pais"
        Me.Boton_Insertar_Pais.Size = New System.Drawing.Size(75, 23)
        Me.Boton_Insertar_Pais.TabIndex = 13
        Me.Boton_Insertar_Pais.Text = "Insertar"
        Me.Boton_Insertar_Pais.UseVisualStyleBackColor = True
        '
        'NombrePais_Text
        '
        Me.NombrePais_Text.Location = New System.Drawing.Point(361, 105)
        Me.NombrePais_Text.Name = "NombrePais_Text"
        Me.NombrePais_Text.Size = New System.Drawing.Size(100, 20)
        Me.NombrePais_Text.TabIndex = 10
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(298, 107)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 16)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "Nombre"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(66, 45)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(97, 16)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Lista de países"
        '
        'lista_paises
        '
        Me.lista_paises.FormattingEnabled = True
        Me.lista_paises.Location = New System.Drawing.Point(46, 64)
        Me.lista_paises.Name = "lista_paises"
        Me.lista_paises.Size = New System.Drawing.Size(140, 212)
        Me.lista_paises.TabIndex = 0
        '
        'tab_torneo
        '
        Me.tab_torneo.Controls.Add(Me.SelectPaisTorneo)
        Me.tab_torneo.Controls.Add(Me.ActualizarTorneos)
        Me.tab_torneo.Controls.Add(Me.BotonBorrar_Torneo)
        Me.tab_torneo.Controls.Add(Me.Boton_Insertar_Torneo)
        Me.tab_torneo.Controls.Add(Me.Label11)
        Me.tab_torneo.Controls.Add(Me.CiudadTorneo_Text)
        Me.tab_torneo.Controls.Add(Me.Label10)
        Me.tab_torneo.Controls.Add(Me.NombreTorneo_Text)
        Me.tab_torneo.Controls.Add(Me.Label7)
        Me.tab_torneo.Controls.Add(Me.Label9)
        Me.tab_torneo.Controls.Add(Me.Lista_Torneos)
        Me.tab_torneo.Location = New System.Drawing.Point(4, 22)
        Me.tab_torneo.Name = "tab_torneo"
        Me.tab_torneo.Padding = New System.Windows.Forms.Padding(3)
        Me.tab_torneo.Size = New System.Drawing.Size(636, 360)
        Me.tab_torneo.TabIndex = 2
        Me.tab_torneo.Text = "Torneo"
        Me.tab_torneo.UseVisualStyleBackColor = True
        '
        'SelectPaisTorneo
        '
        Me.SelectPaisTorneo.FormattingEnabled = True
        Me.SelectPaisTorneo.Location = New System.Drawing.Point(298, 188)
        Me.SelectPaisTorneo.Name = "SelectPaisTorneo"
        Me.SelectPaisTorneo.Size = New System.Drawing.Size(100, 21)
        Me.SelectPaisTorneo.TabIndex = 24
        '
        'ActualizarTorneos
        '
        Me.ActualizarTorneos.Location = New System.Drawing.Point(298, 304)
        Me.ActualizarTorneos.Name = "ActualizarTorneos"
        Me.ActualizarTorneos.Size = New System.Drawing.Size(75, 23)
        Me.ActualizarTorneos.TabIndex = 23
        Me.ActualizarTorneos.Text = "Actualizar"
        Me.ActualizarTorneos.UseVisualStyleBackColor = True
        '
        'BotonBorrar_Torneo
        '
        Me.BotonBorrar_Torneo.Location = New System.Drawing.Point(401, 304)
        Me.BotonBorrar_Torneo.Name = "BotonBorrar_Torneo"
        Me.BotonBorrar_Torneo.Size = New System.Drawing.Size(75, 23)
        Me.BotonBorrar_Torneo.TabIndex = 22
        Me.BotonBorrar_Torneo.Text = "Borrar"
        Me.BotonBorrar_Torneo.UseVisualStyleBackColor = True
        '
        'Boton_Insertar_Torneo
        '
        Me.Boton_Insertar_Torneo.Location = New System.Drawing.Point(189, 304)
        Me.Boton_Insertar_Torneo.Name = "Boton_Insertar_Torneo"
        Me.Boton_Insertar_Torneo.Size = New System.Drawing.Size(75, 23)
        Me.Boton_Insertar_Torneo.TabIndex = 21
        Me.Boton_Insertar_Torneo.Text = "Insertar"
        Me.Boton_Insertar_Torneo.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(260, 190)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(32, 16)
        Me.Label11.TabIndex = 19
        Me.Label11.Text = "País"
        '
        'CiudadTorneo_Text
        '
        Me.CiudadTorneo_Text.Location = New System.Drawing.Point(298, 145)
        Me.CiudadTorneo_Text.Name = "CiudadTorneo_Text"
        Me.CiudadTorneo_Text.Size = New System.Drawing.Size(100, 20)
        Me.CiudadTorneo_Text.TabIndex = 18
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(242, 147)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(50, 16)
        Me.Label10.TabIndex = 17
        Me.Label10.Text = "Ciudad"
        '
        'NombreTorneo_Text
        '
        Me.NombreTorneo_Text.Location = New System.Drawing.Point(298, 102)
        Me.NombreTorneo_Text.Name = "NombreTorneo_Text"
        Me.NombreTorneo_Text.Size = New System.Drawing.Size(100, 20)
        Me.NombreTorneo_Text.TabIndex = 16
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(236, 104)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(57, 16)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "Nombre"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(68, 42)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(106, 16)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "Lista de torneos"
        '
        'Lista_Torneos
        '
        Me.Lista_Torneos.FormattingEnabled = True
        Me.Lista_Torneos.Location = New System.Drawing.Point(50, 61)
        Me.Lista_Torneos.Name = "Lista_Torneos"
        Me.Lista_Torneos.Size = New System.Drawing.Size(140, 212)
        Me.Lista_Torneos.TabIndex = 11
        '
        'Inicio
        '
        Me.Inicio.Controls.Add(Me.Boton_InsertarEdicion)
        Me.Inicio.Controls.Add(Me.Label8)
        Me.Inicio.Controls.Add(Me.Label5)
        Me.Inicio.Controls.Add(Me.AnoTorneo)
        Me.Inicio.Controls.Add(Me.Final2)
        Me.Inicio.Controls.Add(Me.Final1)
        Me.Inicio.Controls.Add(Me.Semis4)
        Me.Inicio.Controls.Add(Me.Semis3)
        Me.Inicio.Controls.Add(Me.Semis2)
        Me.Inicio.Controls.Add(Me.Semis1)
        Me.Inicio.Controls.Add(Me.Cuartos8)
        Me.Inicio.Controls.Add(Me.Cuartos7)
        Me.Inicio.Controls.Add(Me.Cuartos6)
        Me.Inicio.Controls.Add(Me.Cuartos5)
        Me.Inicio.Controls.Add(Me.Cuartos4)
        Me.Inicio.Controls.Add(Me.Cuartos3)
        Me.Inicio.Controls.Add(Me.Cuartos2)
        Me.Inicio.Controls.Add(Me.Cuartos1)
        Me.Inicio.Controls.Add(Me.SeleccionarTorneo)
        Me.Inicio.Location = New System.Drawing.Point(4, 22)
        Me.Inicio.Name = "Inicio"
        Me.Inicio.Padding = New System.Windows.Forms.Padding(3)
        Me.Inicio.Size = New System.Drawing.Size(636, 360)
        Me.Inicio.TabIndex = 3
        Me.Inicio.Text = "TabPage1"
        Me.Inicio.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(78, 165)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(113, 13)
        Me.Label8.TabIndex = 18
        Me.Label8.Text = "Seleccionar Anualidad"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(81, 98)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(100, 13)
        Me.Label5.TabIndex = 17
        Me.Label5.Text = "Seleccionar Torneo"
        '
        'AnoTorneo
        '
        Me.AnoTorneo.Location = New System.Drawing.Point(70, 181)
        Me.AnoTorneo.Name = "AnoTorneo"
        Me.AnoTorneo.Size = New System.Drawing.Size(121, 20)
        Me.AnoTorneo.TabIndex = 16
        '
        'Final2
        '
        Me.Final2.Location = New System.Drawing.Point(530, 181)
        Me.Final2.Name = "Final2"
        Me.Final2.Size = New System.Drawing.Size(100, 20)
        Me.Final2.TabIndex = 15
        '
        'Final1
        '
        Me.Final1.Location = New System.Drawing.Point(530, 136)
        Me.Final1.Name = "Final1"
        Me.Final1.Size = New System.Drawing.Size(100, 20)
        Me.Final1.TabIndex = 14
        '
        'Semis4
        '
        Me.Semis4.Location = New System.Drawing.Point(399, 280)
        Me.Semis4.Name = "Semis4"
        Me.Semis4.Size = New System.Drawing.Size(100, 20)
        Me.Semis4.TabIndex = 13
        '
        'Semis3
        '
        Me.Semis3.Location = New System.Drawing.Point(399, 209)
        Me.Semis3.Name = "Semis3"
        Me.Semis3.Size = New System.Drawing.Size(100, 20)
        Me.Semis3.TabIndex = 12
        '
        'Semis2
        '
        Me.Semis2.Location = New System.Drawing.Point(399, 101)
        Me.Semis2.Name = "Semis2"
        Me.Semis2.Size = New System.Drawing.Size(100, 20)
        Me.Semis2.TabIndex = 11
        '
        'Semis1
        '
        Me.Semis1.Location = New System.Drawing.Point(399, 28)
        Me.Semis1.Name = "Semis1"
        Me.Semis1.Size = New System.Drawing.Size(100, 20)
        Me.Semis1.TabIndex = 10
        '
        'Cuartos8
        '
        Me.Cuartos8.Location = New System.Drawing.Point(260, 295)
        Me.Cuartos8.Name = "Cuartos8"
        Me.Cuartos8.Size = New System.Drawing.Size(100, 20)
        Me.Cuartos8.TabIndex = 9
        '
        'Cuartos7
        '
        Me.Cuartos7.Location = New System.Drawing.Point(260, 269)
        Me.Cuartos7.Name = "Cuartos7"
        Me.Cuartos7.Size = New System.Drawing.Size(100, 20)
        Me.Cuartos7.TabIndex = 8
        '
        'Cuartos6
        '
        Me.Cuartos6.Location = New System.Drawing.Point(260, 220)
        Me.Cuartos6.Name = "Cuartos6"
        Me.Cuartos6.Size = New System.Drawing.Size(100, 20)
        Me.Cuartos6.TabIndex = 7
        '
        'Cuartos5
        '
        Me.Cuartos5.Location = New System.Drawing.Point(260, 194)
        Me.Cuartos5.Name = "Cuartos5"
        Me.Cuartos5.Size = New System.Drawing.Size(100, 20)
        Me.Cuartos5.TabIndex = 6
        '
        'Cuartos4
        '
        Me.Cuartos4.Location = New System.Drawing.Point(260, 115)
        Me.Cuartos4.Name = "Cuartos4"
        Me.Cuartos4.Size = New System.Drawing.Size(100, 20)
        Me.Cuartos4.TabIndex = 5
        '
        'Cuartos3
        '
        Me.Cuartos3.Location = New System.Drawing.Point(260, 89)
        Me.Cuartos3.Name = "Cuartos3"
        Me.Cuartos3.Size = New System.Drawing.Size(100, 20)
        Me.Cuartos3.TabIndex = 4
        '
        'Cuartos2
        '
        Me.Cuartos2.Location = New System.Drawing.Point(260, 41)
        Me.Cuartos2.Name = "Cuartos2"
        Me.Cuartos2.Size = New System.Drawing.Size(100, 20)
        Me.Cuartos2.TabIndex = 3
        '
        'Cuartos1
        '
        Me.Cuartos1.Location = New System.Drawing.Point(260, 15)
        Me.Cuartos1.Name = "Cuartos1"
        Me.Cuartos1.Size = New System.Drawing.Size(100, 20)
        Me.Cuartos1.TabIndex = 2
        '
        'SeleccionarTorneo
        '
        Me.SeleccionarTorneo.FormattingEnabled = True
        Me.SeleccionarTorneo.Location = New System.Drawing.Point(70, 114)
        Me.SeleccionarTorneo.Name = "SeleccionarTorneo"
        Me.SeleccionarTorneo.Size = New System.Drawing.Size(121, 21)
        Me.SeleccionarTorneo.TabIndex = 0
        '
        'Boton_InsertarEdicion
        '
        Me.Boton_InsertarEdicion.Location = New System.Drawing.Point(74, 252)
        Me.Boton_InsertarEdicion.Name = "Boton_InsertarEdicion"
        Me.Boton_InsertarEdicion.Size = New System.Drawing.Size(107, 23)
        Me.Boton_InsertarEdicion.TabIndex = 19
        Me.Boton_InsertarEdicion.Text = "Generar Edición"
        Me.Boton_InsertarEdicion.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.TabControl)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TabControl.ResumeLayout(False)
        Me.tab_jugadora.ResumeLayout(False)
        Me.tab_jugadora.PerformLayout()
        Me.tab_pais.ResumeLayout(False)
        Me.tab_pais.PerformLayout()
        Me.tab_torneo.ResumeLayout(False)
        Me.tab_torneo.PerformLayout()
        Me.Inicio.ResumeLayout(False)
        Me.Inicio.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl As TabControl
    Friend WithEvents tab_jugadora As TabPage
    Friend WithEvents tab_pais As TabPage
    Friend WithEvents tab_torneo As TabPage
    Friend WithEvents label_lista_jugadoras As Label
    Friend WithEvents Lista_jugadoras As ListBox
    Friend WithEvents Button3 As Button
    Friend WithEvents BotonBorrarJugadora As Button
    Friend WithEvents boton_insertarjugadora As Button
    Friend WithEvents SelectPais As ComboBox
    Friend WithEvents nombre_textbox As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lista_paises As ListBox
    Friend WithEvents Boton_Actualizar_Pais As Button
    Friend WithEvents Boton_Borrar_Pais As Button
    Friend WithEvents Boton_Insertar_Pais As Button
    Friend WithEvents NombrePais_Text As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents ActualizarTorneos As Button
    Friend WithEvents BotonBorrar_Torneo As Button
    Friend WithEvents Boton_Insertar_Torneo As Button
    Friend WithEvents Label11 As Label
    Friend WithEvents CiudadTorneo_Text As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents NombreTorneo_Text As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Lista_Torneos As ListBox
    Friend WithEvents Inicio As TabPage
    Friend WithEvents FechaNacimiento As DateTimePicker
    Friend WithEvents SelectPaisTorneo As ComboBox
    Friend WithEvents SeleccionarTorneo As ComboBox
    Friend WithEvents AnoTorneo As TextBox
    Friend WithEvents Final2 As TextBox
    Friend WithEvents Final1 As TextBox
    Friend WithEvents Semis4 As TextBox
    Friend WithEvents Semis3 As TextBox
    Friend WithEvents Semis2 As TextBox
    Friend WithEvents Semis1 As TextBox
    Friend WithEvents Cuartos8 As TextBox
    Friend WithEvents Cuartos7 As TextBox
    Friend WithEvents Cuartos6 As TextBox
    Friend WithEvents Cuartos5 As TextBox
    Friend WithEvents Cuartos4 As TextBox
    Friend WithEvents Cuartos3 As TextBox
    Friend WithEvents Cuartos2 As TextBox
    Friend WithEvents Cuartos1 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Boton_InsertarEdicion As Button
End Class
